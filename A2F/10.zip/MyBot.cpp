/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <limits.h>
#include <algorithm> 
#include <time.h>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best possible_moves" to
         * spawning a background processing thread. 
         */
        Turn turn;
        int depth;
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
        float alphaBeta(OthelloBoard& board, int d, float alpha, float beta,clock_t start_time, Turn t);
        float heuristicFunc(OthelloBoard& board,Turn t);
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
    this->turn = turn;
}

Move MyBot::play( const OthelloBoard& board )
{   
    clock_t start_time, end_time;
    start_time = clock();
    list<Move> possible_moves = board.getValidMoves(turn);
    list<Move>::iterator last_move = possible_moves.begin();

    int d;

    if(board.getBlackCount() + board.getRedCount() < 50){
        d = 7;
    }
    else{
        d = 40;
    }

    for(int i = 3; i<d; i++)
    {
        this->depth = i;
        list<Move> possible_moves = board.getValidMoves(turn);
        list<Move>::iterator iter = possible_moves.begin();
        OthelloBoard temp_board;
        float alpha = INT_MIN, beta = INT_MAX;
        list<Move>::iterator final_move = possible_moves.begin();
        float val=0; 
        for (iter = possible_moves.begin(); iter != possible_moves.end(); iter++){
            temp_board = board;
            temp_board.makeMove(turn, *iter);
            Turn next_turn;
            next_turn = other(turn);
            val = alphaBeta(temp_board, 1, alpha, beta, start_time , next_turn);
            if(val > alpha){
                alpha = val;
                final_move = iter;
            }
            end_time = clock();
            if((float)(end_time-start_time)/CLOCKS_PER_SEC  > 1.94){
                return *final_move;
            }   
        }
        last_move = final_move;
    }
    return *last_move;
}

float MyBot::alphaBeta(OthelloBoard& board, int d, float alpha, float beta,clock_t start_time, Turn t){
    clock_t end_time = clock();
    if((float)(end_time-start_time)/CLOCKS_PER_SEC > 1.94){
        return INT_MIN;
    }
    if(d == depth) return heuristicFunc(board, t);

    list<Move> possible_moves;
    OthelloBoard temp_board;
    list<Move>::iterator iter;
    Turn curr_turn = t;

    //J is max node
    if(t == turn){
        t = other(t);
        possible_moves = board.getValidMoves(curr_turn);
        if(possible_moves.size() == 0) return heuristicFunc(board , curr_turn);
        for(iter = possible_moves.begin(); iter != possible_moves.end(); iter++){
            temp_board = board;
            temp_board.makeMove(curr_turn,*iter);
            alpha = std::max(alpha, alphaBeta(temp_board, d+1, alpha, beta, start_time, t));
            if(alpha >= beta) return beta;
        }
        return alpha;
    }

    //J is min node
    else{
        t = other(t);
        possible_moves = board.getValidMoves( curr_turn );
        if(possible_moves.size() == 0) return heuristicFunc(board , curr_turn);
        for(iter = possible_moves.begin(); iter != possible_moves.end(); iter++){
            temp_board = board;
            temp_board.makeMove(curr_turn,*iter);
            beta = std::min(beta, alphaBeta(temp_board, d+1, alpha, beta, start_time, t));
            if(alpha >= beta) return alpha;
        }
        return beta;
    }
}

float MyBot::heuristicFunc(OthelloBoard& board , Turn t){
    Turn opp_turn;
    opp_turn = other(t);
    int curr_move_no = board.getBlackCount() + board.getRedCount() - 4;

    // Diiference of Coins

    int count_diff = (board.getBlackCount()-board.getRedCount());
    if (t == RED){
        count_diff = (board.getRedCount()-board.getBlackCount());
    }
    // mobility
    
    int move_diff;
    move_diff = board.getValidMoves(t).size() - board.getValidMoves(opp_turn).size();

    //corners

     int blackcorners = 0;
     int redcorners = 0;
    if(board.get(0,0) == BLACK) blackcorners++;
    else if(board.get(0,0) == RED) redcorners++;
    if(board.get(0,7) == BLACK) blackcorners++;
    else if(board.get(0,0) == RED) redcorners++;
    if(board.get(7,0) == BLACK) blackcorners++;
    else if(board.get(0,0) == RED) redcorners++;
    if(board.get(7,7) == BLACK) blackcorners++;
    else if(board.get(0,0) == RED) redcorners++;
    
    int corner_val = (blackcorners - redcorners);
    if(t == RED) 
        corner_val = -corner_val;

    //parity 

    int parity_val = (60-(curr_move_no))%2?-1:1;
    
    // position Value 
    
    int V[8][8] = {{20, -3, 11, 8, 8, 11, -3, 20},
                   {-3, -7, -4, 1, 1, -4, -7, -3},
    	           {11, -4, 2, 2, 2, 2, -4, 11},
    	           {8, 1, 2, -3, -3, 2, 1, 8},
    	           {8, 1, 2, -3, -3, 2, 1, 8},
    	           {11, -4, 2, 2, 2, 2, -4, 11},
    	           {-3, -7, -4, 1, 1, -4, -7, -3},
    	           {20, -3, 11, 8, 8, 11, -3, 20}
        };

    int pos = 0;

    for(int i=0; i<8; i++){
		for(int j=0; j<8; j++)  {
			if(board.get(i,j) == t)  {
				pos += V[i][j];
			} else if(board.get(i,j) == opp_turn)  {
				pos -= V[i][j];
			}
        }
    }

    //Corner Closeness
    
    int my_tiles = 0 ;
    int opp_tiles = 0;

	if(board.get(0,0) == EMPTY)   {
		if(board.get(0,1) == t) my_tiles++;
		else if(board.get(0,1) == opp_turn) opp_tiles++;
		if(board.get(1,0) == t) my_tiles++;
		else if(board.get(1,0) == opp_turn) opp_tiles++;
		if(board.get(1,1) == t) my_tiles++;
		else if(board.get(1,1) == opp_turn) opp_tiles++;
	}
	if(board.get(0,7) == EMPTY)   {
		if(board.get(0,6) == t) my_tiles++;
		else if(board.get(0,6) == opp_turn) opp_tiles++;
		if(board.get(1,6) == t) my_tiles++;
		else if(board.get(1,6) == opp_turn) opp_tiles++;
		if(board.get(1,7) == t) my_tiles++;
		else if(board.get(1,7) == opp_turn) opp_tiles++;
	}
	if(board.get(7,0) == EMPTY)   {
		if(board.get(6,0) == t) my_tiles++;
		else if(board.get(6,0) == opp_turn) opp_tiles++;
		if(board.get(6,1) == t) my_tiles++;
		else if(board.get(6,1) == opp_turn) opp_tiles++;
		if(board.get(7,1) == t) my_tiles++;
		else if(board.get(7,1) == opp_turn) opp_tiles++;
	}
	if(board.get(7,7) == EMPTY)   {
		if(board.get(6,7) == t) my_tiles++;
		else if(board.get(6,7) == opp_turn) opp_tiles++;
		if(board.get(6,6) == t) my_tiles++;
		else if(board.get(6,6) == opp_turn) opp_tiles++;
		if(board.get(7,6) == t) my_tiles++;
		else if(board.get(7,6) == opp_turn) opp_tiles++;
    }
	double l = -1*(my_tiles - opp_tiles);

    if(curr_move_no <= 34)
    {
        return double(pos + (20*move_diff) - count_diff + 1000*corner_val + l);
    }
    else    
    {
        return double(pos + (move_diff) + count_diff + 100*parity_val + 1000*corner_val + l);
    }
}   
// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


