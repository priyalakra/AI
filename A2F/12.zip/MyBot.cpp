/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <bits/stdc++.h>
using namespace std;
using namespace Desdemona;
// #define MAX_LEVEL 6;

Turn global_turn;
OthelloBoard global_board;

clock_t st,fn;

double boardEvaluator(vector<vector<char>> b, OthelloBoard board){
    // my_char - 'X'
    // opp_char - 'O'
    // empty - '-'

    int my_coins = 0, opp_coins = 0;
    double points = 0.0, corner = 0.0, low = 0.0, mobility = 0.0, d = 0.0;
    int V[8][8] =   { { 20, -3, 11, 8, 8, 11, -3, 20 },
                    { -3, -7, -4, 1, 1, -4, -7, -3 },
                    { 11, -4, 2, 2, 2, 2, -4, 11 },
                    { 8, 1, 2, -3, -3, 2, 1, 8 },
                    { 8, 1, 2, -3, -3, 2, 1, 8 },
                    { 11, -4, 2, 2, 2, 2, -4, 11 },
                    { -3, -7, -4, 1, 1, -4, -7, -3 },
                    { 20, -3, 11, 8, 8, 11, -3, 20 } };

    for(int i = 0; i < 8; i++){
        for(int j = 0; j < 8; j++){
            if(b[i][j] == 'X') my_coins++, d+=V[i][j];
            else if(b[i][j] == 'O') opp_coins++, d-=V[i][j];
        }
    }

    points = 1.0 * my_coins / (my_coins + opp_coins);
    if(my_coins < opp_coins) points = points - 1;
    else if(my_coins == opp_coins) points = 0;
    points = 100.0*points;
    
    my_coins = 0;
    opp_coins = 0;
    if(b[0][0] == 'X') my_coins++;
    if(b[0][7] == 'X') my_coins++;
    if(b[7][0] == 'X') my_coins++;
    if(b[7][7] == 'X') my_coins++;
    if(b[0][0] == 'O') opp_coins++;
    if(b[0][7] == 'O') opp_coins++;
    if(b[7][0] == 'O') opp_coins++;
    if(b[7][7] == 'O') opp_coins++;
    corner = 25 * (my_coins - opp_coins);

    my_coins = 0;
    opp_coins = 0;
    if(b[0][0] == '-'){
        if(b[0][1] == 'X') my_coins++;
        if(b[1][0] == 'X') my_coins++;
        if(b[1][1] == 'X') my_coins++;
        if(b[0][1] == 'O') opp_coins++;
        if(b[1][0] == 'O') opp_coins++;
        if(b[1][1] == 'O') opp_coins++;
    }
    if(b[0][7] == '-'){
        if(b[0][6] == 'X') my_coins++;
        if(b[1][7] == 'X') my_coins++;
        if(b[1][6] == 'X') my_coins++;
        if(b[0][6] == 'O') opp_coins++;
        if(b[1][7] == 'O') opp_coins++;
        if(b[1][6] == 'O') opp_coins++;
    }
    if(b[7][0] == '-'){
        if(b[6][0] == 'X') my_coins++;
        if(b[7][1] == 'X') my_coins++;
        if(b[6][1] == 'X') my_coins++;
        if(b[6][0] == 'O') opp_coins++;
        if(b[7][1] == 'O') opp_coins++;
        if(b[6][1] == 'O') opp_coins++;
    }
    if(b[7][7] == '-'){
        if(b[7][6] == 'X') my_coins++;
        if(b[6][7] == 'X') my_coins++;
        if(b[6][6] == 'X') my_coins++;
        if(b[7][6] == 'O') opp_coins++;
        if(b[6][7] == 'O') opp_coins++;
        if(b[6][6] == 'O') opp_coins++;
    }
    low = -10 * (my_coins - opp_coins);

    list<Move> moves = board.getValidMoves(global_turn);
    int my_move_cnt = moves.size();
    moves = board.getValidMoves(other(global_turn));
    int opp_move_cnt = moves.size();

    mobility = 1.0 * my_move_cnt / (my_move_cnt + opp_move_cnt);
    if(my_move_cnt < opp_move_cnt) mobility = mobility - 1;
    if(my_move_cnt == opp_move_cnt) mobility = 0;
    mobility = mobility * 100.0;

    double score =  0.1*(points+d) + 8.51 * corner + 3.82 * low + 0.87 * mobility;
    return score;
}

double testCurMove(OthelloBoard board, Move move, Turn turn, int level, double alpha, double beta){
    fn = clock();
    if(((double)(fn-st)/CLOCKS_PER_SEC)>1.9) {
        if(level%2) return INT_MIN;
        return INT_MAX;
    }
    if(level == 6){
        vector<vector<char>> b(8, vector<char> (8, '-'));
        for(int i = 0; i < 8; i++){
            for(int j = 0; j < 8; j++){
                Coin cur_coin = board.get(i,j);
                if(cur_coin == turn) b[i][j] = 'O';
                else if(cur_coin == other(turn)) b[i][j] = 'X';
            }
        }
        return boardEvaluator(b, board);
    }
    board.makeMove(turn,move);
    turn = other(turn);
    level++;
    list<Move> moves = board.getValidMoves(turn);
    auto it = moves.begin();
    double max_val;
    if(level%2 == 0) max_val = INT_MAX;
    else max_val = INT_MIN;
    for(;it!=moves.end();it++) {
        double cur_val = testCurMove(board,*it,turn,level,alpha,beta);
        if(level%2 == 0) {
            max_val = min(max_val,cur_val);
            beta = min(beta,max_val);
        }
        else {
            max_val = max(max_val,cur_val);
            alpha = max(alpha,max_val);     
        }
        if(beta<=alpha) break;
    }
    return max_val;  
}

double get_score(Move x){
    OthelloBoard temp = global_board;
    temp.makeMove(global_turn, x);
    vector<vector<char>> b(8, vector<char> (8, '-'));
    for(int i = 0; i < 8; i++){
        for(int j = 0; j < 8; j++){
            Coin cur_coin = temp.get(i,j);
            if(cur_coin == global_turn) b[i][j] = 'X';
            else if(cur_coin == other(global_turn)) b[i][j] = 'O';
        }
    }
    return boardEvaluator(b, temp);
}

bool compare(pair<double, Move> x, pair<double, Move> y){
    return x.first > y.first;
}

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    st = clock();
    global_turn = turn;
    global_board = board;
    list<Move> moves = board.getValidMoves(turn);
    vector<pair<double, Move>> score_move_pairs;
    auto it = moves.begin();
    for(;it!=moves.end();it++) {
        double score = get_score(*it);
        score_move_pairs.push_back({score, *it});
    }
    sort(score_move_pairs.begin(), score_move_pairs.end(), compare);
    Move best_move = score_move_pairs[0].second;
    double max_val = INT_MIN;
    int sz = score_move_pairs.size();
    for(int i = 0; i < sz; i++){
        Move cur_move = score_move_pairs[i].second;
        OthelloBoard temp_board = board;
        double cur_val = testCurMove(temp_board, cur_move, turn, 1, INT_MIN, INT_MAX);
        if(cur_val > max_val) {
            max_val = cur_val;
            best_move = cur_move;
        }
    }
    // cout << turn << "\n";
    // cout << "Sorted array - ";
    // for(int i = 0; i <sz; i++) cout<<score_move_pairs[i].first << " ";
    // cout<<"\n"; 
    // cout << "max_val = " << max_val << "\n";
    return best_move;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


/*

Play - Get all the possible moves, take the best move (i.e) by sorting with max values
Sorting parameter - Get the max values for each move
Test each move - Get current state of the board and evaluate the board state
Board evaluator - For now (count of my - count of opp)

*/