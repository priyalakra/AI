/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>

using namespace std;
using namespace Desdemona;

using Player = Turn;
using Moves = list<Move>;

#define MAX_DEPTH 7
#define MIN_VAL -10000000
#define MAX_VAL  10000000


class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
        
        Player maxPlayer;
        Move bestMove;
        clock_t startTime;

        int calcScore(const OthelloBoard &,Turn ,int , int);
        int alphaBeta(const OthelloBoard &, int depth, int alpha, int beta, Turn currTurn);
};

MyBot::MyBot(Turn turn)
    : OthelloPlayer(turn), maxPlayer(turn), bestMove(0, 0) 
{
    // cout <<  sizeof(OthelloBoard);
}

Move MyBot::play( const OthelloBoard& board )
{
    startTime = clock();
    alphaBeta(board, MAX_DEPTH, MIN_VAL, MAX_VAL, turn);
    return bestMove;
}


int MyBot::calcScore(const OthelloBoard &board,Turn currTurn, int currMovesSize, int oppMovesSize)
{

    int countRed = board.getRedCount();
    int countBlack = board.getBlackCount();

    int coinDiff = 1000 * (countRed - countBlack) / (countRed + countBlack);
    if (maxPlayer == BLACK)
        coinDiff *= -1;
    
    if(currMovesSize + oppMovesSize == 0)
        return coinDiff;

    int mobility = 1000 * (currMovesSize - oppMovesSize)*(currMovesSize + oppMovesSize);
    if(currTurn != maxPlayer) mobility *= -1;

    return coinDiff + mobility;
}


int MyBot::alphaBeta(const OthelloBoard &board, int depth, int alpha, int beta, Turn currTurn)
{
    Turn nextTurn = other(currTurn);
    Moves myMoves = board.getValidMoves(currTurn);
    Moves oppMoves = board.getValidMoves(nextTurn);

    // If terminal or leaf node is reached return the score of current board state
    if (depth == 0)
    {
        return calcScore(board,currTurn,myMoves.size(),oppMoves.size());
    }

    double timeElapsed = clock() - startTime;
    timeElapsed /= CLOCKS_PER_SEC;

    if( timeElapsed > 1.75)
    {               
		return calcScore(board,currTurn,myMoves.size(),oppMoves.size());
    }


    // If No valid moves can be made by both players return score of current board state
    if (myMoves.empty() && oppMoves.empty())
    {
        return calcScore(board,currTurn,myMoves.size(),oppMoves.size());
    }
    
    // If function is being executed for first time initialize the bestMove
    if (depth == MAX_DEPTH && currTurn == maxPlayer)
    {
        bestMove = myMoves.front();
    }

    for (Moves::iterator it = myMoves.begin(); it != myMoves.end(); it++)
    {
        OthelloBoard newBoard = board;
        newBoard.makeMove(currTurn, *it);
        int newAB = alphaBeta(newBoard, depth - 1, alpha, beta, nextTurn);

        if (currTurn == maxPlayer)
        {
            if (alpha < newAB)
            {
                alpha = newAB;
                if (depth == MAX_DEPTH)
                    bestMove = Move(*it);
            }
            if (beta <= alpha)
                break;
        }
        else
        {
            if (beta > newAB)
                beta = newAB;

            if (beta <= alpha)
                break;
        }
    }
    return currTurn == maxPlayer ? alpha : beta;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}