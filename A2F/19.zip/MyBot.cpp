/*
CS6380 : Artificial Intelligence Assignment II
Submission by: Santosh G (EE19B055) and Sharuhasan (EE19B117)

References:
- The Weight values (to compute the score) are taken from research papers(University of Washington)
- Other GitHub Repos
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>
#include <limits.h>
using namespace std;
using namespace Desdemona;

Turn my;
clock_t st_time,fin_time;
OthelloBoard actual_board;

double board_score( OthelloBoard board, Turn turn ){
	Turn my_color = my, opp_color = other(my);
	
	int my_til = 0, opp_til = 0, my_nei = 0, opp_nei = 0, x, y;
	double p = 0.0, c = 0.0, l = 0.0, m = 0.0, f = 0.0, d = 0.0;

    	int x_vec[] = {-1, -1, 0, 1, 1, 1, 0, -1};
    	int y_vec[] = {0, 1, 1, 1, 0, -1, -1, -1};
    	int weights[8][8] = 	{ { 20, -3, 11, 8, 8, 11, -3, 20 },
    				 { -3, -7, -4, 1, 1, -4, -7, -3 },
    				  { 11, -4, 2, 2, 2, 2, -4, 11 },
    				   { 8, 1, 2, -3, -3, 2, 1, 8 },
    				   { 8, 1, 2, -3, -3, 2, 1, 8 },
    				  { 11, -4, 2, 2, 2, 2, -4, 11 },
    				 { -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 20, -3, 11, 8, 8, 11, -3, 20 } };

    	for(int i = 0; i < 8; i++){
    		for(int j = 0; j < 8; j++){
    			if(board.get(i, j) == my_color){
    				d += weights[i][j];
                		my_til++;
            		} 
            		else if(board.get(i, j) == opp_color){	
                		d -= weights[i][j];
                		opp_til++;
            			}
            		if(board.get(i, j) != 0){
                		for(int k = 0; k < 8; k++){
                    			x = i + x_vec[k]; y = j + y_vec[k];
                    			if(x >= 0 && x < 8 && y >= 0 && y < 8 && (board.get(i, j) == 0)) {
                        			if(board.get(i, j) == my_color)  my_nei++;
                        			else opp_nei++;
                        			break;
                    			}
                		}
            		}
        	}
        }

    if(my_til > opp_til) p = (100.0 * my_til)/(my_til + opp_til);
    else if(my_til < opp_til) p = -(100.0 * opp_til)/(my_til + opp_til);

    if(my_nei > opp_nei) f = -(100.0 * my_nei)/(my_nei + opp_nei);
    else if(my_nei < opp_nei) f = (100.0 * opp_nei)/(my_nei + opp_nei);

    // Corner occupancy
    my_til = opp_til = 0;
    if(board.get(0,0) == my_color) my_til++;
    else if(board.get(0,0) == opp_color) opp_til++;
    if(board.get(0,7) == my_color) my_til++;
    else if(board.get(0,7) == opp_color) opp_til++;
    if(board.get(7,0) == my_color) my_til++;
    else if(board.get(7,0) == opp_color) opp_til++;
    if(board.get(7,7) == my_color) my_til++;
    else if(board.get(7,7) == opp_color) opp_til++;
    c = 25 * (my_til - opp_til);

    // Corner closeness
    my_til = opp_til = 0;
    if(board.get(0,0) == 0)   {
        if(board.get(0,1) == my_color) my_til++;
        else if(board.get(0,1) == opp_color) opp_til++;
        if(board.get(1,1) == my_color) my_til++;
        else if(board.get(1,1) == opp_color) opp_til++;
        if(board.get(1,0) == my_color) my_til++;
        else if(board.get(1,0) == opp_color) opp_til++;
    }
    if(board.get(0,7) == 0)   {
        if(board.get(0,6) == my_color) my_til++;
        else if(board.get(0,6) == opp_color) opp_til++;
        if(board.get(1,6) == my_color) my_til++;
        else if(board.get(1,6) == opp_color) opp_til++;
        if(board.get(1,7) == my_color) my_til++;
        else if(board.get(1,7) == opp_color) opp_til++;
    }
    if(board.get(7,0) == 0)   {
        if(board.get(7,1) == my_color) my_til++;
        else if(board.get(7,1) == opp_color) opp_til++;
        if(board.get(6,1) == my_color) my_til++;
        else if(board.get(6,1) == opp_color) opp_til++;
        if(board.get(6,0) == my_color) my_til++;
        else if(board.get(6,0) == opp_color) opp_til++;
    }
    if(board.get(7,7) == 0)   {
        if(board.get(6,7) == my_color) my_til++;
        else if(board.get(6,7) == opp_color) opp_til++;
        if(board.get(6,6) == my_color) my_til++;
        else if(board.get(6,6) == opp_color) opp_til++;
        if(board.get(7,6) == my_color) my_til++;
        else if(board.get(7,6) == opp_color) opp_til++;
    }
    l = -10 * (my_til - opp_til);

    // Mobility
    my_til = board.getValidMoves(my).size();
    opp_til = board.getValidMoves(other(my)).size();
    if(my_til > opp_til) m = (100.0 * my_til)/(my_til + opp_til);
    else if(my_til < opp_til) m = -(100.0 * opp_til)/(my_til + opp_til);

    // final weighted score
    double score = (11 * p) + (850.724 * c) + (382.026 * l) + (86.922 * m) + (78.396 * f) + (10 * d);
    return score;
}

bool compare(Move a, Move b) {
    OthelloBoard pos_1 = actual_board, pos_2 = actual_board;
    
    //Making two positions/possibilities after 2 different moves
    pos_1.makeMove(my,a);     
    pos_2.makeMove(my,b);
    
    return board_score(pos_1,my)>board_score(pos_2,my);
}



double alpha_beta(OthelloBoard board, Move move, Turn turn, short depth, double alpha, double beta) {
	
	fin_time = clock();
	//Checking Timelimit
	if(((double)(fin_time - st_time)/CLOCKS_PER_SEC)>1.6) {
        //Checking if Layer is Odd or Even
        	if(depth & 1) return -INT_MAX;       
        return INT_MAX;
        }
	
	if(depth == 6) return board_score(board, turn);
	
	board.makeMove(turn, move);
	
	//Checking from the next step
	turn = other(turn);
	list<Move> new_mov = board.getValidMoves(turn);
	list<Move>::iterator iter = new_mov.begin();
	
	double final_score = INT_MIN;
	
	if(depth & 1) final_score = INT_MAX;
	if(!(new_mov.size())) return final_score;
	
	for(;iter!=new_mov.end();iter++) {
		double current = alpha_beta(board, *iter, turn, depth+1, alpha, beta);
		if(depth & 1) {
			final_score = min(final_score,current);
			beta = min(beta,final_score);				//Setting Beta values based on Minimums
		}
		
		else {
			final_score = max(final_score,current);
			alpha = max(alpha,final_score);		//Setting Alpha values based on Maximums
		}
		
		if(beta<=alpha) break;
	}
	
	return final_score; 
}


class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );
        /*** Play something */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    st_time = clock();    				//Starting the Clock
    list<Move> moves = board.getValidMoves(turn);	//Generating Set of Valid moves
    my = turn;						//Assigning Color/Coin
    
    actual_board = board;
    moves.sort(compare);
    list<Move>::iterator iter = moves.begin();
    Move best_move((*iter).x,(*iter).y);		//Initialising the move
    
    double final_val = -INT_MAX;
    double MAX = INT_MAX, MIN = -INT_MAX;
    OthelloBoard rough_board = board;
    short depth = 1;
    
    for(;iter!=moves.end();iter++) {
    	double curr_val = alpha_beta(rough_board,*iter,turn,depth,MIN,MAX);
    	if(curr_val > final_val) {
    		final_val = curr_val;
    		best_move = *iter;			//Replacing the move if it is better
    	}
    	rough_board = board;
    }
    return best_move;
    

}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}

