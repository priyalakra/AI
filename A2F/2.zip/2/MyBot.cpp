/**
* @file RandomBot.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Bot that randomly chooses a move to play with you
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         */
        MyBot(Turn turn);
        Turn color;

        int h_bias[8] = {-1, -1, 0, 1, 1, 1, 0, -1};

        int weight[8][8] = {{95, -20, 55, 45, 45, 55, -20, 95},
                          {-20, -35, -20, 5, 5, -20, -35, -20},
                          {55, -20, 10, 10, 10, 10, -20, 55},
                          {45, 5, 10, -15, -15, 10, 5, 45},
                          {45, 5, 10, -15, -15, 10, 5, 45},
                          {55, -20, 10, 10, 10, 10, -20, 55},
                          {-20, -35, -20, 5, 5, -20, -35, -20},
                          {95, -20, 55, 45, 45, 55, -20, 95}};

        int v_bias[8] = {0, 1, 1, 1, 0, -1, -1, -1};

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );

        clock_t start;
        clock_t end;

        virtual double alphaBeta(const OthelloBoard & board, Turn t, int d, double a, double b);
        virtual double basic(const OthelloBoard & board, Turn t);
        virtual double disk(const OthelloBoard & board, Turn t);
        virtual double front(const OthelloBoard & board, Turn t);
        virtual double mob(const OthelloBoard & board, Turn t);
        virtual double piece(const OthelloBoard & board, Turn t);
        virtual pair<double,double> corner(const OthelloBoard & board, Turn t);

        virtual bool isValid(int x, int y);

    private:
};

MyBot::MyBot(Turn turn)
    : OthelloPlayer(turn)
{
    
    color = turn;
}

Move MyBot::play(const OthelloBoard & board)
{
    
    start = clock();
    list<Move> valid = board.getValidMoves(turn);

    list<Move>:: iterator it = valid.begin();

    Move best = *it;

    double alpha = -1e18;
    double beta = 1e18;

    while (it != valid.end())
    {
      Move curr = *it;
      OthelloBoard cur_board = board;
      cur_board.makeMove(color, curr);

      double val = alphaBeta(cur_board, color, 5, alpha, beta);

      if (val > alpha)
      {
        alpha = val;
        best = curr;
      }

      it++;
    }

    return best;
}

double MyBot::alphaBeta(const OthelloBoard & board, Turn colour, int depth, double alpha, double beta)
{
  end = clock();
  if (double(end - start)/CLOCKS_PER_SEC >= 1.95)
  {
    if (colour == color) return alpha;
    return beta;
  }

  list<Move> opp_move = board.getValidMoves(other(colour));
  list<Move>:: iterator it = opp_move.begin();

  if ((depth == 0) || (opp_move.size() == 0))
  {

    return basic(board, color);
  }

  if (color == colour)
  {
    while (it != opp_move.end())
    {
      Move curr = *it;
      OthelloBoard cur_board = board;
      cur_board.makeMove(other(colour), curr);
      double temp = alphaBeta(cur_board, other(colour), depth - 1, alpha, beta);
      beta = min(beta, temp);

      if (alpha >= beta) break;
      it++;
    }

    return beta;
  }

  while (it != opp_move.end())
  {
    Move curr = *it;
    OthelloBoard cur_board = board;
    cur_board.makeMove(other(colour), curr);
    double temp = alphaBeta(cur_board, other(colour), depth - 1, alpha, beta);
    alpha = max(alpha, temp);

    if (alpha >= beta) break;
    it++;
  }

  return alpha;

}

double MyBot::disk(const OthelloBoard & board, Turn colour)
{
  int value = 0;

  for(int i=0; i<8; i++)
  {
    for(int j=0; j<8; j++)
    {
      if (board.get(i,j) == other(colour))
      {
        value -= weight[i][j];
      }
      else if (board.get(i,j) == colour)
      {
        value += weight[i][j];
      }
    }
  }

  return value;
}

bool MyBot::isValid(int x, int y)
{
  return ((x >= 0) && (x < 8) && (y >= 0) && (y < 8));
}

double MyBot::front(const OthelloBoard & board, Turn colour)
{
  double value = 0;
  int my_val = 0, opp_val = 0;

  for(int i=0; i<8; i++)
  {
    for(int j=0; j<8; j++)
    {
      if (board.get(i,j) != EMPTY)
      {
        for(int k=0; k<8; k++)
        {
          int x = i + h_bias[k];
          int y = j + v_bias[k];

          if (isValid(x,y) && board.get(x,y) == EMPTY)
          {
            if (board.get(i,j) == other(colour))
            {
              opp_val += 1;
            }
            else if (board.get(i,j) == colour)
            {
              my_val += 1;
            }
            break;
          }
        }
      }
    }
  }

  if (my_val + opp_val > 0)
  {
    value = - (100.0 * my_val) / (my_val + opp_val);

    if (value > -50)
    {
      value += 100;
    }
  }
   return value;
}

double MyBot::piece(const OthelloBoard & board, Turn colour)
{
  
  int black = board.getBlackCount();
  int red = board.getRedCount();

  if (colour == RED)
  {
    swap(black, red);
  }

  double value = (100 * black) / (black + red);

  if (value <= 50)
  {
    value -= 100;
  }

  return value;
}


double MyBot::mob(const OthelloBoard & board, Turn colour)
{
  
  double value = 0;

  int my_cnt = board.getValidMoves(colour).size();
  int opp_cnt = board.getValidMoves(other(colour)).size();

  if (my_cnt + opp_cnt > 0)
  {
    value = (100 * my_cnt) / (my_cnt + opp_cnt);
    if (value <= 50)
    {
      value -= 100;
    }
  }

  return value;

}

pair<double,double> MyBot::corner(const OthelloBoard & board, Turn colour)
{
  
  double crn = 0, crn_adj = 0;
  
  pair<int,int> c1[4] = {{0,0}, {0,7}, {7,0}, {7,7}};

  pair<int,int> adj[8] = {{-1,0}, {0,1}, {0,-1}, {1,0}, {1,1}, {1,-1}, {-1,-1}, {-1,1}};

  for(int i=0; i<4; i++)
  {
      int x1 = c1[i].first;
      int x2 = c1[i].second;

      if (board.get(x1,x2) == other(colour))
      {
        crn -= 1;
      }
      else if (board.get(x1,x2) == colour)
      {
        crn += 1;
      }
      else
      {
        for(int j=0; j<8; j++)
        {
          int y1 = x1 + adj[j].first;
          int y2 = x2 + adj[j].second;

          if (isValid(y1,y2))
          {
            if (board.get(y1,y2) == other(colour))
            {
              crn_adj -= 1;
            }
            else if (board.get(y1,y2) == colour)
            {
              crn_adj += 1;
            }
          }
        }
      }
  }

    crn *= 25;
    crn_adj *= -12.5;

    return {crn, crn_adj};
}

double MyBot::basic(const OthelloBoard & board, Turn colour)
{
  double dis = disk(board, colour);
  double fro = front(board, colour);
  double pi = piece(board, colour);
  double mo = mob(board, colour);
  pair<double, double> crn_val = corner(board, colour);
  double crn = crn_val.first;
  double crn_adj = crn_val.second;

  double score = 10 * pi;
  score += 78.922 * mo;
  score += 382.026 * crn_adj;
  score += 2 * dis;
  score += 74.396 * fro;
  score += 801.724 * crn;
  

  return score;
}


// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


