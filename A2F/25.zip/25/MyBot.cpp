#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
using namespace std;
using namespace Desdemona;

#define INT_MIN -10e9

bool greaterThan(int x, int y)
{
    return x > y;
}

bool lessThan(int x, int y)
{
    return x < y;
}

class MyBot : public OthelloPlayer
{
public:
    MyBot(Turn turn);
    Turn my_color;
    int move_num = 0;
    virtual Move play(const OthelloBoard &board);
    virtual int heu_stat(const OthelloBoard &board, Turn turn);
    virtual int heuristic(const OthelloBoard &board, Turn turn);
    virtual int heu_brute(const OthelloBoard &board, Turn turn);
    virtual int alpha(const OthelloBoard &board, int depth, int alpha_min, int beta_max);
    virtual int beta(const OthelloBoard &board, int depth, int alpha_min, int beta_max);
};

MyBot::MyBot(Turn turn)
    : OthelloPlayer(turn)
{
}

Move MyBot::play(const OthelloBoard &board)
{
    move_num++;
    if (move_num == 1)
        my_color = turn;

    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it = moves.begin();

    int a;
    int depth = 2;
    int max_a = INT_MIN;

    Move next_move = *it;
    int i = 1;

    while (i < moves.size())
    {
        Turn trn = turn;
        OthelloBoard my_board(board);

        my_board.makeMove(trn, *it);
        a = beta(my_board, depth, max_a, 400);

        if (greaterThan(a, max_a))
        {
            max_a = a;
            next_move = *it;
        }
        it++;
        i++;
    }
    return next_move;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}

// Alpha represents the best position value which Max player can reach by using
// a pessimistic evaluation while Beta represents the best position Max player can reach by using
// an optimistic evaluation

int MyBot::beta(const OthelloBoard &board, int depth, int alpha_min, int beta_max)
{
    Turn turn_b;
    if (turn == RED)
    {
        turn_b = BLACK;
    }
    else
    {
        turn_b = RED;
    }
    list<Move> moves = board.getValidMoves(turn_b);
    list<Move>::iterator it = moves.begin();

    int b, i = 0;
    int min_b = beta_max;

    while (i < moves.size())
    {
        OthelloBoard my_board = board;
        Turn trn_b = turn_b;

        my_board.makeMove(trn_b, *it);
        b = alpha(my_board, depth - 1, alpha_min, min_b);

        if (lessThan(b, min_b))
        {
            min_b = b;
            if (lessThan(min_b, alpha_min))
                return alpha_min;
        }
        it++;
        i++;
    }
    return min_b;
}

int MyBot::alpha(const OthelloBoard &board, int depth, int alpha_min, int beta_max)
{
    if (depth == 0)
    {
        OthelloBoard my_board(board);
        return heuristic(my_board, turn);
    }
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it = moves.begin();

    int max_a = alpha_min;
    int a, i = 0;
    while (i < moves.size())
    {
        OthelloBoard my_board = board;
        Turn trn = turn;

        my_board.makeMove(trn, *it);
        a = beta(my_board, depth, max_a, beta_max);

        if (greaterThan(a, max_a))
        {
            max_a = a;
            if (greaterThan(max_a, beta_max))
            {
                return beta_max;
            }
        }
        it++;
        i++;
    }
    return max_a;
}

int MyBot::heuristic(const OthelloBoard &board, Turn turn)
{
    return (greaterThan(move_num, 25) ? heu_brute(board, turn) : heu_stat(board, turn));
}

int MyBot::heu_stat(const OthelloBoard &board, Turn turn)
{
    int i, j;
    Turn turn_b = other(turn);
    // heuristic matrix
    int ar[8][8] = {4, -3, 2, 2, 2, 2, -3, 4, -3, -4, -1, -1, -1, -1, -4, -3, 2, -1, 1, 0, 0, 1, -1, 2, 2, -1, 0, 1, 1, 0, -1, 2, 2, -1, 0, 1, 1, 0, -1, 2, 2, -1, 1, 0, 0, 1, -1, 2, -3, -4, -1, -1, -1, -1, -4, -3, 4, -3, 2, 2, 2, 2, -3, 4};
    int sum = 0;
    i = 0;
    j = 0;
    while (i < 8)
    {
        while (j < 8)
        {
            if (board.get(i, j) == turn)
            {
                // generating the heuristic value
                sum = sum + ar[i][j];
            }
            if (board.get(i, j) == turn_b)
            {
                // generating the heuristic value
                sum = sum - ar[i][j];
            }
            j++;
        }
        i++;
    }
    return sum;
}

int MyBot::heu_brute(const OthelloBoard &board, Turn turn)
{
    Turn turn_b = other(turn);
    int i, j;
    int ar[8][8];
    while (i < 8)
    {
        while (j < 8)
        {
            // randomly assigning values to hueristic matrix
            ar[i][j] = i * j;
            j++;
        }
        i++;
    }

    int sum = 0;
    i = 0;
    j = 0;
    while (i < 8)
    {
        while (j < 8)
        {
            if (board.get(i, j) == turn)
            {
                // generating the heuristic value
                sum = sum + ar[i][j];
            }
            if (board.get(i, j) == turn_b)
            {
                // generating the heuristic value
                sum = sum - ar[i][j];
            }
            j++;
        }
        i++;
    }
    return sum;
}
