#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>
using namespace std;
using namespace Desdemona;
/**********************
*Values taken from the Research paper of University of Washington.
***********************/
#define INFINITY_VAL 1e18

Turn myTurn;
clock_t sClock,fClock;
OthelloBoard Board;



/**********************************
   Input    : character opp and the string
   Function : checks whether the string contains e if yes return false
   Output   : returns the boolean value true or false
************************************/
bool canMove(char self, char opposite, char *s)  {
	
    if (s[0] != opposite)      /* ------>> */           return false;
	
    for (int i = 1; i < 8; i++) {
		if(s[i] == 'e')          /* ------>> */         return false;
		if(s[i] == self)         /* ------>> */         return true;
	}


	return false;
}

/************************************
   Input    : character opp, 2D character matrix, Integer value startx and Integer value starty
   Function : considers all the moves and based on the valid conditions it returns boolean value
   Output   : returns true if it is a valid move else returns false
***********************************/
bool isLegalMove(char self, char opposite, char gameGrid[8][8], int sx, int sy) {
	if (gameGrid[sx][sy] != 'e')    /* ------>> */                       return false;

	char s[10];
	int x, y, dx, dy, i;

	for(dy = -1; dy <= 1; dy++) {
        for(dx = -1; dx <= 1; dx++) {

            if (!dy && !dx)                  /* ------>> */              continue;
            s[0] = '\0';

            for(i = 1; i < 8; i++) {
                x = sx + i*dx;
                y = sy + i*dy;
                if (x >= 0 && y >= 0 && x<8 && y<8)    /* ------>> */     s[i-1] = gameGrid[x][y];
                else s[i-1] = 0;
            }

            if(canMove(self, opposite, s))   /* ------>> */               return true;
        }
    }

	return false;
}


/*****************************
   Input    : character opp, 2D character matrix
   Function : counts the number of the valid moves in the grid
   Output   : return an integer value denoting the count of valid moves.
******************************/
int numValidMoves(char self, char opposite, char gameGrid[8][8]) {
	int c = 0, i, j;
	
    for(i = 0; i < 8; i++) {
        for(j = 0; j < 8; j++) {
            if(isLegalMove(self, opposite, gameGrid, i, j))     /* ------>> */     c++;
        }
    }

	return c;
}


/*****************************
   Input    : 2D character matrix
   Function : calculates the score of the game
   Output   : return a double value denoting the score of the board game
******************************/
double othelloBoardEvaluator(char gameGrid[8][8])  {
	char col = 'm',opCol = 'y';
    int tls = 0, opTls = 0, i, j, k, frTls = 0, opFrTls = 0, x, y;
    double p = 0.0, c = 0.0, l = 0.0, m = 0.0, f = 0.0, d = 0.0;

    int XVal[] = {-1, -1, 0, 1, 1, 1, 0, -1};
    int YVal[] = {0, 1, 1, 1, 0, -1, -1, -1};
    int V[8][8] = 	{ { 20, -3, 11, 8, 8, 11, -3, 20 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 20, -3, 11, 8, 8, 11, -3, 20 } };

    for(i = 0; i < 8; i++)
        for(j = 0; j < 8; j++)  {
            if(gameGrid[i][j] == col)  {
                d += V[i][j];
                tls++;
            } else if(gameGrid[i][j] == opCol)  {
                d -= V[i][j];
                opTls++;
            }

            if(gameGrid[i][j] != 'e') {
                for(k = 0; k < 8; k++) {
                    x = i + XVal[k]; y = j + YVal[k];
                    if(x >= 0 && x < 8 && y >= 0 && y < 8 && gameGrid[x][y] == 'e') {
                        if(gameGrid[i][j] == col) /* ------>> */ frTls++;
                        else                  /* ------>> */ opFrTls++;
                        break;
                    }
                }
            }
        }

    if(tls > opTls) p = (100.0 * tls)/(tls + opTls);
    else if(tls < opTls) p = -(100.0 * opTls)/(tls + opTls);

    if(frTls > opFrTls) f = -(100.0 * frTls)/(frTls + opFrTls);
    else if(frTls < opFrTls) f = (100.0 * opFrTls)/(frTls + opFrTls);

    tls = opTls = 0;
    if(gameGrid[0][0] == col)           /* ------>> */    tls++;
    else if(gameGrid[0][0] == opCol)    /* ------>> */    opTls++;

    if(gameGrid[0][7] == col)           /* ------>> */    tls++;
    else if(gameGrid[0][7] == opCol)    /* ------>> */    opTls++;

    if(gameGrid[7][0] == col)            /* ------>> */   tls++;
    else if(gameGrid[7][0] == opCol)     /* ------>> */   opTls++;

    if(gameGrid[7][7] == col)           /* ------>> */    tls++;
    else if(gameGrid[7][7] == opCol)     /* ------>> */   opTls++;

    c = 25 * (tls - opTls);

    tls = opTls = 0;
    if(gameGrid[0][0] == 'e')   {
        if(gameGrid[0][1] == col)         /* ------>> */  tls++;
        else if(gameGrid[0][1] == opCol)  /* ------>> */  opTls++;

        if(gameGrid[1][1] == col)          /* ------>> */ tls++;
        else if(gameGrid[1][1] == opCol)   /* ------>> */ opTls++;

        if(gameGrid[1][0] == col)        /* ------>> */   tls++;
        else if(gameGrid[1][0] == opCol)  /* ------>> */  opTls++;
    }

    if(gameGrid[0][7] == 'e')   {
        if(gameGrid[0][6] == col)       /* ------>> */    tls++;
        else if(gameGrid[0][6] == opCol)  /* ------>> */  opTls++;

        if(gameGrid[1][6] == col)         /* ------>> */  tls++;
        else if(gameGrid[1][6] == opCol)  /* ------>> */  opTls++;

        if(gameGrid[1][7] == col)         /* ------>> */  tls++;
        else if(gameGrid[1][7] == opCol)   /* ------>> */ opTls++;
    }

    if(gameGrid[7][0] == 'e')   {
        if(gameGrid[7][1] == col)         /* ------>> */  tls++;
        else if(gameGrid[7][1] == opCol)   /* ------>> */ opTls++;

        if(gameGrid[6][1] == col)          /* ------>> */ tls++;
        else if(gameGrid[6][1] == opCol)  /* ------>> */  opTls++;

        if(gameGrid[6][0] == col)         /* ------>> */  tls++;
        else if(gameGrid[6][0] == opCol)  /* ------>> */  opTls++;
    }

    if(gameGrid[7][7] == 'e')   {
        if(gameGrid[6][7] == col)        /* ------>> */   tls++;
        else if(gameGrid[6][7] == opCol)  /* ------>> */  opTls++;

        if(gameGrid[6][6] == col)         /* ------>> */  tls++;
        else if(gameGrid[6][6] == opCol)  /* ------>> */  opTls++;

        if(gameGrid[7][6] == col)         /* ------>> */  tls++;
        else if(gameGrid[7][6] == opCol)  /* ------>> */  opTls++;
    }
    l = -10 * (tls - opTls);

    tls = numValidMoves(col, opCol, gameGrid);
    opTls = numValidMoves(opCol, col, gameGrid);

    if(tls > opTls)          /* ------>> */   m = (100.0 * tls)/(tls + opTls);
    else if(tls < opTls)     /* ------>> */   m = -(100.0 * opTls)/(tls + opTls);

    double score = (11 * p) + (850.724 * c) + (382.026 * l) + (86.922 * m) + (78.396 * f) + (10 * d);

    return score;
}

double testMyMove(OthelloBoard board, Move move, Turn t, short level, double alpha, double beta) {

    fClock = clock();

    if(((double)(fClock-sClock)/CLOCKS_PER_SEC)>1.95) {
        if(level&1) /* ------>> */ /* ------>> *//* ------>> */return -INFINITY_VAL;
        return INFINITY_VAL;
    }

	if(level == 6) {
		char gameGrid[8][8];
		for(int i=0;i<8;i++) {
			for(int j=0;j<8;j++) {
				Coin findTurn = board.get(i,j);
				if(findTurn == t) /* ------>> */            gameGrid[i][j] = 'y';
				else if(findTurn == other(t)) /* ------>> */gameGrid[i][j] = 'm';
				else  /* ------>> *//* ------>> */          gameGrid[i][j] = 'e';
			}
		}

		return othelloBoardEvaluator(gameGrid);
	}

	board.makeMove(t,move);
	t = other(t);
	list<Move> newMoves = board.getValidMoves(t);
	list<Move>::iterator iter = newMoves.begin();
	double ret = -INFINITY_VAL;

	if(level&1)              /* ------>> *//* ------>> */      ret *= -1;
	if(!(newMoves.size()))   /* ------>> */                    return ret;

	for(;iter!=newMoves.end();iter++) {
		double curr = testMyMove(board,*iter,t,level+1,alpha,beta);
		if(level&1) {
			ret = min(ret,curr);
			beta = min(beta,ret);
		}
		else {
			ret = max(ret,curr);
			alpha = max(alpha,ret);		
		}
		if(beta<=alpha)             /* ------>> */             break;
	}

	return ret; 
}

double tester(OthelloBoard board,Turn turn) {
    char grid[8][8];

    for(int i=0;i<8;i++) {
        for(int j=0;j<8;j++) {
        Coin findTurn = board.get(i,j);
        if(findTurn == turn) grid[i][j] = 'm';
        else if(findTurn == other(turn)) grid[i][j] = 'y';
        else grid[i][j] = 'e';
        }
    }

    return othelloBoardEvaluator(grid);
}

bool compare(Move a, Move b) {
    OthelloBoard firstOne = Board,secondTwo = Board;
    firstOne.makeMove(myTurn, a);
    secondTwo.makeMove(myTurn, b);
    return tester(firstOne,myTurn) > tester(secondTwo,myTurn);
}

class MyBot: public OthelloPlayer {
    public:
        MyBot(Turn turn);
        virtual Move play(const OthelloBoard& board);
    private:
};

MyBot::MyBot(Turn turn) : OthelloPlayer(turn) {}

Move MyBot::play(const OthelloBoard& b) {
    sClock = clock();
    list<Move> mv = b.getValidMoves( turn );
    myTurn = turn;
    Board = b;
    mv.sort(compare);
    list<Move>::iterator it = mv.begin();
    Move bestMove((*it).x,(*it).y);
    double retVal = -INFINITY_VAL;
    double MAX = INFINITY_VAL, MIN = -INFINITY_VAL;
    OthelloBoard cb = b;
    short level = 1;

    while(it!=mv.end()) {
    	double cur = testMyMove(cb, *it, turn, level, MIN,MAX);
    	if(cur > retVal) retVal = cur, bestMove = *it;
    	cb = b;
        it++;
    }

    return bestMove;
}


extern "C" {
    OthelloPlayer* createBot(Turn turn) {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer* bot) {
        delete bot;
    }
}