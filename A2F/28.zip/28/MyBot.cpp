#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <bits/stdc++.h>

using namespace std;
using namespace Desdemona;

clock_t start,finish;

class Oath{
    public:
    static int getRedScore(OthelloBoard b) {
        return b.getRedCount();
    }
    static int getBlackScore(OthelloBoard b) {
        return b.getBlackCount();
    }
}; 

class xOath{
    public:
    static int getRedScore(OthelloBoard b) {
        int score = 0;
        for(int i = 0; i < 8; i++) {
            for(int j = 0; j < 8; j++) {
                if(b.get(i, j) == RED) {
                    int x1= 1,x2=1;
                    if(i == 0 || i == 7) x1= 4;
                    if(j == 0 || j == 7) x2= 4;
                    score += (x1*x2);
                }
            }
        }
        return score;
    }
    static int getBlackScore(OthelloBoard b) {
        int score = 0;
        for(int i = 0; i < 8; i++) {
            for(int j = 0; j < 8; j++) {
                if(b.get(i, j) == BLACK) {
                    int x1= 1,x2=1;
                    if(i == 0 || i == 7) x1= 4;
                    if(j == 0 || j == 7) x2= 4;
                    score += (x1*x2);
                }
            }
        }
        return score;
    }
}; 

class GNode {
    public:
    OthelloBoard board;
    Move move;
    Turn mPlayer;
    GNode(GNode* p, OthelloBoard b, Turn pPlayer) : move(-1,-1) {
        board = b;
        mPlayer = pPlayer;
    }
};

class AlphaBeta {
    static const int MAX_DEPTH = 7;
    public:
    static Move playbyGT(OthelloBoard board, Turn turn) {
        start = clock();
        int alpha = INT16_MIN, beta = INT16_MAX;
        list<Move> valid_moves = board.getValidMoves(turn);
        Move curr(-1,-1);
        if(valid_moves.size()>0) curr= *valid_moves.begin();
        GNode* root_node = new GNode(NULL, board, turn);

        for(auto i = valid_moves.begin(); i != valid_moves.end(); i++){
            OthelloBoard next_board = board;
            next_board.makeMove(turn, *i);
            finish = clock() - start;
            if(((double)finish)/CLOCKS_PER_SEC >1.85) return curr;
            int val = playRec(next_board, root_node, true, MAX_DEPTH-1, alpha, beta);
            if(val>alpha) {
                alpha = val;
                curr = *i;
                if(alpha >= beta) return curr;
            }
        }
        return curr;
    }

    static int playRec(OthelloBoard board, GNode* p, bool ismin, int depth, int alpha, int beta) {
        GNode* node = new GNode(p,board, p->mPlayer);
        if(depth==0){
            if((node->mPlayer == RED)) return xOath().getRedScore(board)-xOath().getBlackScore(board);
            else return xOath().getBlackScore(board)-xOath().getRedScore(board);
        }
        Turn t = p->mPlayer;
        if(ismin) t = (p->mPlayer == BLACK)? RED: BLACK;
        list<Move> valid_moves = board.getValidMoves(t);
    
        if(valid_moves.size() == 0) {
            if(!ismin) t = (p->mPlayer == BLACK)? RED: BLACK;
            else t = p->mPlayer;
            ismin = !ismin;
            list<Move> valid_moves = board.getValidMoves(t);
            if(valid_moves.size() == 0) return playRec(board,node, ismin, 0, alpha, beta); 
            for (auto i = valid_moves.begin(); i != valid_moves.end(); i++) {
                OthelloBoard next_board = board;
                next_board.makeMove(t, *i);
                int v = playRec(next_board, node, !ismin, depth-1, alpha, beta);
                if(ismin) {
                    beta = min(v,beta);
                    if(alpha >= beta) return alpha;
                } 
                else {
                    alpha = min(v,alpha);
                    if (alpha >= beta) return beta;
                }
            }
        }
        for (auto i = valid_moves.begin(); i != valid_moves.end(); i++) {
            OthelloBoard next_board = board;
            next_board.makeMove(t, *i);
            int v = playRec(next_board, node, !ismin, depth-1, alpha, beta);
            if(ismin) {
                beta = min(v,beta);
                if(alpha >= beta) return alpha;
            } 
            else {
                alpha = max(v,alpha);
                if (alpha >= beta) return beta;
            }
        }  
        return ismin?beta:alpha;
    }
};

class MyBot: public OthelloPlayer{
    public:
        MyBot( Turn turn );
        virtual Move play( const OthelloBoard& board );
    private:
};
MyBot::MyBot( Turn turn ): OthelloPlayer(turn){
}
Move MyBot::play( const OthelloBoard& board ){
    Move m = AlphaBeta().playbyGT(board, turn);
    return m;
}
extern "C" {
    OthelloPlayer* createBot( Turn turn ){
        return new MyBot( turn );
    }
    void destroyBot( OthelloPlayer* bot ){
        delete bot;
    }
}