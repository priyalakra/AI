/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <queue>
#include <tuple>
#include <map>
#include <chrono>

using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */

        const static int MAX_DEPTH = 7;
        MyBot( Turn turn );

        /**
         * Play something 
         */
        int Static_Weights_heuristic[8][8] = 	{ { 20, -3, 11, 8, 8, 11, -3, 20 },
                                            { -3, -7, -4, 1, 1, -4, -7, -3 },
                                            { 11, -4, 2, 2, 2, 2, -4, 11 },
                                            { 8, 1, 2, 0, 0, 2, 1, 8 },
                                            { 8, 1, 2, 0, 0, 2, 1, 8 },
                                            { 11, -4, 2, 2, 2, 2, -4, 11 },
                                            { -3, -7, -4, 1, 1, -4, -7, -3 },
                                            { 20, -3, 11, 8, 8, 11, -3, 20 } };
        virtual Move play( const OthelloBoard& board );
        
        int eval(const OthelloBoard &board);
        
        int alpha_beta(OthelloBoard &board, int alpha, int beta, Turn t, int depth);
        int SSS_star(OthelloBoard& currBoard, Turn t);
        
    private:
};

class PQNode
{
    // tuple<h_value, status(LIVE/SOLVED), node, nodeType(max/min), parent>
    public:
        int h;
        bool status;
        bool nodeType;
        OthelloBoard node;
        OthelloBoard parent;
        int childNo;
        int childCount;

        PQNode(int h_val, bool status, bool nodeType, OthelloBoard& node, OthelloBoard& parent)
        {
            this->h = h_val;
            this->status = status;
            this->nodeType = nodeType;
            this->node = node;
            this->parent = parent;
        }

};
struct compare
{
    bool operator()(const PQNode& a, const PQNode& b)
    {
        if(a.h != b.h) return a.h<b.h;

        // h_val are same
        if(a.status != b.status) return a.status < b.status;
        return a.nodeType < b.nodeType;
    }
};


MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
    this->turn = turn;
}

Move MyBot::play( const OthelloBoard& board )
{
    list<Move> moves = board.getValidMoves( turn );
    // int randNo = rand() % moves.size();
    list<Move>::iterator it = moves.begin();
    list<Move>::iterator bestMoveIt = moves.begin();
    clock_t start_time = clock();
    int alpha = INT32_MIN;
    int beta = INT32_MAX;
    // int best_val = -64;
    while(it != moves.end() && clock()-start_time < 2)
    {
        OthelloBoard mindBoard = board;
        mindBoard.makeMove(turn, *it);
        
        Turn nextTurn;
        if(turn == BLACK) nextTurn = RED;
        else nextTurn = BLACK;
        int ret = alpha_beta(mindBoard, alpha, beta, nextTurn, 0);
        if(ret >= alpha)
        {
            alpha = ret;
            bestMoveIt = it;
        }
    }
    
    return *bestMoveIt;
}

int MyBot::alpha_beta(OthelloBoard &board, int alpha, int beta, Turn t, int depth)
{
    if(depth == MAX_DEPTH) return eval(board);

    list<Move> nextMoves = board.getValidMoves(t);
    if(nextMoves.size() == 0)
    {
        // check whether it is a terminal node
        return eval(board);
    }

    if(t == turn)
    {
        // max node
        list<Move>::iterator it = nextMoves.begin();
        for(int i=0; i < (int)nextMoves.size(); it++, i++)
        {
            OthelloBoard mindBoard = board;
            mindBoard.makeMove(t , *it);
            Turn nextTurn;
            if(t == BLACK) nextTurn = RED;
            else nextTurn = BLACK;
            int ret = alpha_beta(mindBoard, alpha, beta, nextTurn, depth+1);
            if(alpha < ret) alpha = ret;
            if(alpha >= beta) return beta;
        }
        return alpha;
    }
    else
    {
        // min node
        list<Move>::iterator it = nextMoves.begin();
        for(int i=0; i < (int)nextMoves.size(); it++, i++)
        {
            OthelloBoard mindBoard = board;
            mindBoard.makeMove(t , *it);
            Turn nextTurn;
            if(t == BLACK) nextTurn = RED;
            else nextTurn = BLACK;
            int ret = alpha_beta(mindBoard, alpha, beta, nextTurn, depth+1);
            if(beta > ret) beta = ret;
            if(alpha >= beta) return alpha;
        }
        return beta;
    }
}

int MyBot::SSS_star(OthelloBoard& currBoard, Turn t)
{
    // this function is called starting from next step, so first node is min node

    // tuple<h_value, status(LIVE/SOLVED), node, nodeType(max/min), parent>
    // Status = true => solved
    //          false => live
    // nodeType = true => Max 
    //           false => Min
    int redCount = currBoard.getRedCount();
    int blackCount = currBoard.getBlackCount();
    
    priority_queue<PQNode, vector<PQNode>, compare> open;
    PQNode node = PQNode(65, false, false, currBoard, currBoard);

    open.push(node);
    while (!open.empty())
    {
        PQNode currNode = open.top();
        open.pop();
        
        int boardStateRed = currNode.node.getRedCount();
        int boardStateBlack = currNode.node.getBlackCount();

        Turn currTurn;
        if(currNode.nodeType == true) currTurn = turn;
        else
        {
            if(turn == BLACK) currTurn = RED;
            else currTurn = BLACK;
        }

        if((redCount == boardStateRed && blackCount == boardStateBlack) && (currNode.status == true))
        {
            return currNode.h;
        }

        else if(currNode.status == false)
        {
            // live node
            list<Move> nextMoves = currNode.node.getValidMoves(currTurn);
            list<Move>::iterator it = nextMoves.begin();
            if(nextMoves.size() == 0)
            {
                int evalNode = eval(currNode.node);
                PQNode child = PQNode(min(evalNode, currNode.h),
                                        true, currNode.nodeType, currNode.node,
                                        currNode.parent);
                open.push(child);
                // open.push(make_tuple(h_val, true, boardState, nodeType, parent));
            }
            else if(currNode.nodeType)
            {
                // max node
                for(int i=0; i < (int)nextMoves.size(); it++, i++)
                {
                    OthelloBoard mindBoard = currNode.node;
                    mindBoard.makeMove(currTurn, *it);
                    PQNode child = PQNode(currNode.h,
                                        false, false, mindBoard,
                                        currNode.node);
                    open.push(child);
                    // open.push(make_tuple(currNode.h, false, mindBoard, !currNode.nodeType, boardState));
                }
            }
            else
            {
                OthelloBoard mindBoard = currNode.node;
                mindBoard.makeMove(currTurn, *it);
                PQNode child = PQNode(currNode.h,
                                    false, true, mindBoard,
                                    currNode.node);
                open.push(child);
            }
        }
        else
        {
            // solved node
            if(currNode.nodeType)
            {
                // if()
            }
        }
    }
    
    return 0;
}

int MyBot::eval(const OthelloBoard &board)
{
    // int black = board.getBlackCount();
    // int red = board.getRedCount();
    // if(turn == BLACK)
    // {
    //     return black - red;
    // }
    // else return red-black;

    int map[8][8];
    for(int i=0;i<8;i++)
    {
        for(int j=0;j<8;j++)
        {
            Coin get_color = board.get(i,j);
            if(get_color == turn) map[i][j] = 1;
            else if(get_color == other(turn)) map[i][j] = 2;
            else map[i][j] = 0;
        }
    }
    //All the values obtained from different evaluation methods are added into val.
    double val=0.0,temp_var=0.0;
    //Each spot on the board is given some weight signifying how valuable that spot is.
    

	// Different startegic positions have different weights
    int i,j,k,x,y;
    int max_count = 0, min_count = 0, max_front = 0, min_front = 0;
    int rows[] = {-1, -1, 0, 1, 1, 1, 0, -1};
    int cols[] = {0, 1, 1, 1, 0, -1, -1, -1};
    for(i = 0; i < 8; i++)
        for(j = 0; j < 8; j++)  {
            if(map[i][j] == 1)  {
                temp_var += Static_Weights_heuristic[i][j];
                max_count++;
            } 
            else if(map[i][j] == 2)  {
                temp_var -= Static_Weights_heuristic[i][j];
                min_count++;
            }
            if(map[i][j] != 0)   {
                for(k = 0; k < 8; k++)  {
                    x = i + rows[k]; y = j + cols[k];
                    if(x >= 0 && x < 8 && y >= 0 && y < 8 && map[x][y] == 0) {
                        if(map[i][j] == 1)  max_front++;
                        else min_front++;
                        break;
                    }
                }
            }
        }
    val+=10*temp_var;
    temp_var=0.0;

    if(max_count > min_count){
        temp_var = 11*((100.0 * max_count)/(max_count + min_count));
    }
    else if(max_count < min_count){
        temp_var = -11*((100.0 * min_count)/(max_count + min_count));
    }
    if(max_front > min_front){
        temp_var += -78.396*((100.0 * max_front)/(max_front + min_front));
    }
    else if(max_front < min_front){
        temp_var += 78.396*((100.0 * min_front)/(max_front + min_front));
    }
    val+=temp_var;

    // Corner related metrics are coded below
    max_count = min_count = 0;
    if(map[0][0] == 1){
        max_count++;
    }
    else if(map[0][0] == 2){
        min_count++;
    }

    if(map[0][7] == 1){
        max_count++;
    }
    else if(map[0][7] == 2){
        min_count++;
    }

    if(map[7][0] == 1){
        max_count++;
    }
    else if(map[7][0] == 2){
        min_count++;
    }

    if(map[7][7] == 1){
        max_count++;
    }
    else if(map[7][7] == 2){
        min_count++;
    }
    val += 850.724*(25*(max_count - min_count));

    max_count = min_count = 0;
    if(map[0][0] == 0)   {
        if(map[0][1] == 1) max_count++;
        else if(map[0][1] == 2) min_count++;
        if(map[1][1] == 1) max_count++;
        else if(map[1][1] == 2) min_count++;
        if(map[1][0] == 1) max_count++;
        else if(map[1][0] == 2) min_count++;
    }
    if(map[0][7] == 0)   {
        if(map[0][6] == 1) max_count++;
        else if(map[0][6] == 2) min_count++;
        if(map[1][6] == 1) max_count++;
        else if(map[1][6] == 2) min_count++;
        if(map[1][7] == 1) max_count++;
        else if(map[1][7] == 2) min_count++;
    }
    if(map[7][0] == 0)   {
        if(map[7][1] == 1) max_count++;
        else if(map[7][1] == 2) min_count++;
        if(map[6][1] == 1) max_count++;
        else if(map[6][1] == 2) min_count++;
        if(map[6][0] == 1) max_count++;
        else if(map[6][0] == 2) min_count++;
    }
    if(map[7][7] == 0)   {
        if(map[6][7] == 1) max_count++;
        else if(map[6][7] == 2) min_count++;
        if(map[6][6] == 1) max_count++;
        else if(map[6][6] == 2) min_count++;
        if(map[7][6] == 1) max_count++;
        else if(map[7][6] == 2) min_count++;
    }
    val += -3820.26*(max_count-min_count);

    // Mobility of the current position
    list<Move> max_moves=board.getValidMoves(turn);
    list<Move> min_moves=board.getValidMoves(other(turn));
    max_count = max_moves.size();
    min_count = min_moves.size();
    if(max_count > min_count){
        val += 86.922*((100.0 * max_count)/(max_count + min_count));
    }
    else if(max_count < min_count){
        val += -86.922*((100.0 * min_count)/(max_count + min_count));
    }

    return val;
}


// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


