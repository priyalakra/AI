
#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <bits/stdc++.h>
using namespace std;
using namespace Desdemona;

#define INTMAX 1e6
#define INTMIN -1e6
struct Node {
	bool type;
	int height = 0;
	OthelloBoard Board;
};


std::vector <int> corners = {0,7,56,63};
vector <vector <int> > adj ={ {1,8,9}, {6,13,14}, {48,49,57},{55,62,54}};
clock_t start_t,end_t;
bool flag = false;
Turn MAXNODE;
Turn MINNODE;
class MyBot: public OthelloPlayer
{
    public:
        MyBot( Turn turn );

        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
	: OthelloPlayer( turn )
{
}
float WeightFactor(Coin* grid, Turn turnn) {
    double BC = 0, WC =0;
    for(int iii = 0; iii < 4;iii++){
	if(*(grid + corners[iii]) != EMPTY)
	continue;
        for(int ii = 0; ii < adj[iii].size() ;ii++){
                if(*(grid+adj[iii][ii]) == EMPTY)
                        ;
                else if(*(grid+adj[iii][ii]) == BLACK)
                        BC++;
                else WC++;
        }
    }
    if(turnn == BLACK){
                return -12.5 * (BC - WC);
        }
        else return -12.5 * (WC-BC);


}
float heu(OthelloBoard board,bool turnn) {
		float a,b,c,d;
		if(board.getRedCount() > board.getBlackCount())
			a = 100*(float)(board.getRedCount())/(float)(board.getRedCount()+board.getBlackCount());
		else if(board.getRedCount() < board.getBlackCount())
			a = -100*(float)(board.getBlackCount())/(float)(board.getRedCount()+board.getBlackCount());
		else
			a = 0;
		
		int bl = 0;
        int rd = 0;
		if(board.get(0,0) == BLACK|| board.get(0,7)==BLACK || board.get(7,0) == BLACK || board.get(7,7) == BLACK) {
			bl+=1;
        }

		if(board.get(0,0) == RED || board.get(0,7) == RED || board.get(7,7) == RED || board.get(7,0) == RED) {
			rd+=1;
        }
		b = 25*(float)(rd-bl);
		list <Move> moves1 = board.getValidMoves(RED);
		list <Move> moves2 = board.getValidMoves(BLACK);
        float temp;
        int flag=0;
        temp = max(moves1.size(), moves2.size());
        if(moves1.size()==moves2.size()){
            flag=1;
        }
        if(moves1.size() > moves2.size()) {
            flag=-1;
        }
        float sum;
        sum = (float)(moves1.size()+moves2.size());
        if(flag==-1){
            c=100*(float)(moves1.size())/sum;
        }
        else if(flag==1){
            c=-100*(float)(moves2.size())/sum;
        }
        else if(flag==0){
            c=0;
        }
        
		d = 0;
        Coin grid1[8][8];
        OthelloBoard b1=board;
        for(int ii = 0; ii < 8 ;ii++)
            for(int jj = 0; jj < 8 ;jj++)
                grid1[ii][jj] = b1.get(ii,jj);
        Turn turn_temp;
        if(turnn==0) {
            turn_temp=RED;
        }
        else {
            turn_temp=BLACK;
        }
		d = WeightFactor(&grid1[0][0], turn_temp);
        float val;
        val= (10*a+801.724*b+78.922*c+382.026*d);
	if(turnn) {
		return (-1)*val;
	}
	return val;
}
float AlphaBetaPrune(Node N,float alpha,float beta,int maxDepth) {
	end_t = clock();
	float tot = (float)(end_t-start_t)/CLOCKS_PER_SEC;
	if(tot > 1.95) {
		flag = true;
		if(MAXNODE == BLACK)
			return alpha;
		else
			return beta;
	}
		
	if(N.height == maxDepth) {
		TERMINAL:
		if(MAXNODE == BLACK)
			return heu(N.Board,1);
		else
			return heu(N.Board,0); 
	}
	else {
		if(N.type == 1) {
			OthelloBoard B = N.Board;
			list<Move> moves = B.getValidMoves(MAXNODE);
			list<Move>::iterator it;
			if (moves.size() == 0)
				goto TERMINAL;
			for(it = moves.begin();it!=moves.end();++it) {
				B.makeMove(MAXNODE,*it);
				Node n1;
				n1.Board = B;
				n1.type = 0;
				n1.height = N.height+1;
				alpha = max(alpha,AlphaBetaPrune(n1,alpha,beta,maxDepth));
				/*if(flag == true)
					return beta;*/
				if(alpha >= beta)
					return beta;
				B = N.Board;
			}
			return alpha;
		}
		else {
			OthelloBoard B = N.Board;
			list<Move> moves = B.getValidMoves(MINNODE);
			list<Move>::iterator it;
			if (moves.size() == 0)
				goto TERMINAL;
			for(it = moves.begin();it!=moves.end();++it) {
				B.makeMove(MINNODE,*it);
				Node n1;
				n1.Board = B;
				n1.type = 1;
				n1.height = N.height+1;
				beta = min(beta,AlphaBetaPrune(n1,alpha,beta,maxDepth));
				/*if(flag == true)
					return alpha;*/
				if(alpha >= beta)
					return alpha;
				B = N.Board;
			}
			return beta;
		}
	}
	
}
bool check(Move m) {
	
	if((m.x == 0 && m.y == 0)||(m.x == 0 && m.y == 7)||(m.x == 7 && m.y == 0)||(m.x == 7 && m.y == 7))
		return true;
    else {
	    return false;
    }
}
Move MyBot::play(const OthelloBoard& board)
{
	flag = false;
	srand(time(NULL));
	start_t = clock();
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it;
    list<Move>::iterator ITmax = moves.begin();
    OthelloBoard btemp = board;
    float maxval = INTMIN;
    if(turn == RED) {
    	MAXNODE = RED;
    	MINNODE = BLACK;
    }
    else {
        MAXNODE = BLACK;
    	MINNODE = RED;
    }
    int ht;
    float alpha = INTMIN;
    float beta = INTMAX;
    for(ht = 4;ht<=7;ht++) {
    	alpha = INTMIN;
    	ITmax = moves.begin();
    	maxval = INTMIN;

    	for(it = moves.begin();it!=moves.end();++it) {
        	btemp.makeMove(turn,*it);
        	if(check(*it))
        		return *it;
        	float ans;
        	Node n1;
        	n1.height = 0;
        	n1.type = 0;
        	n1.Board = btemp;	
        	ans = AlphaBetaPrune(n1,alpha,beta,ht);
        	alpha = max(ans,alpha);
        	if(ans > maxval) {
        		maxval = ans;
        		ITmax = it;
        	}
        	if(flag == true)
        		return *ITmax;
     
        	btemp = board;
		}
	}
    return *ITmax;
}

// The following lines are _very_ important to create a bot module for Desdemona
extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


