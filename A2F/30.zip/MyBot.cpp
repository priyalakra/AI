#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>
using namespace std;
using namespace Desdemona;






/*
*
*Values taken from the Research paper of University of Washington.
*
*/

#define INF 1e18
OthelloBoard globalBoard;
Turn my;

clock_t start,finish;



bool issafe(char self, char opp, char *str)  {
	if (str[0] != opp) return false;
    int ctr=1;
    while(ctr<8)
    {
      if (str[ctr] == 'e')
      { 
        return false;  
      }
      if (str[ctr] == self)
      {
         return true;
      }
      ctr+=1;
    }
	return false;
}

bool isLegalMove(char self, char opp, char grid[8][8], int startx, int starty)   {
	if (grid[startx][starty] != 'e') return false;
	char str[10];
	int x, y ;
    int x_d, y_d, i;
    x_d=-1;
    y_d=-1;
    i=1;

    while(y_d<=1)
    {
        while(x_d<=1)
        {
            if (!y_d && !x_d) continue;
            str[0] = '\0';
            while(i<8)
            {
                y = starty + i*y_d;
                x = startx + i*x_d;
                if (x >= 0 && y >= 0 && x<8 && y<8) str[i-1] = grid[x][y];
				else str[i-1] = 0;
                i+=1;
            }
            if (issafe(self, opp, str)) return true;
            x_d+=1;
        }
        y_d+=1;
        return false;
    }

}



double othelloBoardEvaluator(char grid[8][8])  {
	char user_colour = 'm';
    char bot_colour = 'y';
    int userTile = 0, botTiles = 0, i, j, k, userFrontTiles = 0, botFrontTiles = 0, x, y;
    double p = 0.0;
    double c = 0.0;
    double l = 0.0;
    double m = 0.0;
    double f = 0.0;
    double d = 0.0;

    int X1[] = {-1, -1, 0, 1, 1, 1, 0, -1};
    int Y1[] = {0, 1, 1, 1, 0, -1, -1, -1};
    int V[8][8] = 	{ { 20, -3, 11, 8, 8, 11, -3, 20 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 20, -3, 11, 8, 8, 11, -3, 20 } };

    for(i = 0; i < 8; i++)
        for(j = 0; j < 8; j++)  {
            if(grid[i][j] == user_colour)  {
                d += V[i][j];
                userTile++;
            } 
            else if(grid[i][j] == bot_colour)  {
                d -= V[i][j];
                botTiles++;
            }
            if(grid[i][j] != 'e')   {
                for(k = 0; k < 8; k++)  {
                    x = i + X1[k]; y = j + Y1[k];
                    if(x >= 0 && x < 8 && y >= 0 && y < 8 && grid[x][y] == 'e') {
                        if(grid[i][j] == user_colour)  userFrontTiles++;
                        else botFrontTiles++;
                        break;
                    }
                }
            }
        }

    int qued=(userTile + botTiles);
    if(userTile > botTiles) p = (100.0 * userTile)/qued;
    else if(userTile < botTiles) p = -(100.0 * botTiles)/qued;
    int roddr=(userFrontTiles + botFrontTiles);
    if(userFrontTiles < botFrontTiles) f = (100.0 * userFrontTiles)/roddr;
    else if(userFrontTiles > botFrontTiles) f = -(100.0 * botFrontTiles)/roddr;

    userTile = botTiles = 0;

        
    int a=[[0,0],[0,7],[7,0],[7,7]];
    for (int i=0;i<3;i++)
    {
        int x=a[i][0];
        int y=a[i][1];
        if(grid[x][y] == user_colour) userTile++;
        else if(grid[x][y] == bot_colour) botTiles++;
    }

    c = 25 * (userTile - botTiles);

    userTile = botTiles = 0;
    int a=[[0,1],[1,1],[1,0]];
    for (int i=0;i<3;i++)
    {
        int x=a[i][0];
        int y=a[i][1];
        if(grid[x][y] == user_colour) userTile++;
        else if(grid[x][y] == bot_colour) botTiles++;
    }
    if (grid[0][7] == 'e')
    {
        int a=[[0,6],[1,6],[1,7]];
        for (int i=0;i<3;i++)
        {
            int x=a[i][0];
            int y=a[i][1];
            if(grid[x][y] == user_colour) userTile++;
            else if(grid[x][y] == bot_colour) botTiles++;
        }
    }

    if (grid[7][0] == 'e')
    {
        int a=[[7,1],[6,1],[6,0]];
        for (int i=0;i<3;i++)
        {
            int x=a[i][0];
            int y=a[i][1];
            if(grid[x][y] == user_colour) userTile++;
            else if(grid[x][y] == bot_colour) botTiles++;
        }
    }

    if (grid[7][7] == 'e')
    {
        int a=[[6,7],[6,6],[7,6]];
        for (int i=0;i<3;i++)
        {
            int x=a[i][0];
            int y=a[i][1];
            if(grid[x][y] == user_colour) userTile++;
            else if(grid[x][y] == bot_colour) botTiles++;
        }
    }

    l = -10 * (userTile - botTiles);


    int count = 0, i, j;
	for(i = 0; i < 8; i++)
    {
        for(j = 0; j < 8; j++){
            if(isLegalMove(user_colour, bot_colour, grid, i, j)) count++;
        }
    }
	userTile =  count;

    int count = 0, i, j;
	for(i = 0; i < 8; i++)
    {
        for(j = 0; j < 8; j++){
            if(isLegalMove(bot_colour, user_colour, grid, i, j)) count++;
        }
    }
	botTiles =  count;
    int paperr=(userTile + botTiles);



    if(userTile < botTiles) m = -(100.0 * botTiles)/paperr;
    else if(userTile > botTiles) m = -(100.0 * userTile)/paperr;

    return (382.026 * l) + (11 * p) + (78.396 * f) + (10 * d) + (850.724 * c) + (86.922 * m);
}

double testMyMove(OthelloBoard board, Move move, Turn turn, short level, double alpha, double beta) {
    finish = clock();
    if(((double)(finish-start)/CLOCKS_PER_SEC)>1.95) {
        if(level&1) return -INF;
        return INF;
    }
	if(level == 6) {
		char grid[8][8];
		for(int i=0;i<8;i++) {
			for(int j=0;j<8;j++) {
				Coin findTurn = board.get(i,j);
				if(findTurn == turn) grid[i][j] = 'y';
				else if(findTurn == other(turn)) grid[i][j] = 'm';
				else grid[i][j] = 'e';
			}
		}
		return othelloBoardEvaluator(grid);
	}
	board.makeMove(turn,move);
	turn = other(turn);
	list<Move> newMoves = board.getValidMoves(turn);
	list<Move>::iterator iter = newMoves.begin();
	double ret = -INF;
	if(level&1) ret *= -1;
	if(!(newMoves.size())) return ret;
	for(;iter!=newMoves.end();iter++) {
		double curr = testMyMove(board,*iter,turn,level+1,alpha,beta);
		if(level&1) {
			ret = min(ret,curr);
			beta = min(beta,ret);
		}
		else {
			ret = max(ret,curr);
			alpha = max(alpha,ret);		
		}
		if(beta<=alpha) break;
	}
	return ret; 
}

double tester(OthelloBoard board,Turn turn) {
    char grid[8][8];
    for(int i=0;i<8;i++) {
        for(int j=0;j<8;j++) {
        Coin findTurn = board.get(i,j);
        if(findTurn == turn) grid[i][j] = 'm';
        else if(findTurn == other(turn)) grid[i][j] = 'y';
        else grid[i][j] = 'e';
        }
    }
    return othelloBoardEvaluator(grid);
}

bool compare(Move a, Move b) {
    OthelloBoard One = globalBoard,Two = globalBoard;
    One.makeMove(my,a);
    Two.makeMove(my,b);
    return tester(One,my)>tester(Two,my);
}

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    start = clock();
    list<Move> moves = board.getValidMoves( turn );
    my = turn;
    globalBoard = board;
    moves.sort(compare);
    list<Move>::iterator it = moves.begin();
    Move bestMove((*it).x,(*it).y);
    double retVal = -INF;
    double MAX = INF, MIN = -INF;
    OthelloBoard copyBoard = board;
    short level = 1;
    for(;it!=moves.end();it++) {
    	double currValue = testMyMove(copyBoard,*it,turn,level,MIN,MAX);
    	if(currValue > retVal) {
    		retVal = currValue;
    		bestMove = *it;
    	}
    	copyBoard = board;
    }
    return bestMove;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}