

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <time.h>
using namespace std;
using namespace Desdemona;

class MyBot : public OthelloPlayer
{
public:
    /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
    MyBot(Turn turn);

    /**
         * Play something 
         */
    virtual Move play(const OthelloBoard &board);
    virtual int AlphaBeta(const OthelloBoard &board, int depth, int alpha_min, int beta_max);
    virtual int heuristic(const OthelloBoard &board, Turn turn);
    int move_num = 0;
    Turn my_color;

private:
};

MyBot::MyBot(Turn turn)
    : OthelloPlayer(turn)
{
}


/*
Function to choose the next move for the given board situation
*/
Move MyBot::play(const OthelloBoard &board)    
{
    /* get all the currently possible moves for max */
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it = moves.begin();

    /* let the first move be the next move */
    Move next_move = *it;

    /* set an lower bound for alpha value */
    int alpha_min = -200;

    /* for every move of max, find the move which will lead to maximum alpha value */
    for (int i = 0; i < moves.size(); it++, i++)
    {
        Turn alpha = turn;

        /* create a new copy of the given board */
        OthelloBoard new_board = board;

        /* play the move one by one in the copy of the board */
        new_board.makeMove(alpha, *it);

        /* call alphabeta function to calculate the alpha value for this move */
        int a = AlphaBeta(new_board, 3, alpha_min, 200);

        /* save the move which will give the highest alpha value */
        if (a > alpha_min)
        {
            alpha_min = a;
            next_move = *it;
        }
    }

    /* return the next move with highest alpha value */
    return next_move;
}

/*
AlphaBeta function to calculate min max value of every move with alpha beta pruning
*/
int MyBot::AlphaBeta(const OthelloBoard &board, int depth, int alpha_min, int beta_max)
{
    /* if its the last level of game tree, i.e. all are terminal nodes*/
    if (depth == 0)
    {
        /* return the heuristic value */
        return heuristic(board, turn);
    }
    /* if its max's turn, i.e. max have to choose a move */
    else if (depth % 2 == 0)
    {
        /* get all the currently possible moves for max */
        list<Move> moves = board.getValidMoves(turn);
        list<Move>::iterator it = moves.begin();

        /* initally set max alpha value equal to alpha_min */
        int max_a = alpha_min;
        int a;

        /* for every move of max, find the move which will lead to maximum alpha value */
        for (int i = 0; i < moves.size(); it++, i++)
        {
            Turn trn = turn;

            /* create a new copy of the given board */
            OthelloBoard new_board = board;

            /* play the move one by one in the copy of the board */
            new_board.makeMove(trn, *it);

            /* call alphabeta function to calculate the alpha value for this move */
            a = AlphaBeta(new_board, depth - 1, max_a, beta_max);

            /* save the highest alpha value */
            if (a > max_a)
            {
                max_a = a;
                if (max_a > beta_max)
                    return beta_max;
            }
        }

        /* return the highest alpha value*/
        return max_a;
    }

    /* if its min's turn, i.e. min have to choose a move */
    else
    {
        Turn beta = other(turn);

        /* get all the currently possible moves for min */
        list<Move> moves = board.getValidMoves(beta);
        list<Move>::iterator it = moves.begin();

        /* initally set min beta value equal to beta_max */
        int min_b = beta_max;
        int b;

        /* for every move of min, find the move which will lead to minimum beta value */
        for (int i = 0; i < moves.size(); it++, i++)
        {
            Turn trn_b = beta;

            /* create a new copy of the given board */
            OthelloBoard my_board = board;

            /* play the move one by one in the copy of the board */
            my_board.makeMove(trn_b, *it);

            /* call alphabeta function to calculate the beta value for this move */
            b = AlphaBeta(my_board, depth - 1, alpha_min, min_b);

            /* save the lowest beta value */
            if (b < min_b)
            {
                min_b = b;
                if (min_b < alpha_min)
                    return alpha_min;
            }
        }

        /* return the beta value */
        return min_b;
    }
}

/*
Function to calculate heuristic values for a given board position for max nodes
*/
int MyBot::heuristic(const OthelloBoard &board, Turn turn)
{
    /* value assigned to each square of the board according to some evaluation criterias by experts */
    int hval[8][8] = {120, -20, 20, 5, 5, 20, -20, 120,
                      -20, -40, -5, -5, -5, -5, -40, -20,
                      20, -5, 15, 3, 3, 15, -5, 20,
                      5, -5, 3, 3, 3, 3, -5, 5,
                      5, -5, 3, 3, 3, 3, -5, 5,
                      20, -5, 15, 3, 3, 15, -5, 20,
                      -20, -40, -5, -5, -5, -5, -40, -20,
                      120, -20, 20, 5, 5, 20, -20, 120};

    /* initially let the hvalue = 0 */
    int hvalue = 0;
    Turn beta = other(turn);

    /*calculate heuristic for max by adding all the value where our coin is placed minus all the values where opponent's coin is placed*/
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            if (board.get(i, j) == turn)
                hvalue += hval[i][j];
            if (board.get(i, j) == beta)
                hvalue -= hval[i][j];
        }
    }

    /* return heuristic value*/
    return hvalue;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
