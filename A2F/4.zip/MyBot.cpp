/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include<tuple>
using namespace std;
using namespace Desdemona;

#define INF 1e15

 clock_t startTime, endTime;
int boardWeight[8][8] = {{24, 0, 15, 12, 12, 15, 0, 24},
                         {0, -3, 0, 5, 5, 0, -3, 0},
                         {15, 0, 6, 6, 6, 6, 0, 15},
                         {12, 5, 6, 1, 1, 6, 5, 12},
                         {12, 5, 6, 1, 1, 6, 5, 12},
                         {15, 0, 6, 6, 6, 6, 0, 15},
                         {0, -3, 0, 5, 5, 0, -3, 0},
                         {24, 0, 15, 12, 12, 15, 0, 24}};
int dx[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
int dy[8] = {0, 1, 1, 1, 0, -1, -1, -1};


class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        Turn myColor;
        virtual Move play(const OthelloBoard &);
        int GetDiskCount(const OthelloBoard &, Turn);
        double TestMove(const OthelloBoard &, Turn, int, double, double);
        double Heuristic(const OthelloBoard &, Turn);
        tuple<int, int, int> FrontierCount(const OthelloBoard &, Turn);
        Move GetBestMove(const OthelloBoard&, list<Move> &);
    private:
};

MyBot::MyBot( Turn turn ): OthelloPlayer( turn ){myColor = turn;}

int MyBot::GetDiskCount(const OthelloBoard &board, Turn colour) {
    switch(colour){
        case RED: return board.getRedCount(); break;
        case BLACK: return board.getBlackCount(); break;
        default: return 0;
    }
}

bool isValid(int x,int y){return (x>=0 && x < 8 && y>=0 && y < 8);}

Move MyBot::GetBestMove(const OthelloBoard& board, list<Move> &moves){
    Move bestMove = *moves.begin();
    double alpha = -INF, beta = INF;
    for (list<Move>::iterator it = moves.begin(); it != moves.end(); it++) {
        OthelloBoard currentBoard = board;
        currentBoard.makeMove(myColor, *it);
        double val = TestMove(currentBoard, myColor, 6, alpha, beta);
        if (val > alpha) {
            alpha = val;
            bestMove = *it;
        }
    }
    return bestMove;
}

Move MyBot::play( const OthelloBoard& board ) {
    startTime = clock();
    list<Move> moves = board.getValidMoves(turn);
    return GetBestMove(board, moves);
}

double MyBot::TestMove(const OthelloBoard &board, Turn colour, int depth, double alpha, double beta) {
    endTime = clock();
    if (double(endTime - startTime) / CLOCKS_PER_SEC >= 1.90) {
        return ((colour == myColor) ? alpha : beta);
    }

    list<Move> moves = board.getValidMoves(other(colour));
    if (depth == 0 || moves.size() == 0) return Heuristic(board, myColor);

    for (list<Move>::iterator it = moves.begin(); it != moves.end(); it++) {
        OthelloBoard current_board = board;
        current_board.makeMove(other(colour), *it);
        if(colour == myColor){
            beta = min(beta, TestMove(current_board, other(colour), depth - 1, alpha, beta));
            if (alpha >= beta) return alpha;
        } else {
            alpha = max(alpha, TestMove(current_board, other(colour), depth - 1, alpha, beta));
            if (alpha >= beta) return beta;
        }
    }
    return ((colour == myColor) ? beta : alpha);
}

tuple<int, int, int> MyBot::FrontierCount(const OthelloBoard &board, Turn colour){
    int myFrontiers = 0, oppFrontiers = 0;
    int diskWeights = 0;

    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            Turn curr = board.get(i, j);
            if (curr == colour) {
                diskWeights += boardWeight[i][j];
            } else if (curr == other(colour)) {
                diskWeights -= boardWeight[i][j];
            } else continue;

            for (int k = 0; k < 8; k++) {
                if(!isValid(i+dx[k], j+dy[k])) continue;
                if (board.get(i + dx[k], j + dy[k]) == EMPTY) {
                    myFrontiers += (board.get(i, j) == colour);
                    oppFrontiers += (board.get(i, j) == other(colour));
                    break;
                }
            }
        }
    }
    return make_tuple(myFrontiers, oppFrontiers, diskWeights);
}

double MyBot::Heuristic(const OthelloBoard &board, Turn colour) {

    double materialDifference = 0;
    double cornerCapture = 0;
    double frontier = 0;
    double diskWeights = 0;
    double cornerAdjacent = 0;
    double mobility = 0;
    int myFrontiers = 0, oppFrontiers = 0;

    tuple <int, int, int> t = FrontierCount(board, colour);
    myFrontiers = get<0>(t), oppFrontiers = get<1>(t), diskWeights = (get<2>(t) - 4);

    int myCount = GetDiskCount(board, colour), oppCount = GetDiskCount(board, other(colour));
    materialDifference = (100 * myCount) / (myCount + oppCount);
    if (materialDifference <= 50) materialDifference -= 100;

    if (myFrontiers + oppFrontiers > 0) {
        frontier = -(100.0 * myFrontiers) / (myFrontiers + oppFrontiers);
        if (frontier > -50) frontier = 100 + frontier;
    }

    for(int corner_x : {0, 7}){
        for(int corner_y : {0, 7}){
            if(board.get(corner_x, corner_y) == colour) cornerCapture++;
            else if(board.get(corner_x, corner_y) == other(colour)) cornerCapture--;
            else {
                for(int x = -1; x <= 1; x++){
                    for(int y = -1; y <= 1; y++){
                        if(!isValid(corner_x + x, corner_y + y)) continue;
                        if(x == 0 && y == 0) continue;
                        int c = board.get(corner_x + x, corner_y + y);
                        cornerAdjacent += (c == colour);
                        cornerAdjacent -= (c == other(colour));
                    }
                }
            }
        } 
    }

    int ourSize = board.getValidMoves(colour).size(), oppSize = board.getValidMoves(other(colour)).size();
    if (ourSize + oppSize > 0) {
        mobility = (100 * ourSize) / (ourSize + oppSize);
        if (mobility <= 50) mobility -= 100;
    }

    double score = 10 * materialDifference + 20000 * cornerCapture 
                    - 4800 * cornerAdjacent + 80 * mobility 
                    + 75 * frontier + 10 * diskWeights;
    return score;

}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


