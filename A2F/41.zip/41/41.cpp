/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <bits/stdc++.h>
#include <chrono> 
using namespace std;
using namespace Desdemona;

#define SIZE 8

auto start_time = chrono::high_resolution_clock::now(); 
auto end_time = chrono::high_resolution_clock::now(); 


// board weights
static int s_board[8][8] = {
    {100, -10, 11, 6, 6, 11, -10, 100}, 
    {-10, -20, 1, 2, 2, 1, -20, -10},
    {11, 1, 5, 4, 4, 5, 1, 11},
    {6, 2, 4, 2, 2, 4, 2, 6},
    {6, 2, 4, 2, 2, 4, 2, 6},
    {11, 1, 5, 4, 4, 5, 1, 11},
    {-10, -20, 1, 2, 2, 1, -20, -10},
    {100, -10, 11, 6, 6, 11, -10, 100}, 
};

// best move
Move best_move(Move::empty());
int K = 7; // k_ply depth

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );

        /**
         * My code here
         */
        
        Turn PLAYER;
        Turn BOT;
        
        // weights for evaluation function 
        int corner_weight; 
        int edge_corners_weight;
        int positional_weight;
        int disc_count_weight;
        int valid_moves_weight;

        
        float alpha_beta(OthelloBoard& board, Turn turn, float alpha, float beta, int depth);
        float eval(OthelloBoard& board, Turn turn);
        float positionalvalue(OthelloBoard& board, Turn turn);
    
    private:
};

// constructor
MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
    PLAYER = turn;
    BOT = other(turn);

    // defining weights
    corner_weight = 1000;
    edge_corners_weight = 250;
    positional_weight = 10;
    disc_count_weight = 1;
    valid_moves_weight = 100;
}

// Evaluation function
float MyBot::eval(OthelloBoard& board, Turn turn){
    float player_count = board.getBlackCount();
    float bot_count = board.getRedCount();
    if(PLAYER == RED){
        swap(player_count, bot_count);
    }
    int player_corners = 0;
    int bot_corners = 0;


    if(board.get(0,0) == PLAYER) player_corners++;
    else if (board.get(0,0) == BOT) bot_corners++;
    if(board.get(0,SIZE - 1) == PLAYER) player_corners++;
    else if (board.get(0,SIZE - 1) == BOT) bot_corners++;
    if(board.get(SIZE - 1,0) == PLAYER) player_corners++;
    else if (board.get(SIZE - 1,0) == BOT) bot_corners++;
    if(board.get(SIZE - 1,SIZE - 1) == PLAYER) player_corners++;
    else if (board.get(SIZE - 1,SIZE - 1) == BOT) bot_corners++;

     // Calculating pieces adjacent to corners;
    int edge_corners_player = 0;
    int edge_corners_bot = 0;
   
    if(board.get(0,0) == EMPTY){
        if(board.get(0,1) == PLAYER) edge_corners_player++;
        else if(board.get(0,1) == BOT) edge_corners_bot++;
        if(board.get(1,0) == PLAYER) edge_corners_player++;
        else if(board.get(1,0) == BOT) edge_corners_bot++;
        if(board.get(1,1) == PLAYER) edge_corners_player++;
        else if(board.get(1,1) == BOT) edge_corners_bot++;
    }
    if(board.get(0, SIZE - 1) == EMPTY){
        if(board.get(0, SIZE - 2) == PLAYER) edge_corners_player++;
        else if(board.get(0, SIZE - 2) == BOT) edge_corners_bot++;
        if(board.get(1,SIZE - 1) == PLAYER) edge_corners_player++;
        else if(board.get(1,SIZE - 1) == BOT) edge_corners_bot++;
        if(board.get(1,SIZE - 2) == PLAYER) edge_corners_player++;
        else if(board.get(1,SIZE - 2) == BOT) edge_corners_bot++;        
    }
    if(board.get(SIZE - 1, 0) == EMPTY){
        if(board.get(SIZE - 1, 1) == PLAYER) edge_corners_player++;
        else if(board.get(SIZE - 1, 1) == BOT) edge_corners_bot++;
        if(board.get(SIZE - 2, 0) == PLAYER) edge_corners_player++;
        else if(board.get(SIZE - 2, 0) == BOT) edge_corners_bot++;
        if(board.get(SIZE - 2, 1) == PLAYER) edge_corners_player++;
        else if(board.get(SIZE - 2, 1) == BOT) edge_corners_bot++;        
    }
    if(board.get(SIZE - 1, SIZE - 1) == EMPTY){
        if(board.get(SIZE - 1, SIZE - 1) == PLAYER) edge_corners_player++;
        else if(board.get(SIZE - 1, SIZE - 1) == BOT) edge_corners_bot++;
        if(board.get(SIZE - 2, SIZE - 1) == PLAYER) edge_corners_player++;
        else if(board.get(SIZE - 2, SIZE - 1) == BOT) edge_corners_bot++;
        if(board.get(SIZE - 2, SIZE - 2) == PLAYER) edge_corners_player++;
        else if(board.get(SIZE - 2, SIZE - 2) == BOT) edge_corners_bot++;        
    }

    float max_points = 0, min_points = 0;

    max_points += corner_weight*player_corners +valid_moves_weight *board.getValidMoves(PLAYER).size() + disc_count_weight*player_count - edge_corners_weight*edge_corners_player + positional_weight*positionalvalue(board, PLAYER);
    min_points += corner_weight*bot_corners + valid_moves_weight*board.getValidMoves(BOT).size() + disc_count_weight*bot_count - edge_corners_weight*edge_corners_bot + positional_weight*positionalvalue(board, BOT);

    return (max_points - min_points);
}


// Alpha-Beta pruning
float MyBot::alpha_beta(OthelloBoard& board, Turn turn, float alpha, float beta, int depth){
    end_time = chrono::high_resolution_clock::now();
    double time_taken = chrono::duration_cast<chrono::nanoseconds>(end_time - start_time).count(); 
    time_taken *= 1e-9;
    if(time_taken > 1.90){
        // cout<<time_taken<<endl;
        return 0;
    }
    auto moves = board.getValidMoves(turn);
    // terminal node edge case
    if(moves.size()==0 || depth==1){ 
        return eval(board, turn);
    }
    if(turn == PLAYER){
        for(auto it=moves.begin(); it!=moves.end(); it++){
            // construct the child node by making one move.
            auto child = board;
            child.makeMove(turn, *it);
            // update alpha 
            auto temp_alpha = alpha_beta(child, other(turn), alpha, beta, depth-1);
            if(depth==K && temp_alpha>alpha){
                best_move = *it;
            }
            alpha = max(alpha, temp_alpha);
            if(alpha>=beta) return beta;
        }
        return alpha;
    }
    else{ 
        for(auto it=moves.begin(); it!=moves.end(); it++){
            // construct the child node by making one move.
            auto child = board;
            child.makeMove(turn, *it);
            // update beta 
            beta = min(beta, alpha_beta(child, other(turn), alpha, beta, depth-1));
            if(alpha>=beta) return alpha;
        }
        return beta;
    }
}


// Function to calculate positional value for pieces on the board.
float MyBot::positionalvalue(OthelloBoard& board, Turn turn)
{
    float count=0;
    for(int i=0;i<SIZE;i++)
    {
        for (int j=0;j<SIZE;j++)
        {
            if(board.get(i,j)==turn)
            count+=s_board[i][j];
        }        
    }
    return count;
}

Move MyBot::play( const OthelloBoard& board )
{   
    start_time = chrono::high_resolution_clock::now();
    
    auto copy_board = board;
    alpha_beta(copy_board, turn, INT_MIN, INT_MAX, K);

    if(!board.validateMove(turn, best_move)){
        list<Move> moves = board.getValidMoves( turn );
        best_move = *moves.begin();
    }

    return best_move;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


