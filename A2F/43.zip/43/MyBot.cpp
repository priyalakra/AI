/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <climits>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread.
         */
         Turn curr_turn;
         int curr_max_depth;
         MyBot( Turn turn );
        /**
         * Play something
         */
        virtual Move play( const OthelloBoard& board );
        float miniMax(OthelloBoard& board, float alpha, float beta, Turn turn, int depth, time_t start_time);
        float eval(OthelloBoard& board, Turn turn);

    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
  this->curr_turn = turn;
}

Move MyBot::play( const OthelloBoard& board )
{
    time_t start_time = time(0);
    list<Move> moves = board.getValidMoves( turn );
    // int randNo = rand() % moves.size();
    // list<Move>::iterator it = moves.begin();

    int numBlack = board.getBlackCount();
    int numRed = board.getRedCount();
    int max_depth;
    if(numBlack + numRed < 50) {
      max_depth = 8;
    } else {
      max_depth = 65 - numBlack - numRed;
    }
    Move best_move = moves.front();
    OthelloBoard temp_board;
    for(int i = 3; i < max_depth; i++) {
      this->curr_max_depth = i;
      float alpha = INT_MIN, beta = INT_MAX;
      Turn next_turn;
      if(turn == BLACK) {
        next_turn = RED;
      } else {
        next_turn = BLACK;
      }
      // Move best_move = moves.front();
      for(Move move: moves) {
        temp_board = board;
        temp_board.makeMove(turn, move);
        float heuristic = this->miniMax(temp_board, alpha, beta, next_turn, 1, start_time);
        if(heuristic > alpha) {
          alpha = heuristic;
          best_move = move;
        }
        if(time(0) - start_time > 1.9) {
          return best_move;
        }
      }
    }
    return best_move;
}

// 3
/* float MyBot::eval(OthelloBoard& Board, Turn t)
{
    //  Difference in coins
    int b_count,r_count,diff;
    b_count = Board.getBlackCount();
    r_count = Board.getRedCount();
    diff = b_count-r_count;
    
    // int curr_move = b_count+r_count-4;
    
    // Mobility
    list<Move> black_move = Board.getValidMoves(BLACK);
    list<Move> red_move = Board.getValidMoves(RED);
    int mobty = red_move.size();
    

    
    Turn opp_turn;
    if(t==BLACK) opp_turn=RED;
    else opp_turn=BLACK;
    
    list<Move> my_move(red_move);
    if(t==RED) {
        diff = -diff;
        mobty = black_move.size();
        my_move = black_move;
        }
    
    // position values
    int game[8][8] = { {500, -50, 5, 5, 5, 5, -50, 500},
                        {-50, -100, 0, 0, 0, 0, -100, -50},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {-50, -100, 0, 0, 0, 0, -100, -50},
                        {500, -50, 5, 5, 5, 5, -50, 500}};
    
    // Board weight 
    int our_weight=0;
    int opp_weight=0;
    for (int i=0;i<8;i++){
        for (int j=0;j<8;j++){
            if (Board.get(i,j)==t) our_weight+=game[i][j];
            if (Board.get(i,j)==opp_turn) opp_weight+=game[i][j];
        }
    }
    return (our_weight - opp_weight) - 2*mobty + 2*diff;
} */

// 2_1
/* int find_coin_turn(OthelloBoard& Board,int x,int y,Turn t){
    int direc[8][2]={{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1},{0,-1},{1,-1}};
    Turn opp_turn1;
    int total_coin_turns=0;
    if(t==BLACK) opp_turn1=RED;
    else opp_turn1=BLACK;
    for(int i=0;i<8;i++){
        int dx=direc[i][0];
        int dy=direc[i][1];
        int k=1;
        bool found=false;
        while((0<=x+k*dx) && (x+k*dx<8) && (0<=y+k*dy) && (y+k*dy<8)){
            if(Board.get(x+k*dx,y+k*dy)!=opp_turn1){
                found=true;
                break;
            }
            k+=1;
        }
        if(found){
            if(Board.get(x+k*dx,y+k*dy)==t) total_coin_turns+=k-1;
        }
        
    }
    return total_coin_turns;
}

float MyBot::eval(OthelloBoard& Board, Turn t)
{
    //  Difference in coins
    int b_count,r_count,diff;
    b_count = Board.getBlackCount();
    r_count = Board.getRedCount();
    diff = b_count-r_count;
    
    
    // Mobility
    list<Move> black_move = Board.getValidMoves(BLACK);
    list<Move> red_move = Board.getValidMoves(RED);
    int mobty = black_move.size()-red_move.size();
    

    
    Turn opp_turn;
    if(t==BLACK) opp_turn=RED;
    else opp_turn=BLACK;
    
    list<Move> my_move(red_move);
    if(t==RED) {
        diff = -diff;
        mobty = black_move.size();
        my_move = black_move;
        }
    
    // position values
    int game[8][8] = {{2000, -100, 5, 5, 5, 5, -100, 2000},
                        {-100, -100, 0, 0, 0, 0, -100, -100},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {-100, -100, 0, 0, 0, 0, -100, -100},
                        {2000, -100, 5, 5, 5, 5, -100, 2000}};
    
    // Board weight 
    int our_weight=0;
    int opp_weight=0;
    for (int i=0;i<8;i++){
        for (int j=0;j<8;j++){
            if (Board.get(i,j)==t) our_weight+=game[i][j];
            if (Board.get(i,j)==opp_turn) opp_weight+=game[i][j];
        }
    }
    // int nxt_opp_weight=0;
    int nxt_opp_turn=0;
    list<Move>::iterator itr = my_move.begin();
    while(itr != my_move.end()){
        int xi=(*itr).x;
        int yi=(*itr).y;
        int coin_turn=find_coin_turn(Board,xi,yi,t);
        nxt_opp_turn=std::max(nxt_opp_turn,coin_turn);
        itr++;
    }
    return (our_weight - opp_weight) - 5*nxt_opp_turn + 20*mobty + 2*diff;
} */

// 2
/* int find_coin_turn(OthelloBoard& Board,int x,int y,Turn t){
    int direc[8][2]={{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1},{0,-1},{1,-1}};
    Turn opp_turn1;
    int total_coin_turns=0;
    if(t==BLACK) opp_turn1=RED;
    else opp_turn1=BLACK;
    for(int i=0;i<8;i++){
        int dx=direc[i][0];
        int dy=direc[i][1];
        int k=1;
        bool found=false;
        while((0<=x+k*dx) && (x+k*dx<8) && (0<=y+k*dy) && (y+k*dy < 8)){
            if(Board.get(x+k*dx,y+k*dy)!=opp_turn1){
                found=true;
                break;
            }
            k+=1;
        }
        if(found){
            if(Board.get(x+k*dx,y+k*dy)==t) total_coin_turns+=k-1;
        }
        
    }
    return total_coin_turns;
}

float MyBot::eval(OthelloBoard& Board, Turn t)
{
    //  Difference in coins
    int b_count,r_count,diff;
    b_count = Board.getBlackCount();
    r_count = Board.getRedCount();
    diff = b_count-r_count;
    
    //int curr_move = b_count+red_count-4;
    
    // Mobility
    list<Move> black_move = Board.getValidMoves(BLACK);
    list<Move> red_move = Board.getValidMoves(RED);
    int mobty = red_move.size();
    

    
    Turn opp_turn;
    if(t==BLACK) opp_turn=RED;
    else opp_turn=BLACK;
    
    list<Move> my_move(red_move);
    if(t==RED) {
        diff = -diff;
        mobty = black_move.size();
        my_move = black_move;
    }
    
    // position values
    int game[8][8] = { {500, -50, 5, 5, 5, 5, -50, 500},
                        {-50, -100, 0, 0, 0, 0, -50, -50},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {-50, -100, 0, 0, 0, 0, -100, -50},
                        {500, -50, 5, 5, 5, 5, -50, 500}};
    
    // Board weight 
    int our_weight=0;
    int opp_weight=0;
    for (int i=0;i<8;i++){
        for (int j=0;j<8;j++){
            if (Board.get(i,j)==t) our_weight+=game[i][j];
            if (Board.get(i,j)==opp_turn) opp_weight+=game[i][j];
        }
    }
    //int nxt_opp_weight=0;
    int nxt_opp_turn=0;
    list<Move>::iterator itr = my_move.begin();
    while(itr != my_move.end()) {
        int xi=(*itr).x;
        int yi=(*itr).y;
        int coin_turn=find_coin_turn(Board,xi,yi,t);
        nxt_opp_turn=std::max(nxt_opp_turn,coin_turn);
        itr++;
    }
    return (our_weight - opp_weight) - 5*nxt_opp_turn - 2*mobty + 2*diff;
}*/

// 1
/* int find_coin_turn(OthelloBoard& Board,int x,int y,Turn t){
    int direc[8][2]={{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1},{0,-1},{1,-1}};
    Turn opp_turn;
    int total_coin_turns=0;
    if(t==BLACK) opp_turn=RED;
    else opp_turn=BLACK;
    for(int i=0;i<8;i++){
        int dx=direc[i][0];
        int dy=direc[i][1];
        int k=1;
        bool found=false;
        while((0 <= (x + k * dx)) && ((x + k * dx) < 8) && (0 <= (y + k * dy)) && ((y + k * dy) < 8)){
            if(Board.get(x+k*dx,y+k*dy)!=opp_turn){
                found=true;
                break;
            }
            k+=1;
        }
        if (found){
            if(Board.get(x+k*dx,y+k*dy)==t) total_coin_turns+=k;
        }
        
    }
    return total_coin_turns;
}

float MyBot::eval(OthelloBoard& Board, Turn t)
{
    //  Difference in coins
    int b_count,r_count,diff;
    b_count = Board.getBlackCount();
    r_count = Board.getRedCount();
    diff = b_count-r_count;
    
    //int curr_move = b_count+r_count-4;
    
    // Mobility
    list<Move> black_move = Board.getValidMoves(BLACK);
    list<Move> red_move = Board.getValidMoves(RED);
    int mobty = red_move.size();
    

    
    Turn opp_turn;
    if(t==BLACK) opp_turn=RED;
    else opp_turn=BLACK;
    
    list<Move> my_move(red_move);
    if(t==RED) {
        diff = -diff;
        mobty = black_move.size();
        //corn_value = -corn_value;
        my_move = black_move;
        }
    
    // position values
    int game[8][8] = { {200, -20, 5, 5, 5, 5, -20, 200},
                        {-20, -50, 0, 0, 0, 0, -50, -20},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {5, 0, 0, 0, 0, 0, 0, 5},
                        {-20, -50, 0, 0, 0, 0, -50, -20},
                        {200, -20, 5, 5, 5, 5, -20, 200}};
    
    // Board weight 
    int our_weight=0;
    int opp_weight=0;
    for (int i=0;i<8;i++){
        for (int j=0;j<8;j++){
            if (Board.get(i,j)==t) our_weight+=game[i][j];
            if (Board.get(i,j)==opp_turn) opp_weight+=game[i][j];
        }
    }
    //int nxt_opp_weight=0;
    int nxt_opp_turn=0;
    list<Move>::iterator itr = my_move.begin();
    while(itr != my_move.end()) {
        int xi=(*itr).x;
        int yi=(*itr).y;
        int coin_turn=find_coin_turn(Board,xi,yi,t);
        nxt_opp_turn=std::max(nxt_opp_turn,coin_turn);
        itr++;
    }
    return (our_weight - opp_weight) - 5*nxt_opp_turn - 2*mobty + 2*diff;
} */

// trial - only minimizing opponent's mobility
/* float MyBot::eval(OthelloBoard& board, Turn turn) {
  // Coins
  Turn opp_turn;
  int selfCoins = 0, otherCoins = 0;
  if(turn == BLACK) {
    selfCoins = board.getBlackCount();
    otherCoins = board.getRedCount();
    opp_turn = RED;
  } else {
    selfCoins = board.getRedCount();
    otherCoins = board.getBlackCount();
    opp_turn = BLACK;
  }

  // Corners
  int selfCorners = 0, otherCorners = 0;
  for(int i = 0; i < 8; i += 7) {
    for(int j = 0; j < 8; j += 7) {
      if(board.get(i, j) == turn) {
        selfCorners += 1;
      } else if(board.get(i, j) == opp_turn) {
        otherCorners += 1;
      }
    }
  }

  // Mobility
  // int selfMobility = board.getValidMoves(turn).size();
  int otherMobility = board.getValidMoves(opp_turn).size();

  // Value
  int game[8][8] = { {2000, -50, 1, 1, 1, 1, -50, 2000},
                      {-50, -100, 0, 0, 0, 0, -100, -50},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {-50, -100, 0, 0, 0, 0, -100, -50},
                      {2000, -50, 1, 1, 1, 1, -50, 2000}};
  int selfValue = 0, otherValue = 0;
  for(int i = 0; i < 8; i++) {
      for(int j = 0; j < 8; j++) {
          if(board.get(i,j) == turn) {
            selfValue += game[i][j];
          } else if(board.get(i,j)== opp_turn) {
            otherValue += game[i][j];
          }
      }
  }

  return (selfCoins - otherCoins) - (20 * (otherMobility)) + (selfValue - otherValue);
} */


// trial - considering empty corners as opponent corners
/* float MyBot::eval(OthelloBoard& board, Turn turn) {
  // Coins
  Turn opp_turn;
  int selfCoins = 0, otherCoins = 0;
  if(turn == BLACK) {
    selfCoins = board.getBlackCount();
    otherCoins = board.getRedCount();
    opp_turn = RED;
  } else {
    selfCoins = board.getRedCount();
    otherCoins = board.getBlackCount();
    opp_turn = BLACK;
  }

  // Corners
  int selfCorners = 0, otherCorners = 0;
  for(int i = 0; i < 8; i += 7) {
    for(int j = 0; j < 8; j += 7) {
      if(board.get(i, j) == turn) {
        selfCorners += 1;
      } else {
        otherCorners += 1;
      }
    }
  }

  // Mobility
  int selfMobility = board.getValidMoves(turn).size();
  int otherMobility = board.getValidMoves(opp_turn).size();

  // Value
  int game[8][8] = { {1000, -50, 1, 1, 1, 1, -50, 1000},
                      {-50, -100, 0, 0, 0, 0, -100, -50},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {-50, -100, 0, 0, 0, 0, -100, -50},
                      {1000, -50, 1, 1, 1, 1, -50, 1000}};
  int selfValue = 0, otherValue = 0;
  for(int i = 0; i < 8; i++) {
      for(int j = 0; j < 8; j++) {
          if(board.get(i,j) == turn) {
            selfValue += game[i][j];
          } else if(board.get(i,j)== opp_turn) {
            otherValue += game[i][j];
          }
      }
  }

  return (selfCoins - otherCoins) + (1000 * (selfCorners - otherCorners)) + (20 * (selfMobility - otherMobility)) + (selfValue-otherValue);
} */

// trial
float MyBot::eval(OthelloBoard& board, Turn turn) {
  // Coins
  Turn opp_turn;
  int selfCoins = 0, otherCoins = 0;
  if(turn == BLACK) {
    selfCoins = board.getBlackCount();
    otherCoins = board.getRedCount();
    opp_turn = RED;
  } else {
    selfCoins = board.getRedCount();
    otherCoins = board.getBlackCount();
    opp_turn = BLACK;
  }

  // Mobility
  int selfMobility = board.getValidMoves(turn).size();
  int otherMobility = board.getValidMoves(opp_turn).size();

  // Value: Giving corners highest weights
  int game[8][8] = { {2000, -50, 1, 1, 1, 1, -50, 2000},
                      {-50, -100, 0, 0, 0, 0, -100, -50},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 0, 0, 0, 0, 1},
                      {-50, -100, 0, 0, 0, 0, -100, -50},
                      {2000, -50, 1, 1, 1, 1, -50, 2000}};
  int selfValue = 0, otherValue = 0;
  for(int i = 0; i < 8; i++) {
      for(int j = 0; j < 8; j++) {
          if(board.get(i,j) == turn) {
            selfValue += game[i][j];
          } else if(board.get(i,j)== opp_turn) {
            otherValue += game[i][j];
          }
      }
  }

  return (selfCoins - otherCoins) + (20 * (selfMobility - otherMobility)) + (selfValue-otherValue);
}

float MyBot::miniMax(OthelloBoard& board, float alpha, float beta, Turn turn, int depth, time_t start_time) {

  if(time(0) - start_time > 1.9) {
    return INT_MIN;
  }

  // if N is a terminal node:
  //   return eval(board, turn);
  if(depth == this->curr_max_depth) {
    return eval(board, turn);
  }

  // if N is a max Node:
  //  for each child C of N:
  //    alpha = max(alpha, alphaBeta(board, alpha, beta, turn, depth + 1))
  //      if alpha >= beta:
  //        return beta
  //  return alpha

  if(turn == this->curr_turn) {
    list<Move> validMoves = board.getValidMoves(turn);
    if(validMoves.size() == 0) {
      return eval(board, turn);
    }
    OthelloBoard temp_board;
    Turn next_turn;
    if(turn == BLACK) {
      next_turn = RED;
    } else if(turn == RED) {
      next_turn = BLACK;
    }
    for(Move move: validMoves) {
      temp_board = board;
      temp_board.makeMove(turn, move);
      alpha = max(alpha, this->miniMax(temp_board, alpha, beta, next_turn, depth + 1, start_time));
      if(alpha >= beta) {
        return beta;
      }
    }
    return alpha;
  }

  // if N is a min Node:
  //  for each child C of N:
  //    beta = min(beta, alphaBeta(board, alpha, beta, turn, depth + 1))
  //      if beta <= alpha:
  //        return alpha
  //  return beta

  else {
    list<Move> validMoves = board.getValidMoves(turn);
    if(validMoves.size() == 0) {
      return eval(board, turn);
    }
    OthelloBoard temp_board;
    Turn next_turn;
    if(turn == BLACK) {
      next_turn = RED;
    } else if(turn == RED) {
      next_turn = BLACK;
    }
    for(Move move: validMoves) {
      temp_board = board;
      temp_board.makeMove(turn, move);
      beta = min(beta, this->miniMax(board, alpha, beta, next_turn, depth + 1, start_time));
      if(beta <= alpha) {
        return alpha;
      }
    }
    return beta;
  }
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}
