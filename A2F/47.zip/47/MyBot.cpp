/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <time.h>
using namespace std;
using namespace Desdemona;

class MyBot : public OthelloPlayer
{
public:
    /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
    MyBot(Turn turn);

    /**
         * Play something 
         */
    virtual Move play(const OthelloBoard &board);
    virtual int detAlgo(const OthelloBoard &board, int depthOfTree, int alphaMin, int mS);
    virtual int detVal(const OthelloBoard &board, Turn turn);
    Turn playColor;
    int numberOfMove = 0;

private:
};

MyBot::MyBot(Turn turn)
    : OthelloPlayer(turn)
{
}


/*
Function to choose the next move for the given board situation
*/
Move MyBot::play(const OthelloBoard &board)    
{
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it = moves.begin();
    Move upcomingMove = *it;
    int alphaMin = -120;
    int lpVar = 0;
    int maxScore = 120;
    int depthOfTree = 4;
    while(lpVar<moves.size()){
    	lpVar++;
    	Turn turnA = turn;
    	OthelloBoard upcomingBoard = board;
    	upcomingBoard.makeMove(turnA, *it);
    	int tempRes = detAlgo(upcomingBoard, depthOfTree, alphaMin, maxScore);
    	if (tempRes > alphaMin)
        {
            alphaMin = tempRes;
            upcomingMove = *it;
        }
        it++;
    }
    
    return upcomingMove;
}


int MyBot::detAlgo(const OthelloBoard &board, int depthOfTree, int alphaMin, int mS)
{
    if(depthOfTree%2 == 1){
        Turn turnOfBeta = other(turn);
        int betaVal;
        int lpVarB = 0;
        int betaMin = mS;
        list<Move> moves = board.getValidMoves(turnOfBeta);
        list<Move>::iterator it = moves.begin();
        while(lpVarB < moves.size()){
        	lpVarB++;
        	OthelloBoard ourNewBoard = board;
        	Turn takeTurnBeta = turnOfBeta;
        	ourNewBoard.makeMove(takeTurnBeta, *it);
        	betaVal = detAlgo(ourNewBoard, depthOfTree - 1, alphaMin, betaMin);	it++;
        	if(betaVal<betaMin){
        	betaMin = betaVal;
        	if(betaMin<alphaMin)	return alphaMin;}
        }
        return betaMin;}
    if (depthOfTree == 0)      return detVal(board, turn);
    if (depthOfTree % 2 == 0){
    	int alphaVal;
    	int lpVarA = 0;
    	int alphaMax = alphaMin;
        list<Move> moves = board.getValidMoves(turn);
        list<Move>::iterator it = moves.begin();
        while(lpVarA<moves.size()){
        	lpVarA++;
        	Turn takeTurnAlpha = turn;
        	OthelloBoard upcomingBoard = board;
        	upcomingBoard.makeMove(takeTurnAlpha, *it);
        	alphaVal = detAlgo(upcomingBoard, depthOfTree - 1, alphaMax, mS);	it++;
        	if(alphaVal>alphaMax){
        		alphaMax = alphaVal;
        		if (alphaMax > mS)	return mS;}}
        return alphaMax;}   
}


int MyBot::detVal(const OthelloBoard &board, Turn turn){
	int finalValue = 0;
	Turn beta = other(turn);
	int lpVar11 = 0; int lpVar12 = 0;
	int valArray0[8] = {60, -10, 10, 3, 3, 10, -10, 60};
	int valArray1[8] = {-10, -20, -3, -3, -3, -3, -20, -10};
	int valArray2[8] = {10, -3, 5, 2, 2, 5, -3, 10};
	int valArray3[8] = {3, -3, 2, 2, 2, 2, -3, 3};
    while(lpVar11<8){
    	lpVar11++;
        while(lpVar12<0){
            lpVar12++;
            if(board.get(lpVar11,lpVar12) == turn && (lpVar11==0 || lpVar11==7))	finalValue = finalValue + valArray0[lpVar12];
            if(board.get(lpVar11,lpVar12) == beta && (lpVar11==0 || lpVar11==7))	finalValue = finalValue - valArray0[lpVar12];
            if(board.get(lpVar11,lpVar12) == turn && (lpVar11==1 || lpVar11==6))	finalValue = finalValue + valArray1[lpVar12];
            if(board.get(lpVar11,lpVar12) == beta && (lpVar11==1 || lpVar11==6))	finalValue = finalValue - valArray1[lpVar12];
            if(board.get(lpVar11,lpVar12) == turn && (lpVar11==2 || lpVar11==5))	finalValue = finalValue + valArray2[lpVar12];
            if(board.get(lpVar11,lpVar12) == beta && (lpVar11==2 || lpVar11==5))	finalValue = finalValue - valArray2[lpVar12];
            if(board.get(lpVar11,lpVar12) == turn && (lpVar11==3 || lpVar11==4))	finalValue = finalValue + valArray0[lpVar12];
            if(board.get(lpVar11,lpVar12) == beta && (lpVar11==3 || lpVar11==4))	finalValue = finalValue - valArray3[lpVar12];}} 
    return finalValue;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
