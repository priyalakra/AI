/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>
using namespace std;
using namespace Desdemona;

/*
*
*Values taken from the Research paper of University of Washington.
*
*/

#define INF 1e18

Turn my;

clock_t start,finish;
OthelloBoard globalBoard;


bool isStateReachable(char self, char opp, char *str)  {
    bool f=false;
    if (str[0] == opp){
        for (int ctr = 1; ctr < 8; ctr++) {
            if (str[ctr] == 'e'){
                break;
            } 
            if (str[ctr] == self) {
                f=true;
                break;
            }
        }
    }
    return f;
}

bool isValidMove(char self, char opp, char matrix[8][8], int startx, int starty)   {
    bool f=false;

    if (matrix[startx][starty] == 'e'){
        
        int x, y;
        char str[10];
        int ctr;

        int tempArr[3]={-1,0,1};

        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                int dx=tempArr[j];
                int dy=tempArr[i];
                if (!dy && !dx) 
                    continue;
                str[0] = '\0';
                for (ctr = 1; ctr < 8; ctr++)   {
                    int tempCalx=ctr*dx;
                    x = startx + tempCalx;
                    int tempCaly=ctr*dy;
                    y = starty + tempCaly;

                    int strTemp;
                    if (x >= 0 && y >= 0 && x<8 && y<8) 
                        strTemp = matrix[x][y];
                    else 
                        strTemp= 0;

                    str[ctr-1]=strTemp;
                }
                if (isStateReachable(self, opp, str)){
                    f=true;
                    break;
                }
            }
        }
    }
    
    return f;
}

int numValidMoves(char self, char opp, char matrix[8][8])   {
    int i; 
    int j;
    int count = 0;
    for(i = 0; i < 8; i++) {
        for(j = 0; j < 8; j++) {
            
            if(isValidMove(self, opp, matrix, i, j)) 
                count++;
        }
    }
    return count;
}

double brdEval(char matrix[8][8])  {
    char opp_color = 'y';
    char my_color = 'm';
    int x, y;
    int oppTiles = 0;
    int myTiles = 0;
    int i, j, k;
    int oppFrontTiles = 0;
    int myFrontTiles = 0;

    int eight=8;

    int V[eight][eight] ;    
    int v1[]={ 20, -3, 11, 8, 8, 11, -3, 20 };
    for(int i=0;i<eight;i++){
        V[0][i]=v1[i];
    }

    int v2[]={ -3, -7, -4, 1, 1, -4, -7, -3 };
    for(int i=0;i<eight;i++){
        V[1][i]=v2[i];
    }

    int v3[]={ 11, -4, 2, 2, 2, 2, -4, 11 };
    for(int i=0;i<eight;i++){
        V[2][i]=v3[i];
    }

    int v4[]={ 8, 1, 2, -3, -3, 2, 1, 8 };
    for(int i=0;i<eight;i++){
        V[3][i]=v4[i];
    }

    int v5[]={ 8, 1, 2, -3, -3, 2, 1, 8 };
    for(int i=0;i<eight;i++){
        V[4][i]=v5[i];
    }

    int v6[]={ 11, -4, 2, 2, 2, 2, -4, 11 };
    for(int i=0;i<eight;i++){
        V[5][i]=v6[i];
    }

    int v7[]={ -3, -7, -4, 1, 1, -4, -7, -3 };
    for(int i=0;i<eight;i++){
        V[6][i]=v7[i];
    }

    int v8[]={ 20, -3, 11, 8, 8, 11, -3, 20 };
    for(int i=0;i<eight;i++){
        V[7][i]=v8[i];
    }


    double f = 0.0;
    double d = 0.0;
    double m = 0.0;
    double l = 0.0;
    double c = 0.0;
    double p = 0.0;

    int Y1[eight] = {0, 1, 1, 1, 0, -1, -1, -1};

    int X1[eight] = {-1, -1, 0, 1, 1, 1, 0, -1};


    // Piece difference, frontier disks and disk squares
    for(i = 0; i < eight; i++)
        for(j = 0; j < eight; j++)  {
            if(matrix[i][j] != 'e')   {
                for(k = 0; k < eight; k++)  {
                    int tempVar1=i + X1[k];
                    int tempVar2=j + Y1[k];
                    x = tempVar1; 
                    y = tempVar2;

                    if(x < eight  && x >= 0) {
                        int tempMat=matrix[x][y];
                        if( y < eight && y >= 0 && tempMat == 'e'){
                            if(tempMat == my_color)  
                                myFrontTiles++;
                            else 
                                oppFrontTiles++;
                            break;
                        }
                    }
                }
            }

            char cTemp=matrix[i][j];
            if(cTemp == my_color)  {
                d += V[i][j];
                myTiles++;
            } 
            else if(cTemp == opp_color)  {
                d -= V[i][j];
                oppTiles++;
            }
            
        }
    
    int addT=myTiles + oppTiles;

    if(myTiles < oppTiles) 
        p = -(100.0 * oppTiles)/(addT);
    else if(myTiles > oppTiles) 
        p = (100.0 * myTiles)/(addT);


    addT=myFrontTiles + oppFrontTiles;
    if(myFrontTiles < oppFrontTiles) 
        f = (100.0 * oppFrontTiles)/(addT);
    else if(myFrontTiles > oppFrontTiles) 
        f = -(100.0 * myFrontTiles)/(addT);

    // Corner occupancy
    myTiles = 0;
    oppTiles = 0;

    int idx[]={0,0,7,7};
    int idy[]={0,7,0,7};

    for(int id_i=0;id_i<4;id_i++){
        if(matrix[idx[id_i]][idy[id_i]] == my_color) 
            myTiles++;
        else if(matrix[idx[id_i]][idy[id_i]] == opp_color) 
            oppTiles++;

    }

    c = 25 * (myTiles - oppTiles);

    // Corner closeness
    myTiles =0;
    oppTiles = 0;
    
    if(matrix[0][0] == 'e')   {
        char tmat=matrix[0][1];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;

        tmat=matrix[1][1];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;
        
        tmat=matrix[1][0];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;
    }

    if(matrix[7][0] == 'e')   {
        char tmat=matrix[7][1];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;

        tmat=matrix[6][1];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;

        tmat=matrix[6][0];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;
    }

    if(matrix[0][7] == 'e')   {
        char tmat=matrix[0][6];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;
        
        tmat=matrix[1][6];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;
        
        tmat=matrix[1][7];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;
    }
    
    if(matrix[7][7] == 'e')   {
        char tmat=matrix[6][7];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;
        
        tmat=matrix[6][6];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;

        tmat=matrix[7][6];
        if(tmat == my_color) 
            myTiles++;
        else if(tmat == opp_color) 
            oppTiles++;
    }

    l = -10 * (myTiles - oppTiles);

    // Mobility
    myTiles = numValidMoves(my_color, opp_color, matrix);
    oppTiles = numValidMoves(opp_color, my_color, matrix);
    
    addT=myTiles + oppTiles;

    if(myTiles < oppTiles) 
        m = -(100.0 * oppTiles)/(addT);
    else if(myTiles > oppTiles) 
        m = (100.0 * myTiles)/(addT);
    

    // final weighted score
    double score = (11 * p) + (850.724 * c) + (382.026 * l) + (86.922 * m) + (78.396 * f) + (10 * d);
    return score;
}

double checkChanges(OthelloBoard board, Move move, Turn turn, short level, double alpha, double beta) {
    finish = clock();
    double calT=(double)(finish-start)/CLOCKS_PER_SEC;
    if(calT > 1.95) {
        if((level&1) == 0) 
            return INF;
        return -INF;
    }

    int eight=8;
    if(level == 6) {
        
        char matrix[8][8];
        
        for(int i=0;i<eight;i++) {
            for(int j=0;j<eight;j++) {
                
                char mt;
                if(board.get(i,j) == turn) 
                    mt = 'y';

                else if(board.get(i,j) == other(turn)) 
                    mt = 'm';
                
                else 
                    mt = 'e';

                matrix[i][j] = mt;
            }
        }
        return brdEval(matrix);
    }

    board.makeMove(turn,move);
    turn = other(turn);
    
    list<Move> newMoves = board.getValidMoves(turn);
    list<Move>::iterator iter = newMoves.begin();
    
    double ret = -INF;
    
    if((level&1) != 0) 
        ret *= -1;
    
    if(!(newMoves.size())) 
        return ret;

    for(;iter!=newMoves.end();iter++) {
        double curr = checkChanges(board,*iter,turn,level+1,alpha,beta);
        if((level&1) == 0) {

            if(ret < curr){
                ret=curr;
            }
            if(alpha<ret){
                alpha=ret;
            }
        }
        else {      
            if(ret > curr){
                ret=curr;
            }
            if(beta > ret){
                beta=ret;
            }
        }
        if(beta<=alpha) 
            break;
    }
    return ret; 
}

double tester(OthelloBoard board,Turn turn) {
    int eight=8;
    char matrix[8][8];

    for(int i=0;i<eight;i++) {
        for(int j=0;j<eight;j++) {
            char xtm;
            if(board.get(i,j) == turn) 
                xtm = 'm';

            else if(board.get(i,j) == other(turn)) 
                xtm = 'y';
            
            else 
                xtm = 'e';

            matrix[i][j]=xtm;
        }
    }
    return brdEval(matrix);
}

bool compare(Move a, Move b) {
    OthelloBoard Two = globalBoard;
    OthelloBoard One = globalBoard;

    Two.makeMove(my,b);
    One.makeMove(my,a);

    if(tester(One,my)>tester(Two,my))
        return true;
    return false;
}

class MyBot: public OthelloPlayer{
    public:
        MyBot( Turn turn );
        virtual Move play( const OthelloBoard& board );
};

MyBot::MyBot( Turn turn ): OthelloPlayer( turn ){}

Move MyBot::play( const OthelloBoard& board )
{

    double retVal = -INF;
    double MIN = -INF;
    double MAX = INF;
    start = clock();
    list<Move> moves = board.getValidMoves( turn );
    my = turn;
    globalBoard = board;
    moves.sort(compare);
    list<Move>::iterator it = moves.begin();
    Move bestMove((*it).x,(*it).y);
    
    OthelloBoard copyBoard = board;
    short level = 1;
    for(;it!=moves.end();it++) {
        if(checkChanges(copyBoard,*it,turn,level,MIN,MAX) > retVal) {
            retVal = checkChanges(copyBoard,*it,turn,level,MIN,MAX);
            bestMove = *it;
        }
        copyBoard = board;
    }
    return bestMove;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}