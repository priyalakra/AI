/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <list>
#include <vector>

# define MINIMAX_DEPTH 5

using namespace std;
using namespace Desdemona;

struct Node
{
    Node ** children;
    int child_count;
    list<Move> move_list;
    //list<Move>::iterator ptr = move_list.begin();
    OthelloBoard state;
    int val;
};

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );



        int heuristic(const OthelloBoard& board ){

        // intialize black and red total
        int b_total = 0;
        int r_total = 0;

        // factor in the amount of moves each player has
        b_total += board.getValidMoves(BLACK).size();
        r_total += board.getValidMoves(RED).size();

        // factor in the amount of pieces each player has on the board
        b_total += board.getBlackCount();
        r_total += board.getRedCount();

        // factor in the importance of all 4 corners
        if(board.get(0,0) == RED){
            r_total += 10;
        }
        if(board.get(0,0) == BLACK){
            b_total += 10;
        }
        if(board.get(7,0) == RED){
            r_total += 10;
        }
        if(board.get(7,0) == BLACK){
            b_total += 10;
        }
        if(board.get(0,7) == RED){
            r_total += 10;
        }
        if(board.get(0,7)== BLACK){
            b_total += 10;
        }
        if(board.get(7,7) == RED){
            r_total += 10;
        }
        if(board.get(7,7) == BLACK){
            b_total += 10;
        }

        // subtract red's total from black, let black be the maximizer
        return (b_total-r_total);
    }

public: 
    int depth = 5; // initialise depth of the tree 

Node * CreateTree(const OthelloBoard& board, int depth, Turn turn)
{
    Node * node = new Node();

    // get the appropriate list moves
    node->move_list = (turn == RED) ? board.getValidMoves(RED) : board.getValidMoves(BLACK);

    // keep a count of children for indexes later on
    node->child_count = node->move_list.size();

    // copy the passed in board state to the state of the current node
    node->state = board;

    // determine other player's character
    Turn other_player = (turn == RED) ? BLACK : RED;

    // only create children if we're not too deep and this node should have children
    if (depth > 0 && node->child_count > 0) {
        // create an array of nodes as the children of the current node
        node->children = new Node * [node->child_count];


	vector<Move> move_list_Vector(node->move_list.begin(),node->move_list.end());
	//list<Move>::iterator ptr = node->move_list.begin();
        // cycle through the children and create nodes for them
        for (int i = 0; i < node->child_count; ++i){
            OthelloBoard tmp_board;
            tmp_board = board;
	     
	     //advance(ptr,i);
            // must make the associating move first so a subtree of 'that' board configuration can be created
            tmp_board.makeMove(turn, move_list_Vector[i]);

            // turn the child into a tree itself
            node->children[i] = CreateTree(tmp_board, depth - 1, other_player);
        }
    } else 
    {
        node->children = NULL;
    }

    return node;
}

int minimax(Node *position, int depth, int alpha, int beta, bool maximizing_player){

    // if we're at the final layer or this state is a dead sate, return static heurstic
    if(depth == 0 /*|| isGameOver(position->state)*/){
        //std::cout<< "returning heursitic: " << heuristic(position->state) << '\n';
        return heuristic(position->state);
    }

    // if maximizing layer...
    if(maximizing_player){
        int max_eval = -9999999; // set max to worst case

        // for all of the children nodes, recursively call minimax
        // decrease the depth parameter with each call, so we can guarantee we will get to the base case above
        for(int i = 0; i < position->child_count; ++i){
            int eval = minimax(position->children[i], depth - 1, alpha, beta, false);
            max_eval = std::max(max_eval, eval); // update max if evaluation is >

            //update alpha appropriately, and check for eligibility of alpha prune
            alpha = std::max(alpha, eval);
            if(beta <= alpha)
                break;
        }
        position->val = max_eval; // store the max_eval in this node
        return max_eval;
    } 
    else { // minimizing layer...
        int min_eval = 9999999; // set min to worst case
        for(int i = 0; i < position->child_count; ++i){
            int eval = minimax(position->children[i], depth -1, alpha, beta, true);
            min_eval = std::min(min_eval, eval); // update min if evaluation is <

            // update beta appropriately, and check for eligibility of beta prune
            beta = std::min(beta, eval);
            if(beta <= alpha)
                break;
        }
        position->val = min_eval; // store min_eval in this node
        return min_eval;
    }
}


    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    list<Move> moves = board.getValidMoves( turn );
    //int randNo = rand() % moves.size();
    list<Move>::iterator it = moves.begin();


    // game tree representing MINIMAX_DEPTH decisions
    auto gametree = CreateTree(board, MINIMAX_DEPTH, turn);
    bool maximizer = (turn == BLACK) ? true : false;

    // find optimal value
    int optimial_val = minimax(gametree, MINIMAX_DEPTH, -99999999, 99999999, maximizer);

    	vector<Move> move_list_Vector(gametree->move_list.begin(),gametree->move_list.end());
    	
    
	//list<Move>::iterator ptr = gametree->move_list.begin();
    // loop through children of root node to find the node with the optimal value
    for(int i = 0; i < gametree->child_count; ++i){
        
        if(gametree->children[i]->val == optimial_val){
            bool same_config = true;
            for(int j = 0; j < 7; ++j){
                for(int k = 0; k < 7; ++k){
                    if(gametree->children[i]->state.get(j,k) != board.get(j,k))
                        same_config = false;
                }
            }
	
	//advance(ptr,i);
        if(!same_config)
        {
            return move_list_Vector[i];
        }
    }    
    
    return *it;
    }
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}
