/*
 * @file botTemplate.cpp
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-02-04
 * Template for users to create their own bots
 */

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
using namespace std;
using namespace Desdemona;

// heuristic matrix for checking stability
// int h_mat[8][8] = {{8, -7, 3, 3, 3, 3, -5, 8},
//                    {-7, -4, 2, 2, 2, 2, -4, -5},
//                    {3, 2, 1, 1, 1, 1, 2, 3},
//                    {3, 2, 1, 1, 1, 1, 2, 3},
//                    {3, 2, 1, 1, 1, 1, 2, 3},
//                    {3, 2, 1, 1, 1, 1, 2, 3},
//                    {-2, -2, 2, 2, 2, 2, -2, -2},
//                    {8, -2, 3, 3, 3, 3, -2, 8}};

int h_mat[8][8] = {{20, -3, 11, 8, 8, 11, -3, 20},
                   {-3, -7, -4, 1, 1, -4, -7, -3},
                   {11, -4, 2, 2, 2, 2, -4, 11},
                   {8, 1, 2, -3, -3, 2, 1, 8},
                   {8, 1, 2, -3, -3, 2, 1, 8},
                   {11, -4, 2, 2, 2, 2, -4, 11},
                   {-3, -7, -4, 1, 1, -4, -7, -3},
                   {20, -3, 11, 8, 8, 11, -3, 20}};
// class definition starts
class MyBot : public OthelloPlayer
{
    int move_count = 0; // optional
    Turn curr_color;

    // function to check if time per move ended
    clock_t str;
    clock_t end;

    // alpha beta values
    double max_a;
    double min_b;

public:
    MyBot(Turn turn);

    Move play(const OthelloBoard &board);
    double HeuCalc(const OthelloBoard &board);
    double getBestMove(const OthelloBoard &board, int depth, Turn temp_color, double a, double b);
    double alpha(const OthelloBoard &board, int depth, Turn temp_color, double a, double b, list<Move>);
    double beta(const OthelloBoard &board, int depth, Turn temp_color, double a, double b, list<Move>);
    double getCoinParity(const OthelloBoard &board);
    double getStability(const OthelloBoard &board);
    double getCorner(const OthelloBoard &board);
    double getCornerAdjacent(const OthelloBoard &board);
    double getMobility(const OthelloBoard &board);
    double getFrontier(const OthelloBoard &board, int X[], int Y[]);
};
// class definition ends

// constructor definition starts
MyBot::MyBot(Turn turn)
    : OthelloPlayer(turn)
{
    curr_color = turn;
    max_a = -1e18;
    min_b = 1e18;
}
// constructor definition ends

// member function definitions start
Move MyBot::play(const OthelloBoard &board)
{
    str = clock();
    move_count += 1;
    int depth = 0; // hyp
    max_a = -1e18;
    min_b = 1e18;
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it = moves.begin();
    Move move_next = *it;
    for (; it != moves.end(); it++)
    {
        Move curr_move = *it;
        OthelloBoard curr_board = board;
        curr_board.makeMove(curr_color, curr_move);
        double value = getBestMove(board, depth, curr_color, max_a, min_b);
        if (value > max_a)
        {
            max_a = value;
            move_next = curr_move;
        }
    }
    return move_next;
}
double MyBot::getBestMove(const OthelloBoard &board, int depth, Turn temp_color, double a, double b)
{
    end = clock();
    if (double(end - str) / CLOCKS_PER_SEC >= 1.98) // hyp {
        if (temp_color == curr_color)
            return a;
        else
            return b;

    list<Move> moves = board.getValidMoves(other(temp_color));
    if (depth == 5 || moves.size() == 0)
        return HeuCalc(board);
    if (depth < 5)
    {
        double res = (temp_color == curr_color) ? beta(board, depth, temp_color, a, b, moves) : alpha(board, depth, temp_color, a, b, moves);
        return res;
    }
}
double MyBot::alpha(const OthelloBoard &board, int depth, Turn temp_color, double a, double b, list<Move> moves)
{
    list<Move>::iterator it = moves.begin();
    for (; it != moves.end(); it++)
    {
        Move curr_move = *it;
        OthelloBoard curr_board = board;
        curr_board.makeMove(other(temp_color), curr_move);
        a = max(a, getBestMove(curr_board, depth + 1, other(temp_color), a, b));
        if (a >= b)
            return b;
    }
    return a;
}
double MyBot::beta(const OthelloBoard &board, int depth, Turn temp_color, double a, double b, list<Move> moves)
{
    list<Move>::iterator it = moves.begin();
    for (; it != moves.end(); it++)
    {
        Move curr_move = *it;
        OthelloBoard curr_board = board;
        curr_board.makeMove(other(temp_color), curr_move);
        b = min(b, getBestMove(curr_board, depth + 1, other(temp_color), a, b));
        if (a >= b)
            return a;
    }
    return b;
}

double MyBot::getCoinParity(const OthelloBoard &board)
{
    if (curr_color == RED)
        return 11 * 100 * ((board.getRedCount()) / (board.getRedCount() + board.getBlackCount()));
    return 11 * 100 * ((board.getBlackCount()) / (board.getRedCount() + board.getBlackCount()));
}

double MyBot::getStability(const OthelloBoard &board)
{
    int s_h = 0;
    for (int x = 0; x < 8; x++)
    {
        for (int y = 0; y < 8; y++)
        {
            s_h = board.get(x, y) == curr_color ? s_h + h_mat[x][y] : s_h;
            s_h = board.get(x, y) == other(curr_color) ? s_h - h_mat[x][y] : s_h;
        }
    }
    return 10 * s_h;
}

double MyBot::getCorner(const OthelloBoard &board)
{
    int c_h = 0;
    int x_coords[2] = {0, 7};
    int y_coords[2] = {0, 7};
    for (int x = 0; x < 2; x++)
    {
        for (int y = 0; y < 2; y++)
        {
            if (board.get(x_coords[x], y_coords[y]) == curr_color)
                c_h++;
            else if (board.get(x_coords[x], y_coords[y]) == other(curr_color))
                c_h--;
        }
    }

    return c_h * 25 * 851;
}

double MyBot::getCornerAdjacent(const OthelloBoard &board)
{
    int ca_h = 0;
    int x_coords[4] = {0, 1, 6, 7};
    int y_coords[4] = {0, 1, 6, 7};
    for (int x = 0; x < 4; x++)
    {
        for (int y = 0; y < 4; y++)
        {
            if ((x != 0 && y != 0) || (x != 0 && y != 7) || (x != 7 && y != 0) || (x != 7 && y != 7))
            {
                if (board.get(x_coords[x], y_coords[y]) == curr_color)
                    ca_h++;
                else if (board.get(x_coords[x], y_coords[y]) == other(curr_color))
                    ca_h--;
            }
        }
    }
    return ca_h * (-10) * 382;
}
double MyBot::getMobility(const OthelloBoard &board)
{
    if (board.getValidMoves(curr_color).size() + board.getValidMoves(other(curr_color)).size() == 0)
        return 0;
    int res = 100 * ((board.getValidMoves(curr_color).size() - board.getValidMoves(other(curr_color)).size()) / (board.getValidMoves(curr_color).size() + board.getValidMoves(other(curr_color)).size()));
    return res * 87;
}
double MyBot::HeuCalc(const OthelloBoard &board)
{

    double coin_parity_heu = 0.0,
           mobility_heu = 0.0,
           cor_heu = 0.0,
           stability_heu = 0.0,
           coradj_heu = 0.0;

    coin_parity_heu = getCoinParity(board); // can be negative
    if (coin_parity_heu <= 50)
        coin_parity_heu -= 100;

    mobility_heu = getMobility(board);
    if (mobility_heu <= 50)
    {
        mobility_heu -= 100;
    }
    stability_heu = getStability(board);
    cor_heu = getCorner(board);
    coradj_heu = getCornerAdjacent(board);
    return coin_parity_heu + mobility_heu + cor_heu + stability_heu + coradj_heu;
}

// member function definition ends

// The following lines are _very_ important to create a bot module for Desdemona

extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
