
#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>
using namespace std;
using namespace Desdemona;



#define INF 1e18

Turn my;

clock_t start,finish;
OthelloBoard globalBoard;





bool canMove(char self, char opp, char *str)  {
    bool ret=false;
    if(str[0]==opp)
    {
        int i=1;
        while(i<8)
        {
            if(str[i]=='e')return ret;
            if(str[i]==self)
            {
                ret=true;
                return ret;
            }
            i++;
        }
    }

    return ret;
	
}
	





bool isLegalMove(char self, char opp, char grid[8][8], int startx, int starty)   {
	if (grid[startx][starty] != 'e') return false;
	char str[10];
	int x, y, dx, dy, ctr;
    
    dy=-1;
    while(dy<=1)
    {
        for(dx=-1;dx<=1;dx++)
        {
            if(dx==0 && dy==0)
            {
                continue;
            }
            str[0]='\0';
            ctr=1;
            while(ctr<8)
            {
                x=startx+ctr*dx;
                y=starty+ctr*dy;
                if(x>=0 && x<8 && y>=0 && y<8)
                {
                    str[ctr-1]=grid[x][y];
                }
                else 
                {
                    str[ctr-1]=0;
                }

                ctr++;
            }
            if(canMove(self,opp,str))
            {
                return true;
            }
            
        }
        dy++;
    }
    return false;
	
}
int numValidMoves(char self, char opp, char grid[8][8])   {
    int moves=0;
    for(int i=0;i<8;i++)
    {
        int j=0;
        while(j<8)
        {
            if(isLegalMove(self,opp,grid,i,j)==false)
                {    
                    j++; 
                    continue;
                }
            else
            {
                moves++;
            }j++;

        }
        
    }
    return moves;

	// int count = 0, i, j;
	// for(i = 0; i < 8; i++) for(j = 0; j < 8; j++) if(isLegalMove(self, opp, grid, i, j)) count++;
	// return count;
}

double othelloBoardEvaluator(char grid[8][8])  {
	char my_color = 'm',opp_color = 'y';
    int myTiles = 0, oppTiles = 0, i, j, k, myFrontTiles = 0, oppFrontTiles = 0, x, y;
    double p = 0.0, c = 0.0, l = 0.0, m = 0.0, f = 0.0, d = 0.0;

    int X1[] = {-1, -1, 0, 1, 1, 1, 0, -1};
    int Y1[] = {0, 1, 1, 1, 0, -1, -1, -1};
    int V[8][8] = 	{ { 20, -3, 11, 8, 8, 11, -3, 20 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 20, -3, 11, 8, 8, 11, -3, 20 } };
    // int V[8][8]={ 10,-3,2,2,2,2,-3,10
    //             ,-3,-4,-1,-1,-1,-1,-4,-3
    //             ,2,-1,1,0,0,1,-1,-2
    //             ,2,-1,0,1,1,0,-1,2
    //             ,2,-1,0,1,1,0,-1,2
    //             ,2,-1,1,0,0,1,1,-2
    //             ,-3,-4,-1,-1,-1,1,-4,-3
    //             ,10,-3,2,2,2,2,-3,10 };

	

     i=0;
     j=0;
    while(i<8)
    {
        while(j<8)
        {
            if(grid[i][j]==my_color)
            {
                d=d+V[i][j];
                myTiles++;
            }
            else if(grid[i][j]==opp_color){
                d=d-V[i][j];
                oppTiles++;
            }
            if(grid[i][j]=='e')
            {
                 k=0;
                while(k<8)
                {
                    x = i + X1[k]; y = j + Y1[k];
                    if(x >= 0 && x < 8 && y >= 0 && y < 8 && grid[x][y] == 'e') {
                        if(grid[i][j] == my_color)  
                        {
                            myFrontTiles++;
                        }
                        else
                        {
                            oppFrontTiles++;
                        } 
                        break;
                    }
                    k++;
                }
                
            }
            j++;
        }
        i++;
    }
    
     
    if(myTiles>oppTiles)
    {
        double g=100.0*myTiles;
        double h=myTiles+oppTiles;
        p=g/h;
    }
    else if(myTiles<oppTiles)
    {
        double g=-(100.0*myTiles);
        double h=myTiles+oppTiles;
        p=g/h;
    }

   
    if(myFrontTiles>oppFrontTiles)
    {
        double g=-(100.0*myFrontTiles);
        double h=(myFrontTiles+oppFrontTiles);
        f=g/h;
    }
    else if(myFrontTiles<oppFrontTiles)
    {
        double g=(100.0*oppFrontTiles);
        double h=myFrontTiles+oppFrontTiles;
        f=g/h;
    }

    // Corner occupancy
    myTiles = oppTiles = 0;
    if(grid[0][0] == my_color) myTiles++;
    else if(grid[0][0] == opp_color) oppTiles++;
    if(grid[0][7] == my_color) myTiles++;
    else if(grid[0][7] == opp_color) oppTiles++;
    if(grid[7][0] == my_color) myTiles++;
    else if(grid[7][0] == opp_color) oppTiles++;
    if(grid[7][7] == my_color) myTiles++;
    else if(grid[7][7] == opp_color) oppTiles++;
    c = 25 * (myTiles - oppTiles);

    

    // Corner closeness
    myTiles = oppTiles = 0;
    if(grid[0][0] == 'e')   {
        if(grid[0][1] == my_color) myTiles++;
        else if(grid[0][1] == opp_color) oppTiles++;
        if(grid[1][1] == my_color) myTiles++;
        else if(grid[1][1] == opp_color) oppTiles++;
        if(grid[1][0] == my_color) myTiles++;
        else if(grid[1][0] == opp_color) oppTiles++;
    }
    if(grid[0][7] == 'e')   {
        if(grid[0][6] == my_color) myTiles++;
        else if(grid[0][6] == opp_color) oppTiles++;
        if(grid[1][6] == my_color) myTiles++;
        else if(grid[1][6] == opp_color) oppTiles++;
        if(grid[1][7] == my_color) myTiles++;
        else if(grid[1][7] == opp_color) oppTiles++;
    }
    if(grid[7][0] == 'e')   {
        if(grid[7][1] == my_color) myTiles++;
        else if(grid[7][1] == opp_color) oppTiles++;
        if(grid[6][1] == my_color) myTiles++;
        else if(grid[6][1] == opp_color) oppTiles++;
        if(grid[6][0] == my_color) myTiles++;
        else if(grid[6][0] == opp_color) oppTiles++;
    }
    if(grid[7][7] == 'e')   {
        if(grid[6][7] == my_color) myTiles++;
        else if(grid[6][7] == opp_color) oppTiles++;
        if(grid[6][6] == my_color) myTiles++;
        else if(grid[6][6] == opp_color) oppTiles++;
        if(grid[7][6] == my_color) myTiles++;
        else if(grid[7][6] == opp_color) oppTiles++;
    }
    l = -10 * (myTiles - oppTiles);

    // Mobility
    myTiles = numValidMoves(my_color, opp_color, grid);
    oppTiles = numValidMoves(opp_color, my_color, grid);
    if(myTiles>oppTiles)
    {
        double o=(100.0*myTiles);
        double u=myTiles+oppTiles;
        m=o/u;
    }
    else if(myTiles<oppTiles)
    {
        double o=-(100.0*oppTiles);
        double u=myTiles+oppTiles;
        m=o/u;
    }
    double score=0;
    double q=11*p;
    score+=q;
    q=850.724*c;
    score+=q;
    q=382.026*l;
    score+=q;
    q=86.922*m;
    score+=q;
    q=78.396*f;
    score+=q;
    q=10*d;
    score+=q;
    // final weighted score
    // double score = (11 * p) + (850.724 * c) + (382.026 * l) + (86.922 * m) + (78.396 * f) + (10 * d);
    return score;
}

double testMyMove(OthelloBoard board, Move move, Turn turn, short level, double alpha, double beta) {
    finish = clock();
    if(((double)(finish-start)/CLOCKS_PER_SEC)>1.95) {
        if(level==1)
        {
            return -INF;
        }
        return INF;
        
    }
	
    double ans = -INF;
    if(level!=6)
    {



	board.makeMove(turn,move);
	turn = other(turn);
    list<Move> valid_moves = board.getValidMoves(turn);
	
	
    if(level==1)
    {
        ans*=-1;
    }
    if(valid_moves.size()==0)
    {
        return ans;
    }
	

    list<Move>::iterator itr = valid_moves.begin();
    while(itr!=valid_moves.end())
    {
        double current_score=testMyMove(board,*itr,turn,level+1,alpha,beta);
        if(level==1)
        {
            ans=min(ans,current_score);
            beta=min(beta,ans);

        }
        else
        {
            ans=max(ans,current_score);
            alpha=max(alpha,current_score);
        }
        if(beta<=alpha)
        {
            break;
        }
        itr++;

    }
	
	return ans; 
    }

    

    char currgrid[8][8];
    int i=0;
    while(i<8)
    {
        for(int j=0;j<8;j++)
        {
            Coin curr_turn=board.get(i,j);
            if(curr_turn==other(turn))
            {
                currgrid[i][j]='m';
            }
            else if(curr_turn==turn)
            {
                currgrid[i][j]='y';
            }
            else
            {
                currgrid[i][j]='e';
            }
        }
        i++;
    }
    return othelloBoardEvaluator(currgrid);
}

double tester(OthelloBoard board,Turn turn) {
    char board_grid[8][8];

    for(int i=8-1;i>=0;i--)
    {
        for(int j=0;j<8;j++)
        {
            Coin position_turn=board.get(i,j);
            if(turn==position_turn)
            {
                board_grid[i][j]='m';
                continue;
            }
            if(other(turn)==position_turn)
            {
                board_grid[i][j]='y';
                continue;
            }
            board_grid[i][j]='e';

        }
    }
    return othelloBoardEvaluator(board_grid);

    
}


bool compare(Move a, Move b) {
    OthelloBoard One = globalBoard,Two = globalBoard;
    One.makeMove(my,a);
    Two.makeMove(my,b);
    return tester(One,my)>tester(Two,my);
}

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    start = clock();
    list<Move> moves = board.getValidMoves( turn );
    my = turn;
    globalBoard = board;
    moves.sort(compare);
    list<Move>::iterator itr = moves.begin();
    Move bestMove((*itr).x,(*itr).y);
    double retVal = -INF;
    double MAX = INF, MIN = -INF;
    OthelloBoard copyBoard = board;
    short level = 1;

    while(itr!=moves.end())
    {
        double current_score=testMyMove(copyBoard,*itr,turn,level,MIN,MAX);
        if(current_score>retVal)
        {
            retVal=current_score;
            bestMove=*itr;
        }
        copyBoard=board;
        itr++;
    }

    
    return bestMove;
}
// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}