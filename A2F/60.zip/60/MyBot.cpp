#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>

using namespace Desdemona;
using namespace std;

clock_t start;
OthelloBoard globalBoard;
Turn myTurn;
clock_t finish;

bool canMove(char self, char opp, char *str) 
{
    if (str[0] == opp)
    {
        int k = 0;
        do
        {
            k++;
            
            if (str[k] == self) 
            {
                return true;
            }
            else
            {
                if (str[k] == 'e') 
                {
                    return false;
                }
            }  
        } while (k<7);
        
        return false;
    } 
    else
    {
        return false;
    }

}

bool isLegalMove(char self, char opp, char grid[8][8], int startx, int starty)   
{
    char ch = grid[startx][starty];
    if (ch == 'e')
    {
        char str[10];
        int x, y;
        int dx, dy;
        dy = -2;
        do
        {
            dy++;
            dx = -2;
            do
            {
                dx++;
                if (!(!dy && !dx))
                {
                    str[0] = '\0';
                    int k = 0;
                    do
                    {
                        k++;
                        x = startx + k*dx;
                        y = starty + k*dy;
                        str[k-1]=0;
                        if((x<0 || x>7 || y<0 || y>7)==false)
                        {
                            str[k-1] = grid[x][y];
                        }
                        
                    } while (k<7);
                    
                    bool res = canMove(self, opp, str);
                    if (res) 
                    {
                        return true;
                    }
                }

            } while (dx<1);
            
        }while(dy<1);
        return false;
    }
    else{
        return false;
    }
}

int numValidMoves(char self, char opp, char grid[8][8])   {
	int ans = 0;
    int row = -1;
    do
    {
        row++;
        int col = -1;
        do
        {
            col++;
            bool check = isLegalMove(self, opp, grid, row, col);
            if(check)
            {
                ans++;
            } 
        } while (col<7);
        
    } while (row<7);
    
	return ans;
}

double othelloBoardEvaluator(char grid[8][8])  {
	char my_color = 'm',opp_color = 'y';
    int myTotalTiles = 0;
    int opponentTitles = 0;
    int k;
    int myFrontTiles = 0;
    int opponentFrontTiles = 0;
    double p = 0.0;
    double c = 0.0;
    double l = 0.0;
    double m = 0.0;
    double f = 0.0;
    double d = 0.0;
    int x;
    int y;
    int X1[8];
    X1[0]=-1;
    X1[1]=-1;
    X1[2]=0;
    X1[3]=1;
    X1[4]=1;
    X1[5]=1;
    X1[6]=0;
    X1[7]=-1;

    int Y1[8];
    Y1[0]=0;
    Y1[1]=1;
    Y1[2]=1;
    Y1[3]=1;
    Y1[4]=0;
    Y1[5]=-1;
    Y1[6]=-1;
    Y1[7]=-1;
    
    int V[8][8];
    V[0][0]=20;V[0][1]=-3;V[0][2]=11;V[0][3]=8;V[0][4]=8;V[0][5]=11;V[0][6]=-3;V[0][7]=20;
    V[1][0]=-3;V[1][1]=-7;V[1][2]=-4;V[1][3]=1;V[1][4]=1;V[1][5]=-4;V[1][6]=-7;V[1][7]=-3;
    V[2][0]=11;V[2][1]=-4;V[2][2]=2;V[2][3]=2;V[2][4]=2;V[2][5]=2;V[2][6]=-4;V[2][7]=11;
    V[3][0]=8;V[3][1]=1;V[3][2]=2;V[3][3]=-3;V[3][4]=-3;V[3][5]=2;V[3][6]=1;V[3][7]=8;
    V[4][0]=8;V[4][1]=1;V[4][2]=2;V[4][3]=-3;V[4][4]=-3;V[4][5]=2;V[4][6]=1;V[4][7]=8;
    V[5][0]=11;V[5][1]=-4;V[5][2]=2;V[5][3]=2;V[5][4]=2;V[5][5]=2;V[5][6]=-4;V[5][7]=11;
    V[6][0]=-3;V[6][1]=-7;V[6][2]=-4;V[6][3]=1;V[6][4]=1;V[6][5]=-4;V[6][6]=-7;V[6][7]=-3;
    V[7][0]=20;V[7][1]=-3;V[7][2]=11;V[7][3]=8;V[7][4]=8;V[7][5]=11;V[7][6]=-3;V[7][7]=20;
    int row = -1;
    do{
        row++;
        int col = -1;
        do{
            col++;
            if(grid[row][col] == opp_color && grid[row][col] != my_color)
            {
                d = d - V[row][col];
                ++opponentTitles;
            }
            else
            {
                if(grid[row][col] == my_color && grid[row][col] != opp_color)  
                {
                    d = d + V[row][col];
                    ++myTotalTiles;
                } 
            }
            if(grid[row][col] == 'e') continue;

            k= -1;
            do{
                k++;
                x = row + X1[k]; 
                y = col + Y1[k];

                if(x<0 || x>7 || y<0 || y>7 or grid[x][y]!='e')
                    continue; 
    
                (grid[row][col] == my_color)?myFrontTiles++:opponentFrontTiles++;
                break;
                
            }while(k<7);
        }while(col<7);
    }while(row<7);

    if(myTotalTiles > opponentTitles)
    {
        p = (100.0 * myTotalTiles);
        p = p/(myTotalTiles + opponentTitles);
    }
    else
    {
        if(myTotalTiles < opponentTitles)
        {
            p = -(100.0 * opponentTitles);
            p = p/(myTotalTiles + opponentTitles);
        }
    }
    
    myTotalTiles = 0;
    opponentTitles = 0;
    
    if(myFrontTiles > opponentFrontTiles)
    {
        f = -(100.0 * myFrontTiles);
        f= f/(myFrontTiles + opponentFrontTiles);
    }
    else
    {
        if(myFrontTiles < opponentFrontTiles)
        {
            f = (100.0 * opponentFrontTiles);
            f = f/(myFrontTiles + opponentFrontTiles);
        }
    }

    
    if(grid[7][7] == my_color)
    {
        myTotalTiles++;
    }
    else{
        if(grid[7][7] == opp_color)
        {
            opponentTitles++;
        }
    } 
    if(grid[0][7] == my_color)
    {
        myTotalTiles++;
    }
    else{
        if(grid[0][7] == opp_color)
        {
            opponentTitles++;
        }
    } 
    if(grid[7][0] == my_color)
    {
        myTotalTiles++;
    }
    else{
        if(grid[7][0] == opp_color)
        {
            opponentTitles++;
        }
    } 
    if(grid[0][0] == my_color)
    {
        myTotalTiles++;
    }
    else{
        if(grid[0][0] == opp_color)
        {
            opponentTitles++;
        }
    } 
    int diff = (myTotalTiles - opponentTitles);
    myTotalTiles = 0;
    c = 25 * diff;
    opponentTitles = 0;
    
    if(grid[7][7] == 'e')   
    {
        (grid[6][6]==my_color)?myTotalTiles++:((grid[6][6] == opp_color)?opponentTitles++:opponentTitles+=0);
        (grid[6][7]==my_color)?myTotalTiles++:((grid[6][7] == opp_color)?opponentTitles++:opponentTitles+=0);
        (grid[7][6]==my_color)?myTotalTiles++:((grid[7][6] == opp_color)?opponentTitles++:opponentTitles+=0);
    }
    if(grid[0][0] == 'e')   {
        (grid[1][1]==my_color)?myTotalTiles++:((grid[1][1] == opp_color)?opponentTitles++:opponentTitles+=0);
        (grid[0][1]==my_color)?myTotalTiles++:((grid[0][1] == opp_color)?opponentTitles++:opponentTitles+=0);
        (grid[1][0]==my_color)?myTotalTiles++:((grid[1][0] == opp_color)?opponentTitles++:opponentTitles+=0);
    }
    
    if(grid[7][0] == 'e')   {
        (grid[6][1]==my_color)?myTotalTiles++:((grid[6][1] == opp_color)?opponentTitles++:opponentTitles+=0);
        (grid[7][1]==my_color)?myTotalTiles++:((grid[7][1] == opp_color)?opponentTitles++:opponentTitles+=0);
        (grid[6][0]==my_color)?myTotalTiles++:((grid[6][0] == opp_color)?opponentTitles++:opponentTitles+=0);
    }
    if(grid[0][7] == 'e')   {
        (grid[1][6]==my_color)?myTotalTiles++:((grid[1][6] == opp_color)?opponentTitles++:opponentTitles+=0);
        (grid[0][6]==my_color)?myTotalTiles++:((grid[0][6] == opp_color)?opponentTitles++:opponentTitles+=0);
        (grid[1][7]==my_color)?myTotalTiles++:((grid[1][7] == opp_color)?opponentTitles++:opponentTitles+=0);
    }
    int df = (myTotalTiles - opponentTitles);
    myTotalTiles = 0;
    l = -10 * df;
    myTotalTiles = numValidMoves(my_color, opp_color, grid);
    opponentTitles = 0;
    opponentTitles = numValidMoves(opp_color, my_color, grid);
    if(myTotalTiles > opponentTitles)
    {
        m = (100.0 * myTotalTiles);
        m = m/(myTotalTiles + opponentTitles);
    }
    else
    {
        if(myTotalTiles < opponentTitles)
        {
            m = -(100.0 * opponentTitles);
            m = m/(myTotalTiles + opponentTitles);
        }
    }
    double ans = (11 * p) + (850.724 * c);
    ans  = ans + (382.026 * l) + (86.922 * m);
    return ans + (78.396 * f) + (10 * d);
}

double testMyMove(OthelloBoard board, Move move, Turn turn, short level, double alpha, double beta) {
    finish = clock();
    double t = ((double)(finish-start)/CLOCKS_PER_SEC);
    if(t>1.95) {
        if(level&1)
        {
            return -1e18;
        }
        else
        {
            return 1e18;
        } 
    }
    Coin getTurn;
    list<Move>::iterator iter;
    double ret;
	if(level == 6) 
    {
		char grid[8][8];
        int row = -1;
        do
        {
            row++;
            int col = -1;
            do
            {
                col++;
                getTurn = board.get(row,col);
                (getTurn == turn)?(grid[row][col] = 'y'):((getTurn == other(turn))?grid[row][col] = 'm':grid[row][col] = 'e');
            } while (col<7);
            
        } while (row<7);
		double ans = othelloBoardEvaluator(grid);
        return ans;
	}
	board.makeMove(turn,move);
	turn = other(turn);
	list<Move> newMoves = board.getValidMoves(turn);
	iter = newMoves.begin();
	ret = -1e18;
	if(level&1)
    {
        ret = ret*(-1);
    } 
    if(newMoves.size())
    {
        do {
            if(iter==newMoves.end())
                break;
            level = level+1;
            double curr = testMyMove(board,*iter,turn,level,alpha,beta);
            level = level-1;
            double mini1 = min(ret,curr);
            double maxi1 = max(ret,curr);
            if(level&1) 
            {
                ret = mini1;
                beta = min(beta,ret);
            }
            else {
                ret = maxi1;
                alpha = max(alpha,ret);		
            }
            if(beta>alpha)
            {
                iter++;
            }
            else
                break;
        }while(true);
        return ret;
    }
    else
        return ret;
	 
}

double tester(OthelloBoard board,Turn turn) {
    char othelloSquare[8][8];
    int row = -1;
    Coin getTurn;
    do{
        row++;
        int col = -1;
        do{
            col++;
            getTurn = board.get(row,col);
            (getTurn == turn)?(othelloSquare[row][col] = 'm'):((getTurn == other(turn))?othelloSquare[row][col] = 'y':othelloSquare[row][col] = 'e');
        }while(col<7);
    }while(row<7);
    double ans;
    ans = othelloBoardEvaluator(othelloSquare);
    return ans;
}

bool compare(Move first, Move second) {
    OthelloBoard board1;
    OthelloBoard board2;
    board1 = globalBoard;
    board1.makeMove(myTurn,first);
    board2 = globalBoard;
    board2.makeMove(myTurn,second);
    double d1 = tester(board1,myTurn);
    double d2 = tester(board2,myTurn);
    if(d1>d2)
        return true;
    else
        return false;
}

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best othelloMoves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    start = clock();
    
    OthelloBoard b;
    double retVal,MAX,MIN;
    list<Move>::iterator it;
    retVal = -1e18;
    MAX = 1e18;
    MIN = -1e18;
    list<Move> othelloMoves = board.getValidMoves( turn );
    myTurn = turn;
    globalBoard = board;
    b = board;
    othelloMoves.sort(compare);
    it = othelloMoves.begin();
    Move optimumMove(it->x,it->y);
    short level = 1;
    do {
        if(it==othelloMoves.end())
            break;
    	double cur = testMyMove(b,*it,turn,level,MIN,MAX);
        if(cur <= retVal)
        {
            b = board;
            it++;
        }
        else
        {
            retVal = cur;
    		optimumMove = *it;
            b = board;
            it++;
        }	
    }while(true);
    return optimumMove;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}