/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <bits/stdc++.h>
using namespace std;
using namespace Desdemona;

// #define DEBUGTIME
// #define DEBUG
// #define DEBUGFINE

#define TIME_SAFETY 1.98


int highest_depth = 0;
int progress = 4;

class GNode {
    public:
    Turn mPlayer;
    Turn turn;
    Move move;
    double minmax;
    bool ismin;
    OthelloBoard board;
    GNode(GNode* p, OthelloBoard b, Turn pPlayer) : move(-1,-1) {
        board = b;
        mPlayer = pPlayer;
        parent = p;
    }
    
    GNode* parent;
    vector<GNode*> children;
};

Turn get_other(Turn t) {
    return other(t);
    
}

class Heuristics {
    public:
    static double getScore(OthelloBoard b, Turn self) {
        // int progress = b.getBlackCount() + b.getRedCount();
        int moves_self = b.getValidMoves(self).size();
        int moves_other = b.getValidMoves(get_other(self)).size();
        if(moves_other + moves_self == 0) {
            // game over state
            return finalScore(b, self);
        }
        if(progress < 12) {
            return startGameScore(b, self);
        } else if (progress < 56) {
            return midGameScore(b, self);
        } else {
            return endGameScore(b, self)*10;
        }
        return 0; // for compiler
    }

    static double mobilityScore(OthelloBoard b, Turn self) {
        int selfmoves = b.getValidMoves(self).size();
        Turn opp = (self == RED) ? BLACK : RED;
        int oppmoves = b.getValidMoves(opp).size();
        if(oppmoves == 0 && selfmoves == 0) return endGameScore(b, self);
        double mobility =  50*(double)(selfmoves - oppmoves);
        return mobility;
    }

    static double fortressHelper(OthelloBoard b, Turn self) {
        vector<vector<int>> stable(8, vector<int> (8, 0));
        // left up
        int i = 0, j = 0;
        if(b.get(i,j) == self)
        for (i = 0; i < 8; i ++) {
            for (j = 0; j < 8; j ++) {
                if(b.get(i,j) != self) {
                    break;
                } else {
                    stable[i][j] = 1;
                }
            }
            if(j == 0) {
                break;
            }
        }

        // left down
        i = 7, j = 0;
        if(b.get(i,j) == self)
        for (i = 7; i >= 0; i --) {
            for (j = 0; j < 8; j ++) {
                if(b.get(i,j) != self || stable[i][j] == 1) {
                    break;
                } else {
                    stable[i][j] = 1;
                }
            }
            if(j == 0) {
                break;
            }
        }

        // right down
        i = 7, j = 7;
        if(b.get(i,j) == self)
        for (i = 7; i >= 0; i --) {
            for (j = 7; j >= 0; j --) {
                if(b.get(i,j) != self || stable[i][j] == 1) {
                    break;
                } else {
                    stable[i][j] = 1;
                }
            }
            if(j == 7) {
                break;
            }
        }

        // right up
        i = 0, j = 7;
        if(b.get(i,j) == self)
        for (i = 0; i < 8; i ++) {
            for (j = 7; j >= 0; j --) {
                if(b.get(i,j) != self || stable[i][j] == 1) {
                    break;
                } else {
                    stable[i][j] = 1;
                }
            }
            if(j == 7) {
                break;
            }
        }
        double sum = 0;
        for(int i = 0; i < 8; i++)
        for (int j = 0; j < 8; j++)
        sum += stable[i][j];
        return sum;
    }

    static double fortressScore(OthelloBoard b, Turn self) {
        double dself = fortressHelper(b, self);
        double dopp = fortressHelper(b, get_other(self));

        return 150*(dself - dopp);
    }

    static double endGameScore(OthelloBoard b, Turn self) {
        int selfcount;
        int oppcount;
        if(self == RED) {
            selfcount = b.getRedCount();
            oppcount = b.getBlackCount();
        } else {
            selfcount = b.getBlackCount();
            oppcount = b.getRedCount();
        }
        if(oppcount == 0) return INFINITY;
        if(selfcount == 0) return -INFINITY;
        return (selfcount - oppcount);
    }

    static double finalScore(OthelloBoard b, Turn self) {
        int selfcount;
        int oppcount;
        if(self == RED) {
            selfcount = b.getRedCount();
            oppcount = b.getBlackCount();
        } else {
            selfcount = b.getBlackCount();
            oppcount = b.getRedCount();
        }
        if(selfcount == 0) return -INFINITY;
        else if(0 == oppcount) return INFINITY;
        // else return 0;
        return 1000*(selfcount - oppcount) ;
    }

    static double midGameScore(OthelloBoard b, Turn self) {
        // return positionScore(b, self);
        return hardPositionScore(b, self) + mobilityScore(b, self) + fortressScore(b, self);
    }

    static double startGameScore(OthelloBoard b, Turn self) {
        // return positionScore(b, self);
        return hardPositionScore(b, self) + mobilityScore(b, self);
    }

    static double positionScore(OthelloBoard b, Turn self) {
        Turn opp = (self == RED) ? BLACK : RED;
        vector<vector<int>> V(8);
        V[0] = {999,-128, 2, 2, 2, 2,-128,999};
    	V[1] = {-128,-480,-1, 0, 0,-1,-480,-128};
    	V[2] = {  4, -1, 1, 0, 0, 1, -1,  4};
    	V[3] = {  4,  0, 0, 2, 2, 0,  0,  4};
    	V[4] = {  4,  0, 0, 2, 2, 0,  0,  4};
    	V[5] = {  4, -1, 1, 0, 0, 1, -1,  4};
    	V[6] = {-128,-480,-1, 0, 0,-1,-480,-128};
    	V[7] = {999,-128, 4, 4, 4, 4,-128,999};
        // int selfpoints = 0;
        // int opppoints = 0;
        int t = 0;
        int i, j;
        for(i=0; i<8; i++)
		for(j=0; j<8; j++)  {
			if(b.get(i,j) == self)  {
				// selfpoints += V[i][j];
                t += V[i][j];
			} else if(b.get(i,j) == opp)  {
				// opppoints += V[i][j];
                t -= V[i][j];
			}
		}
        // return 40*(double)(selfpoints - opppoints)/(selfpoints + opppoints) + 0.6*cornerScore(b, self);
        return t;
    }

    static double hardPositionScore(OthelloBoard b, Turn self) {
        Turn opp = get_other(self);
        int t = 0;
        // int i, j;
        // corners
        if(b.get(0,0) == self) t += 800;
        else if(b.get(0,0) == opp) t -= 800;
        if(b.get(0,7) == self) t += 800;
        else if(b.get(0,7) == opp) t -= 800;
        if(b.get(7,7) == self) t += 800;
        else if(b.get(7,7) == opp) t -= 800;
        if(b.get(7,0) == self) t += 800;
        else if(b.get(7,0) == opp) t -= 800;
        // corner adj
        if(b.get(0,1) == self && b.get(0,0) != self) t -= 120;
        else if(b.get(0,1) == opp && b.get(0,0) != opp) t += 120;
        if(b.get(1,0) == self && b.get(0,0) != self) t -= 120;
        else if(b.get(1,0) == opp && b.get(0,0) != opp) t += 120;
        if(b.get(0,6) == self && b.get(0,7) != self) t -= 120;
        else if(b.get(0,6) == opp && b.get(0,7) != opp) t += 120;
        if(b.get(1,7) == self && b.get(0,7) != self) t -= 120;
        else if(b.get(1,7) == opp && b.get(0,7) != opp) t += 120;
        if(b.get(6,7) == self && b.get(7,7) != self) t -= 120;
        else if(b.get(6,7) == opp && b.get(7,7) != opp) t += 120;
        if(b.get(7,6) == self && b.get(7,7) != self) t -= 120;
        else if(b.get(7,6) == opp && b.get(7,7) != opp) t += 120;
        if(b.get(7,1) == self && b.get(7,0) != self) t -= 120;
        else if(b.get(7,1) == opp && b.get(7,0) != opp) t += 120;
        if(b.get(6,0) == self && b.get(7,0) != self) t -= 120;
        else if(b.get(6,0) == opp && b.get(7,0) != opp) t += 120; 
        // corner close diag
        if(b.get(1,1) == self && b.get(0,0) != self) t -= 400;
        else if(b.get(1,1) == opp && b.get(0,0) != opp) t += 400;
        if(b.get(6,1) == self && b.get(7,0) != self) t -= 400;
        else if(b.get(6,1) == opp && b.get(7,0) != opp) t += 400;
        if(b.get(6,6) == self && b.get(7,7) != self) t -= 400;
        else if(b.get(6,6) == opp && b.get(7,7) != opp) t += 400;
        if(b.get(1,6) == self && b.get(0,7) != self) t -= 400;
        else if(b.get(1,6) == opp && b.get(0,7) != opp) t += 400;
        return t;
    }
};

class AlphaBetaHybrid {
    static const int MAX_DEPTH_START = 8;
    static const int MAX_DEPTH_MID = 6;
    static const int MAX_DEPTH_END = 9;
    public:
    static Turn maxPlayer;
    // AlphaBetaHybrid(Turn _maxPlayer) {
    //     maxPlayer = _maxPlayer;
    // }
    static int COND_DEPTH(int num_coins) {
        if(num_coins < 12) {
            return MAX_DEPTH_START;
        } else if(num_coins < 56) {
            return MAX_DEPTH_MID;
        } else {
            return MAX_DEPTH_END;
        }
    }

    static Move iterativeDeepening(OthelloBoard b, Turn t) {
        list<Move> moves = b.getValidMoves(t);
        if(moves.size() == 0) return Move::pass();
        auto epoch = std::chrono::high_resolution_clock::now();
        int start_depth = 4;
        int end_depth = 40; // will surely go time critical, but okay.

        bool TERMINATE = false;
        Move temp(-1,-1);
        Move currentBest(-1,-1);
        int depth;
        for (depth = start_depth; depth <= end_depth; depth ++) {
            temp = selectBest(b, t, depth, epoch, TERMINATE);
            if(TERMINATE) {
                #ifdef DEBUGTIME
                cout << "Time critical!" << endl;
                #endif
                break;
            } else {
                currentBest = temp;
            }
        }
        #ifdef DEBUG
        cout << "Progress: Black:" <<  b.getBlackCount() << " Red:" << b.getRedCount() << "; Final depth: " << depth - 1 << endl;
        b.print();

        #endif
        highest_depth = max(highest_depth, depth - 1);

        return  b.validateMove(t, currentBest) ? currentBest : moves.front();
        // return  moves.front();
        
    }

    static Move selectBest(OthelloBoard b, Turn t, int depth, std::chrono::_V2::system_clock::time_point epoch, bool& TERMINATE) {
        if(TERMINATE || (double)(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now()-epoch).count())/(1e9) > TIME_SAFETY) {
            TERMINATE = true;
            return Move::empty();
        }
        double alpha = -INFINITY;
        double beta = +INFINITY;
        Move m(-1,-1);
        list<Move> moves = b.getValidMoves(t);
        AlphaBetaHybrid::maxPlayer = t; // explicit
        if(moves.size() == 0)
        return Move::pass();
        else {
            // m = moves.front();
            for (auto move:moves) {
                OthelloBoard b1 = b;
                b1.makeMove(maxPlayer, move);
                double value = AlphaBeta(b1, true, alpha, beta, depth - 1, epoch, TERMINATE);
                if(TERMINATE) {
                    return Move(-1,-1);
                }
                if(alpha < value || m == Move::pass()) {
                    alpha = value;
                    m = move;
                }
                if(alpha >= beta) break; // this would never happen, though.
            }
            return m;
        }
    }

    static double AlphaBeta (OthelloBoard b, bool ismin, double alpha, double beta, int depth, std::chrono::_V2::system_clock::time_point epoch, bool& TERMINATE) {
        if(TERMINATE || (double)(std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::high_resolution_clock::now()-epoch).count())/(1e9) > TIME_SAFETY) {
            TERMINATE = true;
            return Heuristics::getScore(b, maxPlayer);
        }
        if(depth == 0 || b.getBlackCount() + b.getRedCount() == 64) {
            return Heuristics::getScore(b, maxPlayer);
        }
        #ifdef DEBUGFINE
        cout << "At depth: " << depth << " not terminal. Alpha Start: " << alpha << " Beta Start: " << beta << endl;
        b.print();
        #endif
        if(!ismin) {
            list<Move> moves = b.getValidMoves(maxPlayer);
            if(moves.size() == 0) {
                if(b.getValidMoves(get_other(maxPlayer)).size() == 0) {
                    return Heuristics::finalScore(b, maxPlayer);
                }
                else {
                    alpha = max(alpha, AlphaBeta(b, !ismin, alpha, beta, depth, epoch, TERMINATE));
                    if(TERMINATE) {
                        return alpha;
                    }
                    if(alpha >= beta) return beta;
                    return alpha;
                }
            } else {
                for (auto move:moves) {
                    OthelloBoard b1 = b;
                    b1.makeMove(maxPlayer, move);
                    alpha = max(alpha, AlphaBeta(b1, !ismin, alpha, beta, depth - 1, epoch, TERMINATE));
                    if(TERMINATE) {
                        return alpha;
                    }
                    if(alpha >= beta) return beta;
                }
                return alpha;
            }
            
        } else {
            Turn minPlayer = get_other(maxPlayer);
            list<Move> moves = b.getValidMoves(minPlayer);
            if(moves.size() == 0) {
                if(b.getValidMoves(maxPlayer).size() == 0) {
                    return Heuristics::finalScore(b, maxPlayer);
                }
                else {
                    beta = min(beta, AlphaBeta(b, !ismin, alpha, beta, depth, epoch, TERMINATE));
                    if(TERMINATE) {
                        return beta;
                    }
                    if(alpha >= beta) return alpha;
                    return beta;
                }
            } else {
                for (auto move:moves) {
                    OthelloBoard b1 = b;
                    b1.makeMove(minPlayer, move);
                    beta = min(beta, AlphaBeta(b1, !ismin, alpha, beta, depth - 1, epoch, TERMINATE));
                    if(TERMINATE) {
                        return beta;
                    }
                    if(alpha >= beta) return alpha;
                }
                return beta;
            }
        }
    }
};

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );
        ~MyBot();

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

MyBot::~MyBot()
{
    cout << "Highest depth: " << highest_depth << endl;
}

Turn AlphaBetaHybrid::maxPlayer = BLACK;

Move MyBot::play( const OthelloBoard& board )
{
    #ifdef DEBUGTIME
    auto begin = std::chrono::high_resolution_clock::now();
    #endif
    AlphaBetaHybrid::maxPlayer = turn;
    progress = board.getBlackCount() + board.getRedCount();
    Move m = AlphaBetaHybrid().iterativeDeepening(board, turn);
    // Move m = AlphaBetaHybrid().playbyGT(board, turn);
    #ifdef DEBUGTIME
    auto end = std::chrono::high_resolution_clock::now();
    cout << fixed << setprecision(9) << "Elapsed: " << (double)(std::chrono::duration_cast<std::chrono::nanoseconds>(end-begin).count())/(1e9) << " seconds\n";
    #endif
    #ifdef DEBUG
    cout << "Highest depth: " << highest_depth << endl;
    #endif

    // sanity check
    if(board.validateMove(turn , m) == false) {
        list<Move> moves = board.getValidMoves(turn);
        if(moves.size() == 0) return Move::pass();
        else return moves.front();
    }
    return m;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}

