/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread.
         */
        MyBot( Turn turn );

        /**
         * Play something
         */
        virtual Move play( const OthelloBoard& board );
        virtual double searchTree(const OthelloBoard& board, Turn color, int depth, double alpha, double beta);
        virtual double Heuristic(const OthelloBoard& board);
    private:
      Turn ourColor;
      int HMat[8][8] = {{100, -10, 11, 6, 6, 11, -10, 100},
                        {-10, -20, 1, 2, 2, 1, -20, -10},
                        {11, 1, 5, 4, 4, 5, 1, 11},
                        {6, 2, 4, 2, 2, 4, 2, 6},
                        {6, 2, 4, 2, 2, 4, 2, 6},
                        {11, 1, 5, 4, 4, 5, 1, 11},
                        {-10, -20, 1, 2, 2, 1, -20, -10},
                        {100, -10, 11, 6, 6, 11, -10, 100}};
      int hBias[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
      int vBias[8] = {0, 1, 1, 1, 0, -1, -1, -1};
      clock_t startTime;
      clock_t endTime;
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
  ourColor = turn;
}

Move MyBot::play( const OthelloBoard& board )
{
    startTime = clock();
    list<Move> moves = board.getValidMoves( turn );
    list<Move>::iterator it = moves.begin();

    Move chosenMove = *it;
    double alpha = -1e18;
    double beta = 1e18;
    for(it = moves.begin(); it != moves.end(); it++){
      Move currentMove = *it;
      OthelloBoard currentBoard = board;
      currentBoard.makeMove(ourColor, currentMove);
      double currentHeuristic = searchTree(currentBoard, ourColor, 5, alpha, beta);
      if(currentHeuristic > alpha){
        alpha = currentHeuristic;
        chosenMove = *it;
      }
    }
    return chosenMove;
}

double MyBot::searchTree(const OthelloBoard& board, Turn color, int depth, double alpha, double beta){
    endTime = clock();
    double timeElapsed = double(endTime - startTime) / CLOCKS_PER_SEC;
    if(timeElapsed >= 1.999){
      if(color == ourColor){
          return alpha;
      }
      return beta;
    }

    list<Move> otherMoves = board.getValidMoves(other(color));
    list<Move>::iterator it = otherMoves.begin();

    if(depth == 0 || otherMoves.empty()){
        return Heuristic(board);
    }

    if(color == ourColor){
        for(it = otherMoves.begin(); it != otherMoves.end(); it++){
            OthelloBoard currentBoard = board;
            currentBoard.makeMove(other(color), *it);
            double newBeta = searchTree(currentBoard, other(color), depth - 1, alpha, beta);
            if(newBeta < beta){
              beta = newBeta;
            }
            if(alpha >= beta){
              return alpha;
            }
        }
        return beta;
    }
    else{
      for(it = otherMoves.begin(); it != otherMoves.end(); it++){
          OthelloBoard currentBoard = board;
          currentBoard.makeMove(other(color), *it);
          double newAlpha = searchTree(currentBoard, other(color), depth - 1, alpha, beta);
          if(newAlpha > alpha){
            alpha = newAlpha;
          }
          if(alpha >= beta){
            return beta;
          }
      }
      return alpha;
    }
}

double MyBot::Heuristic(const OthelloBoard& board){
    double countDiffHeuristic = 0;
    double cornerHeuristic = 0;
    double frontierHeuristic = 0;
    double diskHeuristic = 0;
    double cornerAdjHeuristic = 0;
    double mobilityHeuristic = 0;

    int ourFrontier = 0;
    int otherFrontier = 0;

    for(int i = 0; i < 8; i++){
      for(int j = 0; j < 8; j++){
        if(board.get(i, j) == ourColor){
          diskHeuristic += HMat[i][j];
        }
        else if(board.get(i, j) == other(ourColor)){
          diskHeuristic -= HMat[i][j];
        }
        if(board.get(i, j) != EMPTY){
          for(int k = 0; k < 8; k++){
            int x = i + hBias[k];
            int y = j + vBias[k];
            if(x >= 0 && x < 8 && y >= 0 && y < 8 && board.get(x, y) == EMPTY){
              if(board.get(i, j) == ourColor){
                ourFrontier++;
              }
              else{
                otherFrontier++;
              }
              break;
            }
          }
        }
      }
    }

    int ourTiles = 0;
    int otherTiles = 0;
    if(ourColor == RED){
      ourTiles = board.getRedCount();
      otherTiles = board.getBlackCount();
    }
    else if(ourColor == BLACK){
      otherTiles = board.getRedCount();
      ourTiles = board.getBlackCount();
    }

    countDiffHeuristic = (100 * ourTiles)/(ourTiles + otherTiles);
    if(countDiffHeuristic <= 50){
      countDiffHeuristic -= 100;
    }

    if(ourFrontier + otherFrontier > 0){
      frontierHeuristic = -(100.0 * ourFrontier)/(ourFrontier + otherFrontier);
      if(frontierHeuristic > -50){
        frontierHeuristic += 100;
      }
    }
    Turn leftTop = board.get(0, 0);
    Turn leftBottom = board.get(7, 0);
    Turn rightTop = board.get(0, 7);
    Turn rightBottom = board.get(7, 7);

    if(leftTop == ourColor){
      cornerHeuristic++;
    }
    else if(leftTop == other(ourColor)){
      cornerHeuristic--;
    }
    else{
      for(int i = 0; i < 2; i++){
        for(int j = 0; j < 2; j++){
          if(i != 0 || j != 0){
            if(board.get(i, j) == ourColor){
              cornerAdjHeuristic--;
            }
            else if(board.get(i, j) == other(ourColor)){
              cornerAdjHeuristic++;
            }
          }
        }
      }
    }

    if(leftBottom == ourColor){
      cornerHeuristic++;
    }
    else if(leftBottom == other(ourColor)){
      cornerHeuristic--;
    }
    else{
      if (board.get(7, 1) == ourColor) {
          cornerAdjHeuristic--;
      } else if (board.get(7, 1) == other(ourColor)) {
          cornerAdjHeuristic++;
      }
      if (board.get(6, 1) == ourColor) {
          cornerAdjHeuristic--;
      } else if (board.get(6, 1) == other(ourColor)) {
          cornerAdjHeuristic++;
      }
      if (board.get(6, 0) == ourColor) {
          cornerAdjHeuristic--;
      } else if (board.get(6, 0) == other(ourColor)) {
          cornerAdjHeuristic++;
      }
    }

    if(rightTop == ourColor){
      cornerHeuristic++;
    }
    else if(rightTop == other(ourColor)){
      cornerHeuristic--;
    }
    else{
      if (board.get(0, 6) == ourColor) {
          cornerAdjHeuristic--;
      } else if (board.get(0, 6) == other(ourColor)) {
          cornerAdjHeuristic++;
      }
      if (board.get(1, 6) == ourColor) {
          cornerAdjHeuristic--;
      } else if (board.get(1, 6) == other(ourColor)) {
          cornerAdjHeuristic++;
      }
      if (board.get(1, 7) == ourColor) {
          cornerAdjHeuristic--;
      } else if (board.get(1, 7) == other(ourColor)) {
          cornerAdjHeuristic++;
      }
    }

    if(rightBottom == ourColor){
      cornerHeuristic++;
    }
    else if(rightBottom == other(ourColor)){
      cornerHeuristic--;
    }
    else{
      for(int i = 6; i < 8; i++){
        for(int j = 6; j < 8; j++){
          if(i != 7 || j != 7){
            if(board.get(i, j) == ourColor){
              cornerAdjHeuristic--;
            }
            else if(board.get(i, j) == other(ourColor)){
              cornerAdjHeuristic++;
            }
          }
        }
      }
    }

    int ourValidMoves = board.getValidMoves(ourColor).size();
    int otherValidMoves = board.getValidMoves(other(ourColor)).size();
    if(ourValidMoves + otherValidMoves > 0){
      mobilityHeuristic = (100 * ourValidMoves)/(ourValidMoves + otherValidMoves);
      if(mobilityHeuristic <= 50){
        mobilityHeuristic -= 100;
      }
    }

    double score = 10 * countDiffHeuristic + 40086.2 * cornerHeuristic + 4775.325 * cornerAdjHeuristic + 78.922 * mobilityHeuristic + 74.396 * frontierHeuristic + 10 * diskHeuristic;
    return score;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}
