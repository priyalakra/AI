/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <climits>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        Turn player;
        int place_value[8][8] = {{20, -4, 11, 8, 8, 11, -4, 20},
                                   {-4, -7, -4, 1, 1, -4, -7, -4},
                                   {11, -4, 2, 2, 2, 2, -4, 11},
                                   {8, 1, 2, -3, -3, 2, 1, 8},
                                   {8, 1, 2, -3, -3, 2, 1, 8},
                                   {11, -4, 2, 2, 2, 2, -4, 11},
                                   {-4, -7, -4, 1, 1, -4, -7, -4},
                                   {20, -4, 11, 8, 8, 11, -4, 20}};
        clock_t start_time;
        clock_t end_time;
        pair<int,int> bias[8] = {make_pair(-1,0),make_pair(-1,1),make_pair(0,1),make_pair(1,1),make_pair(1,0),make_pair(1,-1),make_pair(0,-1),make_pair(-1,-1)};
        virtual Move play(const OthelloBoard &board);
        virtual double minimax(const OthelloBoard &board, Turn, int depth, double, double);
        virtual pair<double,double> disk_frontier(const OthelloBoard &board,Turn t);
        virtual pair<double,double> corner_and_adj(const OthelloBoard& board,Turn t);
        virtual double parity_heur(const OthelloBoard& board,Turn t);
        virtual double mobility_heur(const OthelloBoard& board,Turn t);
        virtual double Heuristic(const OthelloBoard &board);

    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
    player = turn;
}



Move MyBot::play( const OthelloBoard& board )
{
    start_time = clock();
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it = moves.begin();

    Move best_move = *it;
    double alpha = INT_MIN;
    double beta = INT_MAX;
    //int lookahead=5;
    for (auto i = moves.begin();i != moves.end();i++) {
        Move current_move = *i;
        OthelloBoard current_board = board;
        current_board.makeMove(player, current_move);
        double parameter = minimax(current_board,player,5, alpha, beta);
        if (parameter > alpha) {
            alpha = parameter;
            best_move = current_move;
        }
    }
    return best_move;
}

double elapsed_time(clock_t begin, clock_t end){
    int a = end-begin;
    int a_sec = a/CLOCKS_PER_SEC;
    return double(a_sec);
}

bool isLeafNode(int depth,list<Move> valid_moves){
    int num_valid = valid_moves.size();
    if(num_valid==0 || depth==0){
        return true;
    }
    return false;
}

double MyBot::minimax(const OthelloBoard &board, Turn t, int depth, double alpha, double beta) {

    end_time = clock();
    double a = double(end_time - start_time) / CLOCKS_PER_SEC;
    if (a >= 1.98) {
        if (t == player) {
            return alpha;
        } else {
            return beta;
        }
    }

    list<Move> moves = board.getValidMoves(other(t));
    list<Move>::iterator it = moves.begin();
    if (isLeafNode(depth,moves)) {
        return Heuristic(board);
    }

    if (t == player) {
        for (; it != moves.end(); it++) {
            Move current_move = *it;
            OthelloBoard current_board = board;
            current_board.makeMove(other(t), current_move);
            depth--;
            beta = min(beta, minimax(current_board, other(t), depth, alpha, beta));
            if (alpha >= beta) {
                return alpha;
            }
        }
        return beta;
    } else {
        for (; it != moves.end(); it++) {
            Move current_move = *it;
            OthelloBoard current_board = board;
            current_board.makeMove(other(t), current_move);
            depth--;
            alpha = max(alpha, minimax(current_board, other(t), depth, alpha, beta));
            if (alpha >= beta) {
                return beta;
            }
        }
        return alpha;
    }
}

bool is_valid(int i,int j,const OthelloBoard& board){
    bool flag = true;
    if(i<0 || i>=8 || j>0 || j>=8 || board.get(i,j)!=EMPTY){
        flag=false;
    }
    return flag;
}

double MyBot::parity_heur(const OthelloBoard& board,Turn colour){
    double parity_perc=0;
    int our_coins=0;
    int opp_coins=0;
    if(colour==RED){

        our_coins=board.getRedCount();
        opp_coins=board.getBlackCount();
    }
    else{
        our_coins=board.getBlackCount();
        opp_coins=board.getRedCount();
    }
    int total_coins = our_coins+opp_coins;

    parity_perc = (100 * our_coins)/(total_coins);
    if (parity_perc < 51) {
        parity_perc -= 100;
    }
    return parity_perc;
}

double MyBot::mobility_heur(const OthelloBoard& board,Turn colour){
    int our_valid_moves=0;
    int opp_valid_moves=0;
    int mobility_diff_perc = 0;
    our_valid_moves = board.getValidMoves(colour).size();
    opp_valid_moves = board.getValidMoves(other(colour)).size();
    int total_valid = our_valid_moves+opp_valid_moves;
    if(our_valid_moves!=0 && opp_valid_moves!=0){
        mobility_diff_perc = (100*our_valid_moves)/(total_valid);
        if(mobility_diff_perc<51){
            mobility_diff_perc-=100;
        }
    }
    return mobility_diff_perc;

}

pair<double,double> MyBot::corner_and_adj(const OthelloBoard& board,Turn colour){

    double c=0;
    double c_adj=0;
    Turn opp_colour = other(colour);

    if (board.get(0, 0) == colour) {
        c++;
    } else if (board.get(0, 0) == opp_colour) {
        c--;
    } else {
        if (board.get(0, 1) == colour) {
            c_adj++;
        } else if (board.get(0, 1) == opp_colour) {
            c_adj--;
        }
        if (board.get(1, 1) == colour) {
            c_adj++;
        } else if (board.get(1, 1) == opp_colour) {
            c_adj--;
        }
        if (board.get(1, 0) == colour) {
            c_adj++;
        } else if (board.get(1, 0) == opp_colour) {
            c_adj--;
        }
    }
    if (board.get(0, 7) == colour) {
        c++;
    } else if (board.get(0, 7) == opp_colour) {
        c--;
    } else {
        if (board.get(0, 6) == colour) {
            c_adj++;
        } else if (board.get(0, 6) == opp_colour) {
            c_adj--;
        }
        if (board.get(1, 6) == colour) {
            c_adj++;
        } else if (board.get(1, 6) == opp_colour) {
            c_adj--;
        }
        if (board.get(1, 7) == colour) {
            c_adj++;
        } else if (board.get(1, 7) == opp_colour) {
            c_adj--;
        }
    }
    if (board.get(7, 7) == colour) {
        c++;
    } else if (board.get(7, 7) == opp_colour) {
        c--;
    } else {
        if (board.get(6, 7) == colour) {
            c_adj++;
        } else if (board.get(6, 7) == opp_colour) {
            c_adj--;
        }
        if (board.get(6, 6) == colour) {
            c_adj++;
        } else if (board.get(6, 6) == opp_colour) {
            c_adj--;
        }
        if (board.get(7, 6) == colour) {
            c_adj++;
        } else if (board.get(7, 6) == opp_colour) {
            c_adj--;
        }
    }
    if (board.get(7, 0) == colour) {
        c++;
    } else if (board.get(7, 0) == opp_colour) {
        c--;
    } else {
        if (board.get(7, 1) == colour) {
            c_adj++;
        } else if (board.get(7, 1) == opp_colour) {
            c_adj--;
        }
        if (board.get(6, 1) == colour) {
            c_adj++;
        } else if (board.get(6, 1) == opp_colour) {
            c_adj--;
        }
        if (board.get(6, 0) == colour) {
            c_adj++;
        } else if (board.get(6, 0) == opp_colour) {
            c_adj--;
        }
    }

    return make_pair(c,c_adj);


}

pair<double,double> MyBot::disk_frontier(const OthelloBoard& board,Turn colour){
    int our_front=0;
    int opp_front=0;
    int total_front=0;
    double front_heur_perc=0;
    double disk_heur=0;
    int i=0;
    int j=0;
    while(i<8) {
        while(j<8) {
            if (board.get(i, j) == colour) {
                disk_heur += place_value[i][j];
            } else if (board.get(i, j) == other(colour)) {
                disk_heur -= place_value[i][j];
            }

            if (board.get(i, j) != EMPTY) {
                for (int k = 0; k < 8; k++) {
                    pair<int,int> bias_var = bias[k];
                    int horz = i + bias_var.first;
                    int vert = j + bias_var.second;
                    if (is_valid(horz,vert,board)) {
                        if (board.get(i, j) == colour) {
                            our_front++;
                        } else if (board.get(i, j) == other(colour)) {
                            opp_front++;
                        }
                        break;
                    }
                }
            }
            j++;
        }
        i++;
    }
    total_front=our_front+opp_front;
    
    if(total_front!=0){
        front_heur_perc=(100*our_front)/(total_front);
        if(front_heur_perc<51){
            front_heur_perc*=-1;
            front_heur_perc+=100;
        }
        else{
            front_heur_perc*=-1;
        }
    }
    return make_pair(disk_heur,front_heur_perc);
}

double MyBot::Heuristic(const OthelloBoard &board) {

    Turn colour = player;
    double move_value=0;
    move_value += 10*parity_heur(board,colour);
    move_value +=  78.992*mobility_heur(board,colour);
    pair<double,double> p = disk_frontier(board,colour);
    move_value += 10*p.first;
    move_value += 74.396*p.second;
    pair<double,double> cc = corner_and_adj(board,colour);
    move_value += 25*801.724*cc.first;
    move_value += (-12.5)*382.026*cc.second;

    return move_value;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


