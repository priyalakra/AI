/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        Turn our_turn;
        int Heuristic_Val[8][8] = {{19, -4, 11, 9, 9, 11, -4, 19},
                                   {-4, -7, -4, 1, 1, -4, -7, -4},
                                   {11, -4, 2, 2, 2, 2, -4, 11},
                                   {9, 1, 2, -3, -3, 2, 1, 9},
                                   {9, 1, 2, -3, -3, 2, 1, 9},
                                   {11, -4, 2, 2, 2, 2, -4, 11},
                                   {-4, -7, -4, 1, 1, -4, -7, -4},
                                   {19, -4, 11, 9, 9, 11, -4, 19}};
        int vertical_bias[8] = {0, 1, 1, 1, 0, -1, -1, -1};
        int horizontal_bias[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
        
        clock_t start_time;
        clock_t end_time;
        virtual int GetCoinCount(const OthelloBoard &board, Turn);
        virtual Move play(const OthelloBoard &board);
        virtual double AlphaBetaPrune(const OthelloBoard &board, Turn, int, double, double);
        virtual double Heuristic(const OthelloBoard &board, Turn);
        virtual double Disk_Heuristic(const OthelloBoard &board, Turn);
        virtual double Frontier_Heuristic(const OthelloBoard &board,Turn);
        virtual double Piece_difference_Heuristic(const OthelloBoard &board,Turn);
        virtual double Mobility_Heuristic(const OthelloBoard &board, Turn);
        virtual pair<double,double> Corner_Heuristics(const OthelloBoard &board, Turn);

    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
    our_turn = turn;
}

int MyBot::GetCoinCount(const OthelloBoard &board, Turn colour) {
    if (colour == BLACK) {
        return board.getBlackCount();
    } else if (colour == RED) {
        return board.getRedCount();
    } else {
        return 0;
    }
}

Move MyBot::play( const OthelloBoard& board )
{
    start_time = clock();
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it = moves.begin();

    Move best_move = *it;
    double alpha = -1e18;
    double beta = 1e18;
    for (; it != moves.end(); it++) {
        Move current_move = *it;
        OthelloBoard current_board = board;
        current_board.makeMove(our_turn, current_move);
        double parameter = AlphaBetaPrune(current_board, our_turn,5, alpha, beta);
        if (parameter > alpha) {
            alpha = parameter;
            best_move = current_move;
        }
    }
    return best_move;
}

double MyBot::AlphaBetaPrune(const OthelloBoard &board, Turn colour, int depth, double alpha, double beta) {

    //do not take more than 2 sec
    end_time = clock();
    if (double(end_time - start_time) / CLOCKS_PER_SEC >= 1.98) {
        if (colour == our_turn) {
            return alpha;
        } else {
            return beta;
        }
    }

    list<Move> moves = board.getValidMoves(other(colour));
    list<Move>::iterator it = moves.begin();

    //termination
    if (depth == 0 || moves.size() == 0) {
        return Heuristic(board, our_turn);
    }

    if (colour != our_turn)
    { // check alpha
        for (; it != moves.end(); it++) {
            Move current_move = *it;
            OthelloBoard current_board = board;
            current_board.makeMove(other(colour), current_move);
            alpha = max(alpha, AlphaBetaPrune(current_board, other(colour), depth - 1, alpha, beta));
            if (alpha >= beta) {
                break;
            }
        }
        return alpha;
    }
    else
    { // check beta
        for (; it != moves.end(); it++)
        {
            Move current_move = *it;
            OthelloBoard current_board = board;
            current_board.makeMove(other(colour), current_move);
            beta = min(beta, AlphaBetaPrune(current_board, other(colour), depth - 1, alpha, beta));
            if (alpha >= beta)
            {
                break;
            }
        }
        return beta;
    }
}

double MyBot::Disk_Heuristic(const OthelloBoard &board, Turn colour)
{
    double disk_heuristic = 0;
    for(int i=0;i<8;i++){
        for(int j=0;j<8;j++){
            if (board.get(i, j) == colour)
            {
                disk_heuristic += Heuristic_Val[i][j];
            }
            else if (board.get(i, j) == other(colour))
            {
                disk_heuristic -= Heuristic_Val[i][j];
            }
        }
    }
    return disk_heuristic;
}

double MyBot::Frontier_Heuristic(const OthelloBoard &board, Turn colour){
    double frontier_heuristic=0;
    int our_frontier_tiles = 0, opponent_frontier_tiles = 0;
    for(int i=0;i<8;i++){
       for(int j=0;j<8;j++){
            if(board.get(i,j)!=EMPTY){
                for (int k = 0; k < 8; k++)
                {
                    int x = i + horizontal_bias[k];
                    int y = j + vertical_bias[k];
                    if (x >= 0 && x < 8 && y >= 0 && y < 8 && board.get(x, y) == EMPTY)
                    {
                        if (board.get(i, j) == colour)
                        {
                            our_frontier_tiles++;
                        }
                        else if (board.get(i, j) == other(colour))
                        {
                            opponent_frontier_tiles++;
                        }
                        break;
                    }
                }
            }
       }
    }
    if (our_frontier_tiles + opponent_frontier_tiles > 0)
    {
        frontier_heuristic = -(100.0 * our_frontier_tiles) / (our_frontier_tiles + opponent_frontier_tiles);
        frontier_heuristic = (frontier_heuristic > -50)?(100+frontier_heuristic):frontier_heuristic;
    }
    return frontier_heuristic;
}

double MyBot::Piece_difference_Heuristic(const OthelloBoard &board, Turn colour){
    double piece_difference_heuristic = (100 * GetCoinCount(board, colour)) / (GetCoinCount(board, colour) + GetCoinCount(board, other(colour)));
    if (piece_difference_heuristic <= 50)
    {
        piece_difference_heuristic -= 100;
    }
    return piece_difference_heuristic;
}

double MyBot::Mobility_Heuristic(const OthelloBoard &board, Turn colour){
    double mobility_heuristic =0;
    if (board.getValidMoves(colour).size() + board.getValidMoves(other(colour)).size() != 0)
    {
        mobility_heuristic = (100 * board.getValidMoves(colour).size()) / (board.getValidMoves(colour).size() + board.getValidMoves(other(colour)).size());
        if (mobility_heuristic <= 50)
        {
            mobility_heuristic -= 100;
        }
    }
    return mobility_heuristic;
}

void tempfun(const OthelloBoard &board, Turn colour, double &corner_heuristic, double &corner_adjacent_heuristic,int a,int b,int c,int d)
{
    if (board.get(a, b) == colour)
    {
        corner_heuristic++;
    }
    else if (board.get(a, b) == 0)
    {
        if (board.get(c, d) == colour)
        {
            corner_adjacent_heuristic++;
        }
        else if (board.get(c,d) == other(colour))
        {
            corner_adjacent_heuristic--;
        }
        if (board.get(a,d) == colour)
        {
            corner_adjacent_heuristic++;
        }
        else if (board.get(a,d) == other(colour))
        {
            corner_adjacent_heuristic--;
        }
        if (board.get(c,b) == colour)
        {
            corner_adjacent_heuristic++;
        }
        else if (board.get(c,b) == other(colour))
        {
            corner_adjacent_heuristic--;
        }
    }
    else if (board.get(a, b) == other(colour))
    {
        corner_heuristic--;
    }
    else
    {
        ;
    }
}

pair<double,double> MyBot::Corner_Heuristics(const OthelloBoard &board, Turn colour){
    double corner_heuristic = 0;
    double corner_adjacent_heuristic = 0;
    tempfun(board,colour,corner_heuristic,corner_adjacent_heuristic,0,0,1,1);
    tempfun(board, colour, corner_heuristic, corner_adjacent_heuristic, 0, 7, 1, 6);
    tempfun(board, colour, corner_heuristic, corner_adjacent_heuristic, 7, 7, 6,6);
    tempfun(board, colour, corner_heuristic, corner_adjacent_heuristic, 7, 0, 6, 1);
    corner_heuristic *= 25;
    corner_adjacent_heuristic *= -12.5;
    return {corner_heuristic,corner_adjacent_heuristic};
}


double MyBot::Heuristic(const OthelloBoard &board, Turn colour){

    double piece_difference_heuristic = Piece_difference_Heuristic(board,colour);
    double frontier_heuristic = Frontier_Heuristic(board,colour);
    double disk_heuristic = Disk_Heuristic(board,colour);
    pair<double,double> cheuristics = Corner_Heuristics(board,colour);
    double corner_heuristic = cheuristics.first;
    double corner_adjacent_heuristic = cheuristics.second;
    double mobility_heuristic = Mobility_Heuristic(board,colour);
    double score = 10 * piece_difference_heuristic + 801.724 * corner_heuristic + 382.026 * corner_adjacent_heuristic + 78.922 * mobility_heuristic + 74.396 * frontier_heuristic + 10 * disk_heuristic;
    return score;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
