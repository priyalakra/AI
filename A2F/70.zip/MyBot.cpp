/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

/*
ASSIGNMENT 2 : AI : problem solving
Authors: Kankan Jana(CS21M026),Keyur Raval(CS21M029)

*/
#include <cstdlib>
#include "Othello.h"
#include <ctime>
#include "OthelloBoard.h"
#include <list>
#include "OthelloPlayer.h"

using namespace std;
using namespace Desdemona;

#define BORDLENGTH 8
#define INFINITE 1e18

bool can_move_piece(char, char, char *);
bool is_legal(char , char, char [][8], int , int );
int total_valid_moves(char , char , char [][8]);
double board_eval(char [][8]);
double check_move(OthelloBoard, Move , Turn , short , double , double);
double move_checker(OthelloBoard ,Turn );
bool move_compare(Move, Move);

OthelloBoard board_Global;
clock_t start_time, end_time;
Turn myTurn;

bool move_compare(Move a, Move b) {

    OthelloBoard one = board_Global, two = board_Global;
    one.makeMove(myTurn,a);
    two.makeMove(myTurn,b);
    return move_checker(one, myTurn) > move_checker(two, myTurn);
}

double move_checker(OthelloBoard board,Turn turn) {

    char g[BORDLENGTH][BORDLENGTH];
    int p;
    int q;
    for( p=0; p<BORDLENGTH;p++) {

        for( q=0; q<BORDLENGTH;q++) {

            Coin trn_fnd = board.get(p,q);
            if(trn_fnd == turn)
                g[p][q] = 'a';
            else if(trn_fnd == other(turn))
                g[p][q] = 'b';
            else
                g[p][q] = 'c';
        }
    }

    double val = board_eval(g);
    //cout<<val <<endl;

    return val;
}

double check_move(OthelloBoard board, Move move, Turn turn, short lvl, double alpha_val, double beta_val){

    end_time = clock();

    if(((double)(end_time-start_time)/CLOCKS_PER_SEC)>1.95){
        if(lvl&1)
            return -INFINITE;

        return INFINITE;
    }
    //cout<< lvl<<endl;
	if(lvl == 6) {
		char g[BORDLENGTH][BORDLENGTH];
		for(int i=0;i<BORDLENGTH;i++) {
			for(int j=0;j<BORDLENGTH;j++) {
				Coin trn_fnd = board.get(i,j);
				if(trn_fnd == turn) g[i][j] = 'b';
				else if(trn_fnd == other(turn)) g[i][j] = 'a';
				else g[i][j] = 'c';
			}
		}
		return board_eval(g);
	}

	board.makeMove(turn, move);
	turn = other(turn);
	list<Move> n_move = board.getValidMoves(turn);
	list<Move>::iterator itr = n_move.begin();
	double result = -INFINITE;

	if(lvl&1)
        result *= -1;
    //cout<< result<<endl;
	if(!(n_move.size()))
        return result;

	for(;itr!=n_move.end();itr++){

		double curr = check_move(board,*itr,turn,lvl+1,alpha_val,beta_val);
		if(lvl&1) {
			result = min(result,curr);
			beta_val = min(beta_val,result);
		}
		else {
			result = max(result,curr);
			alpha_val = max(alpha_val,result);		
		}
        //cout<<alpha_val<<endl;
        //cout<<beta_val<<endl;
		if(beta_val<=alpha_val)
            break;
	}

    //cout<< result<<endl;
	return result; 
}

double board_eval(char g[BORDLENGTH][BORDLENGTH])  {

	char m_clr = 'a',clr_opp = 'b';

    int m_tle = 0, tiles_opp = 0, i, j, k, m_frnt_tle = 0, opp_frnt_tiles = 0, x, y;

    double p = 0.0, c = 0.0, l = 0.0, m = 0.0, f = 0.0, d = 0.0;

    int B[] = {0, 1, 1, 1, 0, -1, -1, -1};
    int A[] = {-1, -1, 0, 1, 1, 1, 0, -1};

    //================================//
    //Reference : Learning to play Othello using approximate Qlearning
    //https://www.cs.huji.ac.il/w~ai/projects/2017/learning/Othello/files/Othello%20project%20report.pdf
    //================================//
    int GRID_BOX[BORDLENGTH][BORDLENGTH] = 	{ {100, -20, 10, 5, 5, 10, -20, 100}, 
                    {-20, -50, -2, -2, -2, -2, -50, -20},
                    {10, -2, -1, -1, -1, -1, -2, 10},
                    {5, -2, -1, -1, -1, -1, -2, 5},
                    {5, -2, -1, -1, -1, -1, -2, 5},
                    {10, -2, -1, -1, -1, -1, -2, 10},
                    {-20, -50, -2, -2, -2, -2, -50, -20},
                    {100, -20, 10, 5, 5, 10, -20, 100}};
    

    for(i = 0; i < BORDLENGTH; i++){

        for(j = 0; j < BORDLENGTH; j++){

            if(g[i][j] == m_clr){

                d += GRID_BOX[i][j];
                m_tle++;
            } 
            else if(g[i][j] == clr_opp){

                d -= GRID_BOX[i][j];
                tiles_opp++;
            }

            //cout<<d<<endl;
            //cout<<tiles_opp<<endl;
            if(g[i][j] != 'c'){

                for(k = 0; k < BORDLENGTH; k++){

                    x = i + A[k]; y = j + B[k];
                    if(x >= 0 && x < BORDLENGTH && y >= 0 && y < BORDLENGTH && g[x][y] == 'c'){

                        if(g[i][j] == m_clr)
                            m_frnt_tle++;
                        else
                            opp_frnt_tiles++;

                        //cout<<m_frnt<<endl;
                        //cout<<opp_frnt<<endl;
                        break;
                    }
                }
            }
        }
    }

    if(m_tle > tiles_opp)
        p = (100.0 * m_tle)/(m_tle + tiles_opp);
    else if(m_tle < tiles_opp)
        p = -(100.0 * tiles_opp)/(m_tle + tiles_opp);

    //cout<<"p: "<<p<<endl;
    if(m_frnt_tle > opp_frnt_tiles)
        f = -(100.0 * m_frnt_tle)/(m_frnt_tle + opp_frnt_tiles);
    else if(m_frnt_tle < opp_frnt_tiles)
        f = (100.0 * opp_frnt_tiles)/(m_frnt_tle + opp_frnt_tiles);

    //cout<<"f: "<<f<<endl;
    m_tle = tiles_opp = 0;
    if(g[0][0] == m_clr)
        m_tle++;
    else if(g[0][0] == clr_opp)
        tiles_opp++;
    
    //cout<<m_tle<<endl;
    //cout<<tiles_opp<<endl;
    if(g[0][7] == m_clr)
        m_tle++;
    else if(g[0][7] == clr_opp)
        tiles_opp++;
    
    //cout<<m_tle<<endl;
    //cout<<tiles_opp<<endl;
    if(g[7][0] == m_clr)
        m_tle++;
    else if(g[7][0] == clr_opp)
        tiles_opp++;
    
    //cout<<m_tle<<endl;
    //cout<<tiles_opp<<endl;
    if(g[7][7] == m_clr)
        m_tle++;
    else if(g[7][7] == clr_opp)
        tiles_opp++;

    //cout<<m_tle<<endl;
    //cout<<tiles_opp<<endl;

    c = 25 * (m_tle - tiles_opp);
    //cout<<c<<endl;

    m_tle = tiles_opp = 0;
    if(g[0][0] == 'c'){

        if(g[0][1] == m_clr)
            m_tle++;
        else if(g[0][1] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
        if(g[1][1] == m_clr)
            m_tle++;
        else if(g[1][1] == clr_opp)
            tiles_opp++;
        
        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
        if(g[1][0] == m_clr)
            m_tle++;
        else if(g[1][0] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
    }
    if(g[0][7] == 'c'){

        if(g[0][6] == m_clr)
            m_tle++;
        else if(g[0][6] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
        if(g[1][6] == m_clr)
            m_tle++;
        else if(g[1][6] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
        if(g[1][7] == m_clr)
            m_tle++;
        else if(g[1][7] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
    }
    if(g[7][0] == 'c'){
        if(g[7][1] == m_clr)
            m_tle++;
        else if(g[7][1] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
        if(g[6][1] == m_clr)
            m_tle++;
        else if(g[6][1] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
        if(g[6][0] == m_clr)
            m_tle++;
        else if(g[6][0] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
    }
    if(g[7][7] == 'c'){

        if(g[6][7] == m_clr)
            m_tle++;
        else if(g[6][7] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
        if(g[6][6] == m_clr)
            m_tle++;
        else if(g[6][6] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
        if(g[7][6] == m_clr)
            m_tle++;
        else if(g[7][6] == clr_opp)
            tiles_opp++;

        //cout<<m_tle<<endl;
        //cout<<tiles_opp<<endl;
    }
    l = -10 * (m_tle - tiles_opp);

    //cout<<l<<endl;
    m_tle = total_valid_moves(m_clr, clr_opp, g);
    tiles_opp = total_valid_moves(clr_opp, m_clr, g);

    //cout<<m_tle<<endl;
    //cout<<tiles_opp<<endl;

    if(m_tle > tiles_opp)
        m = (100.0 * m_tle)/(m_tle + tiles_opp);
    else if(m_tle < tiles_opp)
        m = -(100.0 * tiles_opp)/(m_tle + tiles_opp);

    //cout<<m<<endl;
    double final_score = (11 * p) + (850.724 * c) + (382.026 * l) + (86.922 * m) + (78.396 * f) + (10 * d);

    //cout<<final_score<<endl;
    return final_score;
}

int total_valid_moves(char self, char op, char g[BORDLENGTH][BORDLENGTH]){
	int c = 0;
	for(int p = 0; p < BORDLENGTH; p++)
        for(int q = 0; q < BORDLENGTH; q++)
            if(is_legal(self, op, g, p, q))
                c++;
    
    //cout<<c<<endl;
	return c;
}

bool is_legal(char self, char op, char g[BORDLENGTH][BORDLENGTH], int s_x, int s_y){

	if (g[s_x][s_y] != 'c')
        return false;

	char str[10];
	int x_val, y_val, val_x, val_y, ctr_val;

	for (val_y = -1; val_y <= 1; val_y++){

		for (val_x = -1; val_x <= 1; val_x++){
	        // keep going if both velocities are zero
			if (!val_y && !val_x)
                continue;

			str[0] = '\0';
			for (ctr_val = 1; ctr_val < BORDLENGTH; ctr_val++){

				x_val = s_x + ctr_val*val_x;
				y_val = s_y + ctr_val*val_y;

				if (x_val >= 0 && y_val >= 0 && x_val<BORDLENGTH && y_val<BORDLENGTH)
                    str[ctr_val-1] = g[x_val][y_val];
				else
                    str[ctr_val-1] = 0;
			}
			if (can_move_piece(self, op, str))
                return true;
		}
    }

	return false;
}

bool can_move_piece(char self, char op, char *str)  {

	if (str[0] != op){
        return false;
    } 
	for (int c = 1; c < BORDLENGTH; c++) {
		if (str[c] == 'c'){ return false;}
		if (str[c] == self){return true;}
	}
	return false;
}

///////////////////////
// Main class
//////////////////////

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best steps" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    start_time = clock();
    list<Move> steps = board.getValidMoves( turn );
    myTurn = turn;
    board_Global = board;
    steps.sort(move_compare);
    list<Move>::iterator it = steps.begin();
    Move bestMove((*it).x,(*it).y);
    double ret_val = -INFINITE;
    double MAX = INFINITE, MIN = -INFINITE;
    OthelloBoard copy_board = board;
    short lvl = 1;
    for(;it!=steps.end();it++) {
    	double currv = check_move(copy_board,*it,turn,lvl,MIN,MAX);
    	if(currv > ret_val) {
    		ret_val = currv;
    		bestMove = *it;
    	}
    	copy_board = board;
    }
    return bestMove;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}