/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <climits>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{

    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    
    private:
    //variables
        Turn our_turn;
        int Heuristic[8][8] = {    {20, -3, 11, 8, 8, 11, -3, 20},
                                   {-3, -7, -4, 1, 1, -4, -7, -3},
                                   {11, -4, 2, 2, 2, 2, -4, 11},
                                   {8, 1, 2, -3, -3, 2, 1, 8},
                                   {8, 1, 2, -3, -3, 2, 1, 8},
                                   {11, -4, 2, 2, 2, 2, -4, 11},
                                   {-3, -7, -4, 1, 1, -4, -7, -3},
                                   {20, -3, 11, 8, 8, 11, -3, 20}   };

        clock_t start_time;
        clock_t end_time;

    //Functions
        virtual int Num_coins(const OthelloBoard &board, Turn);
        virtual double Test_the_Move(const OthelloBoard &board, Turn, int, double, double);
        virtual double Get_Heuristic_val_of_Board(const OthelloBoard &board, Turn);
        bool isValid_pos(int x, int y);

        double heur_piece_diff(const OthelloBoard &board, Turn);
        double heur_cor(const OthelloBoard &board, Turn);
        double heur_fro(const OthelloBoard &board, Turn);
        double heur_disk(const OthelloBoard &board, Turn);
        double heur_cor_adj(const OthelloBoard &board, Turn);
        double heur_mob(const OthelloBoard &board, Turn);
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
    our_turn = turn;
}

Move MyBot::play( const OthelloBoard& board )
{
    start_time = clock();
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it = moves.begin();
    OthelloBoard curr_board = board;

    Move best_move = *it;
    double alpha = INT_MIN;
    double beta = INT_MAX;
    while (it != moves.end()) {
        Move curr_move = *it;
        curr_board = board;
        curr_board.makeMove(our_turn, curr_move);
        double Heuristic_value = Test_the_Move(curr_board, our_turn, 5, alpha, beta);

        if(Heuristic_value <= alpha)
            it++;
        else if (Heuristic_value > alpha) {
            alpha = Heuristic_value;
            best_move = curr_move;
            it++;
        }  
    }
    return best_move;
}

int MyBot::Num_coins(const OthelloBoard &board, Turn turn) {
    if(turn == EMPTY)
        return 0;
    int num_of_coins = (turn == RED)?(board.getRedCount()):(board.getBlackCount());
    return num_of_coins;
}

double MyBot::Test_the_Move(const OthelloBoard &board, Turn turn, int depth, double alpha, double beta) {


    end_time = clock();
    if (double(end_time - start_time) / CLOCKS_PER_SEC >= 1.98) {
        int ret_val = (turn == our_turn) ? alpha : beta;
        return ret_val;
    }

    list<Move> moves = board.getValidMoves(other(turn));
    list<Move>::iterator it = moves.begin();


    if (depth == 0 || moves.size() == 0) {
        return Get_Heuristic_val_of_Board(board, our_turn);
    }

    if (turn == our_turn) { 
        while (it != moves.end()) {
            Move curr_move = *it;
            OthelloBoard current_board = board;
            current_board.makeMove(other(turn), curr_move);
            beta = min(beta, Test_the_Move(current_board, other(turn), depth - 1, alpha, beta));
            if(alpha<beta)
            {
                it++;
                continue;
            }else
            if (alpha >= beta) {
                return alpha;
            }

            it++;
        }
        return beta;
    } 
    if(turn == other(our_turn)){
        while (it != moves.end()) {
            Move curr_move = *it;
            OthelloBoard current_board = board;
            current_board.makeMove(other(turn), curr_move);
            alpha = max(alpha, Test_the_Move(current_board, other(turn), depth - 1, alpha, beta));
            if(alpha<beta)
            {
                it++;
                continue;
            }else
            if (alpha >= beta) {
                return beta;
            }

            it++;
        }
        return alpha;
    }
    return 0;
}

bool MyBot::isValid_pos(int x, int y)
{
    if(x>=0 && x<8 && y>=0 && y<8)
        return true;
    return false;
}


double MyBot::heur_disk(const OthelloBoard &board, Turn turn) {
    double heur_disk = 0;
    for(int i=0; i<8; i++)
        for(int j=0; j<8; j++)
        {
            if(board.get(i,j) != EMPTY)
                heur_disk += (board.get(i,j) == turn) ? (Heuristic[i][j]) : (-1*Heuristic[i][j]);
        }
    return heur_disk;
     
}

double MyBot::heur_fro(const OthelloBoard &board, Turn turn) {
    int our_frontier_tiles = 0, opponent_frontier_tiles = 0;

    

    int surrounding_x[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
    int surrounding_y[8] = {0, 1, 1, 1, 0, -1, -1, -1};

    for(int i=0; i<8; i++)
        for(int j=0; j<8; j++)
        {
            if(board.get(i,j) != EMPTY)
            {
                for(int k=0; k<8; k++)
                {
                    int t = i+surrounding_x[k];
                    int m = j+surrounding_y[k];
                    if(isValid_pos(t,m) && board.get(t,m)==EMPTY)
                    {
                        if(board.get(i,j) != EMPTY)
                        {
                            our_frontier_tiles += (board.get(i,j) == turn) ? (1) : (0);
                            opponent_frontier_tiles += (board.get(i,j) == other(turn)) ? (1) : (0);
                        }
                        break;
                    }
                }
            }
        }


    int total_frontier_tiles = our_frontier_tiles + opponent_frontier_tiles;
    if(total_frontier_tiles <= 0)
        return 0;
    else
    if (total_frontier_tiles > 0) {
        double our_percent = our_frontier_tiles*100 / (total_frontier_tiles);
        if(our_percent > 50)
            return -1*our_percent;
        else
            return (100-our_percent);
    }

    return 0;
}

double MyBot::heur_piece_diff(const OthelloBoard &board, Turn turn) {
    double heur_piece_diff = 0;
    heur_piece_diff = (100*Num_coins(board,turn)) / (Num_coins(board, turn) + Num_coins(board, other(turn)));

    if(heur_piece_diff > 50)
        return heur_piece_diff;
    else 
        return -1*(100 - heur_piece_diff);
}

double MyBot::heur_cor(const OthelloBoard &board, Turn turn) {
    double heur_cor = 0;
    int corner_x[4] = {0,0,7,7};
    int corner_y[4] = {0,7,0,7};

    for(int i=0; i<4; i++)
    {
        if(board.get(corner_x[i] , corner_y[i]) != EMPTY)
            heur_cor += (board.get(corner_x[i] , corner_y[i]) == turn) ? (1) : (-1);
    }
    
    return heur_cor;
}

double MyBot::heur_cor_adj(const OthelloBoard &board, Turn turn) {
    double heur_cor_adj = 0;
  
    int corner_x[4] = {0,0,7,7};
    int corner_y[4] = {0,7,0,7};
    int surrounding_x[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
    int surrounding_y[8] = {0, 1, 1, 1, 0, -1, -1, -1};

    for(int i=0; i<4; i++)
    {
        if(board.get(corner_x[i] , corner_y[i]) == EMPTY)
        {
            for(int j=0; j<8; j++)
            {
                int x=corner_x[i]+surrounding_x[j];
                int y=corner_y[i]+surrounding_y[j];
                if(isValid_pos(x,y))
                {
                    if(board.get(x , y) != EMPTY)
                        heur_cor_adj += (board.get(x , y) == turn) ? (-1) : (1);
                }
            }
        }
    }


    return heur_cor_adj;
}

double MyBot::heur_mob(const OthelloBoard &board, Turn turn) {
    double heur_mob = 0;
  

    if (board.getValidMoves(turn).size() + board.getValidMoves(other(turn)).size() != 0) {
        heur_mob = (100 * board.getValidMoves(turn).size()) / (board.getValidMoves(turn).size() + board.getValidMoves(other(turn)).size());
        if (heur_mob <= 50) {
            heur_mob -= 100;
        }
    }  
    return heur_mob;
}

double MyBot::Get_Heuristic_val_of_Board(const OthelloBoard &board, Turn turn) {

    return 10 * heur_piece_diff(board,turn) + 780 *(26* heur_cor(board,turn)) + 380.026 *(12.5* heur_cor_adj(board,turn)) + 80 * heur_mob(board,turn) + 75 * heur_fro(board,turn) + 11 * heur_disk(board,turn);

}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


