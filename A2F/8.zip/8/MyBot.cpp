#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>

using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
        virtual int beta(const OthelloBoard& board, int depth, int alpha_min, int beta_max, clock_t start);
        virtual int alpha(const OthelloBoard& board, int depth, int alpha_min, int beta_max, clock_t start);
        virtual int heuristic(const OthelloBoard& board, Turn turn);
        virtual int corners(const OthelloBoard& board, Turn turn);
        virtual int stability(const OthelloBoard& board, Turn turn);
        virtual int mobility(const OthelloBoard& board, Turn turn);
        virtual int coins(const OthelloBoard& board, Turn turn);
        virtual int subpart_coins(const OthelloBoard& board, Turn turn);
        int move_num = 0;
        Turn my_color;
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    clock_t start;
    start = clock();
    move_num++;
    bool complete = true;
    int depth=4;
    if(board.getBlackCount() + board.getRedCount() >= 49){
        depth = 10;
    }
    if(board.getBlackCount() + board.getRedCount() >= 36){
        depth = 5;
    }
    
    if(move_num==1)my_color = turn;

    list<Move> moves = board.getValidMoves( turn );

    list<Move>::iterator it = moves.begin();
    int max_a = -1000000;
    int a;
    Move next_move = *moves.begin();
    for(int i=0; i < moves.size(); it++, i++){
        Move new_move= *it;
        if(new_move.x == 0 && new_move.y == 0) return new_move;
        if(new_move.x == 0 && new_move.y == 7) return new_move;
        if(new_move.x == 7 && new_move.y == 0) return new_move;
        if(new_move.x == 7 && new_move.y == 7) return new_move;
        Turn trn = turn;
        OthelloBoard my_board = board;
        my_board.makeMove(trn,new_move);
        a = beta(my_board,depth,max_a,1000000, start);
        if(a>max_a){
            max_a = a;
            next_move = new_move;
        }
    }
    return next_move;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}

int MyBot::beta(const OthelloBoard& board, int depth, int alpha_min, int beta_max, clock_t start){
    Turn turn_b = (turn==RED)?BLACK:RED;
    if(depth == 0){
        OthelloBoard my_board = board;
        return heuristic(my_board,turn);
    }
    if(((double)(clock() - start))/CLOCKS_PER_SEC >= 1.9){
        OthelloBoard my_board = board;
        return heuristic(my_board,turn);
    }
    list<Move> moves = board.getValidMoves( turn_b );
    
    list<Move>::iterator it = moves.begin();

    int min_b = beta_max;
    int b;
    for(int i=0; i < moves.size(); it++, i++){
        Turn trn_b = turn_b;
        OthelloBoard my_board = board;
        my_board.makeMove(trn_b,*it);
        b = alpha(my_board,depth-1,alpha_min,min_b, start);
        if(b<min_b){
            min_b = b;
            if(min_b<alpha_min)return alpha_min;
        }
    }

    if(moves.empty()){
        moves = board.getValidMoves( turn );
        if(moves.empty()){
            return heuristic(board, turn);
        }
        b = alpha(board, depth-1, alpha_min, min_b, start);
        if(b < min_b){
            min_b = b;
            if(min_b < alpha_min) return alpha_min;
        }
    }
    return min_b;
}

int MyBot::alpha(const OthelloBoard& board, int depth, int alpha_min, int beta_max, clock_t start){
    if(depth == 0){
        OthelloBoard my_board = board;
        return heuristic(my_board,turn);
    }
    if(((double)(clock() - start))/CLOCKS_PER_SEC >= 1.9){
        OthelloBoard my_board = board;
        return heuristic(my_board,turn);
    }
    list<Move> moves = board.getValidMoves( turn );
   
    list<Move>::iterator it = moves.begin();
    
    int max_a = alpha_min;
    int a;
    for(int i=0; i < moves.size(); it++, i++){
        Turn trn = turn;
        OthelloBoard my_board = board;
        my_board.makeMove(trn,*it);
        a = beta(my_board,depth-1,max_a,beta_max, start);
        if(a>max_a){
            max_a = a;
            if(max_a>beta_max)return beta_max;
        }
    }

    if(moves.empty()){
        moves = board.getValidMoves( (turn==RED)?BLACK:RED );
        if(moves.empty()){
            return heuristic(board, turn);
        }
        a = beta(board, depth-1, max_a, beta_max, start);
        if(a>max_a){
            max_a = a;
            if(max_a>beta_max)return beta_max;
        }
    }
    return max_a;
}

int MyBot::heuristic(const OthelloBoard& board, Turn turn){
    if(board.getRedCount() + board.getBlackCount() <= 16) return 50*corners(board, turn) + 25*coins(board, turn) + 25*stability(board, turn);
    if(board.getRedCount() + board.getBlackCount() <= 25) return 50*corners(board, turn) + 25*subpart_coins(board, turn);
    if(board.getRedCount() + board.getBlackCount() <= 36) return 50*corners(board, turn) + 25*subpart_coins(board, turn) + 5*mobility(board, turn)+ 25*stability(board, turn);;
    return 50*corners(board, turn) + 25*subpart_coins(board, turn) + 5*mobility(board, turn) + 25*stability(board, turn);
}

int MyBot::coins(const OthelloBoard& board, Turn turn){
    int black = board.getBlackCount();
    int red = board.getRedCount();

    if(black + red == 0) return 0;

    if(turn == BLACK) return 100*((float)(black - red)/(float)(black + red));
    else return 100*((float)(red - black)/(float)(black + red));
}

int MyBot::corners(const OthelloBoard& board, Turn turn){
    Turn turn_b = other(turn);
    int maxCount = 0;
    int minCount = 0;

    if(board.get(0, 0) == turn) maxCount++;
    else if(board.get(0, 0) == turn_b) minCount++;

    if(board.get(7, 7) == turn) maxCount++;
    else if(board.get(7, 7) == turn_b) minCount++;

    if(board.get(0, 7) == turn) maxCount++;
    else if(board.get(0, 7) == turn_b) minCount++;

    if(board.get(7, 0) == turn) maxCount++;
    else if(board.get(7, 0) == turn_b) minCount++;

    if(maxCount + minCount == 0) return 0;
    return 100*((float)(maxCount - minCount)/(float)(maxCount + minCount));
}

bool isCorner(int i, int j){
    return ((i == 0 || i == 7) && (j == 0 || j == 7));
}

bool nearCorner(int i, int j){
    return (isCorner(i-1, j) || isCorner(i-1, j-1) || isCorner(i, j-1) || isCorner(i, j+1) || isCorner(i+1, j+1) || isCorner(i+1, j) || isCorner(i-1, j+1) || isCorner(i+1, j-1));
}

int MyBot::stability(const OthelloBoard& board, Turn turn){
    Turn turn_b = other(turn);

    int arr[8][8]=	{ { 20, -3, 11, 8, 8, 11, -3, 20 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 20, -3, 11, 8, 8, 11, -3, 20 } };

    int maxCount = 0;
    int minCount = 0;
    for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            if((i == 0 && j == 1) || (i == 1 && j == 0)){
                if(board.get(i, j) == turn && board.get(0, 0) == turn) maxCount-=arr[i][j];
                else if(board.get(i,j) == turn) maxCount+=arr[i][j];
                if(board.get(i, j) == turn_b && board.get(0, 0) == turn_b) minCount-=arr[i][j];
                else if(board.get(i,j) == turn_b) minCount+=arr[i][j];
            }
            else if((i == 0 && j == 6) || (i == 1 && j == 7)){
                if(board.get(i, j) == turn && board.get(0, 7) == turn) maxCount-=arr[i][j];
                else if(board.get(i,j) == turn) maxCount+=arr[i][j];
                if(board.get(i, j) == turn_b && board.get(0, 7) == turn_b) minCount-=arr[i][j];
                else if(board.get(i,j) == turn_b) minCount+=arr[i][j];
            }
            else if((i == 7 && j == 1) || (i == 6 && j == 0)){
                if(board.get(i, j) == turn && board.get(7, 0) == turn) maxCount-=arr[i][j];
                else if(board.get(i,j) == turn) maxCount+=arr[i][j];
                if(board.get(i, j) == turn_b && board.get(7, 0) == turn_b) minCount-=arr[i][j];
                else if(board.get(i,j) == turn_b) minCount+=arr[i][j];
            }
            else if((i == 7 && j == 6) || (i == 6 && j == 7)){
                if(board.get(i, j) == turn && board.get(7, 7) == turn) maxCount-=arr[i][j];
                else if(board.get(i,j) == turn) maxCount+=arr[i][j];
                if(board.get(i, j) == turn_b && board.get(7, 7) == turn_b) minCount-=arr[i][j];
                else if(board.get(i,j) == turn_b) minCount+=arr[i][j];
            }
            else{
                if(board.get(i, j) == turn) maxCount+=arr[i][j];
                else if(board.get(i, j) == turn_b) minCount+=arr[i][j];
            }
        }
    }

    if(maxCount + minCount == 0) return 0;
    return 100*((float)(maxCount - minCount)/(float)(maxCount + minCount));
}

int MyBot::mobility(const OthelloBoard& board, Turn turn){
    int maxCount = board.getValidMoves(turn).size();
    int minCount = board.getValidMoves(other(turn)).size();

    if(maxCount + minCount == 0) return 0;
    return 100*((float)(maxCount - minCount)/(float)(maxCount + minCount));
}

int MyBot::subpart_coins(const OthelloBoard& board, Turn turn){
    int turn_arr[4] = {0};
    int turn_b_arr[4] = {0};
    Turn turn_b = other(turn);
    for(int i=0; i<4; i++){
        for(int j=0; j<4; j++){
            if(board.get(i, j) == turn) turn_arr[0]++;
            else if(board.get(i, j) == turn_b) turn_b_arr[0]++;
        }
    }
    for(int i=0; i<4; i++){
        for(int j=4; j<8; j++){
            if(board.get(i, j) == turn) turn_arr[1]++;
            else if(board.get(i, j) == turn_b) turn_b_arr[1]++;
        }
    }
    for(int i=4; i<8; i++){
        for(int j=0; j<4; j++){
            if(board.get(i, j) == turn) turn_arr[2]++;
            else if(board.get(i, j) == turn_b) turn_b_arr[2]++;
        }
    }
    for(int i=4; i<8; i++){
        for(int j=4; j<8; j++){
            if(board.get(i, j) == turn) turn_arr[3]++;
            else if(board.get(i, j) == turn_b) turn_b_arr[3]++;
        }
    }

    int val = 0;
    for(int i=0; i<4; i++){
        if(turn_arr[i] + turn_b_arr[i] != 0){
            val += 100*((float)(turn_arr[i] - turn_b_arr[i])/(float)(turn_arr[i] + turn_b_arr[i]));
        }
    }

    return val;
}
