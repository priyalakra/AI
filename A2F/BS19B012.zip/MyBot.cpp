#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <iostream>
#include <ctime>
using namespace std;
using namespace Desdemona;

clock_t start, finish;
OthelloBoard curr_board;

int num_moves = 0;
Turn my;

bool valid(char curr_c, char opp, char *sr)
{
	if (sr[0] == opp)
	{
		for (int cnt = 1; cnt < 8; cnt++)
		{
			if (sr[cnt] == 'n')
				return false;
			if (sr[cnt] == curr_c)
				return true;
		}
	}
	else
		return false;
	return false;
}

bool legal(char curr_c, char opp, char grid[8][8], int sx, int sy)
{
	if (grid[sx][sy] != 'n')
		return false;
	char sr[10];
	int x, y, hori, ver, cnt;
	for (ver = -1; ver <= 1; ver++)
		for (hori = -1; hori <= 1; hori++)
		{
			if (!ver && !hori)
				continue;
			sr[0] = '\0';
			for (cnt = 1; cnt < 8; cnt++)
			{
				x = sx + cnt * hori;
				y = sy + cnt * ver;
				if (x >= 0 && y >= 0 && x < 8 && y < 8)
					sr[cnt - 1] = grid[x][y];
				else
					sr[cnt - 1] = 0;
			}

			if (valid(curr_c, opp, sr))
				return true;
		}

	return false;
}

int num_valid(char curr_c, char opp, char grid[8][8])
{
	int count = 0, i, j;
	for (i = 0; i < 8; i++)
		for (j = 0; j < 8; j++)
			if (legal(curr_c, opp, grid, i, j))
				count++;
	return count;
}

double othelloBoardEvaluator(char grid[8][8], char flag)
{
	char my_color = 'x', opp_color = 'o';
	int myTiles = 0, oppTiles = 0, i, j, k, myFrontTiles = 0, oppFrontTiles = 0, x, y;
	double p = 0.0, c = 0.0, l = 0.0, m = 0.0, f = 0.0, d = 0.0;

	int hort[] = { -1, -1, 0, 1, 1, 1, 0, -1 };

	int vert[] = { 0, 1, 1, 1, 0, -1, -1, -1 };

	int pos_v[8][8] = {
		{ 100, -20, 10, 5, 5, 10, -20, 100 },
		{-20, -50, -2, -2, -2, -2, -50, -20
		},
		{ 10, -2, -1, -1, -1, -1, -2, 10 },
		{ 5, -2, -1, -1, -1, -1, -2, 5 },
		{ 5, -2, -1, -1, -1, -1, -2, 5 },
		{ 10, -2, -1, -1, -1, -1, -2, 10 },
		{-20, -50, -2, -2, -2, -2, -50, -20
		},
		{ 100, -20, 10, 5, 5, 10, -20, 100 },
	};

	for (i = 0; i < 8; i++)
		for (j = 0; j < 8; j++)
		{
			if (grid[i][j] == my_color)
			{
				d += pos_v[i][j];
				myTiles++;
			}
			else if (grid[i][j] == opp_color)
			{
				d -= pos_v[i][j];
				oppTiles++;
			}

			if (grid[i][j] != 'n')
			{
				for (k = 0; k < 8; k++)
				{
					x = i + hort[k];
					y = j + vert[k];
					if (x >= 0 && x < 8 && y >= 0 && y < 8 && grid[x][y] == 'n')
					{
						if (grid[i][j] == my_color)
							myFrontTiles++;
						else
							oppFrontTiles++;
						break;
					}
				}
			}
		}

	if (myTiles > oppTiles)
		p = (100.0 *myTiles) / (myTiles + oppTiles);
	else if (myTiles < oppTiles)
		p = -(100.0 *oppTiles) / (myTiles + oppTiles);

	if (myFrontTiles > oppFrontTiles)
		f = -(100.0 *myFrontTiles) / (myFrontTiles + oppFrontTiles);
	else if (myFrontTiles < oppFrontTiles)
		f = (100.0 *oppFrontTiles) / (myFrontTiles + oppFrontTiles);

	myTiles = 0;
	oppTiles = 0;
	int a = 0;
	int b = 0;
	for (int i = 0; i < 2; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			if (grid[a][b] == my_color)
				myTiles++;
			else if (grid[a][b] == opp_color)
				oppTiles++;
			b = 7;
		}

		a = 7;
		b = 0;
	}

	c = 25 *(myTiles - oppTiles);

	myTiles = 0;
	oppTiles = 0;
	if (grid[0][0] == 'n')
	{
		if (grid[0][1] == my_color) myTiles++;
		else if (grid[0][1] == opp_color) oppTiles++;
		if (grid[1][1] == my_color) myTiles++;
		else if (grid[1][1] == opp_color) oppTiles++;
		if (grid[1][0] == my_color) myTiles++;
		else if (grid[1][0] == opp_color) oppTiles++;
	}

	if (grid[0][7] == 'n')
	{
		if (grid[0][6] == my_color) myTiles++;
		else if (grid[0][6] == opp_color) oppTiles++;
		if (grid[1][6] == my_color) myTiles++;
		else if (grid[1][6] == opp_color) oppTiles++;
		if (grid[1][7] == my_color) myTiles++;
		else if (grid[1][7] == opp_color) oppTiles++;
	}

	if (grid[7][0] == 'n')
	{
		if (grid[7][1] == my_color) myTiles++;
		else if (grid[7][1] == opp_color) oppTiles++;
		if (grid[6][1] == my_color) myTiles++;
		else if (grid[6][1] == opp_color) oppTiles++;
		if (grid[6][0] == my_color) myTiles++;
		else if (grid[6][0] == opp_color) oppTiles++;
	}

	if (grid[7][7] == 'n')
	{
		if (grid[6][7] == my_color) myTiles++;
		else if (grid[6][7] == opp_color) oppTiles++;
		if (grid[6][6] == my_color) myTiles++;
		else if (grid[6][6] == opp_color) oppTiles++;
		if (grid[7][6] == my_color) myTiles++;
		else if (grid[7][6] == opp_color) oppTiles++;
	}

	l = -10 *(myTiles - oppTiles);

	myTiles = num_valid(my_color, opp_color, grid);
	oppTiles = num_valid(opp_color, my_color, grid);
	if (myTiles > oppTiles)
		m = (100.0 *myTiles) / (myTiles + oppTiles);
	else if (myTiles < oppTiles)
		m = -(100.0 *oppTiles) / (myTiles + oppTiles);

	if (num_moves < 20)
		return (11 *p) + (950 *c) + (420 *l) + (125 *m) + (65 *f) + (10 *d);

	return (13 *p) + (900 *c) + (400 *l) + (110 *m) + (78 *f) + (10 *d);
}

double alphabeta(OthelloBoard board, Move move, Turn turn, short depth, double alpha, double beta)
{
	finish = clock();
	if (((double)(finish - start) / CLOCKS_PER_SEC) > 1.95)
	{
		if (depth % 2 == 1) return -100000;
		return 100000;
	}

	if (depth == 6)
	{
		char grid[8][8];
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				Coin find = board.get(i, j);
				if (find == turn) grid[i][j] = 'o';
				else if (find == other(turn)) grid[i][j] = 'x';
				else grid[i][j] = 'n';
			}
		}

		return othelloBoardEvaluator(grid, 'l');
	}

	board.makeMove(turn, move);
	turn = other(turn);
	list<Move> get_moves = board.getValidMoves(turn);
	list<Move>::iterator ptr;
	double maxi_k = -100000;
	if (depth % 2 == 1)
		maxi_k *= -1;
	if (!get_moves.size())
	{
		int coindiff = 0;
		for (int i = 0; i < 8; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				Coin find = board.get(i, j);
				if (find == other(turn)) coindiff++;
				else if (find == turn) coindiff--;
			}
		}

		if (coindiff == 0)
			coindiff--;
		maxi_k *= coindiff;
		return maxi_k;
	}

	for (ptr = get_moves.begin(); ptr != get_moves.end(); ptr++)
	{
		double maxi_c = alphabeta(board, *ptr, turn, depth + 1, alpha, beta);

		if (depth % 2 == 1)
		{
			maxi_k = min(maxi_k, maxi_c);
			beta = min(beta, maxi_k);
		}
		else
		{
			maxi_k = max(maxi_k, maxi_c);
			alpha = max(alpha, maxi_k);
		}

		if (beta <= alpha)
			break;
	}

	return maxi_k;
}

double tester(OthelloBoard board, Turn turn)
{
	char grid[8][8];
	for (int i = 0; i < 8; i++)
	{
		for (int j = 0; j < 8; j++)
		{
			Coin find = board.get(i, j);
			if (find == turn)
				grid[i][j] = 'x';
			else if (find == other(turn))
				grid[i][j] = 'o';
			else
				grid[i][j] = 'n';
		}
	}

	return othelloBoardEvaluator(grid, 'i');
}

bool comp_fun(Move a, Move b)
{
	OthelloBoard board_a = curr_board;
	OthelloBoard board_b = curr_board;

	board_a.makeMove(my, a);
	board_b.makeMove(my, b);

	bool flag = false;
	if (tester(board_a, my) > tester(board_b, my))
		return true;
	return flag;

}

class MyBot: public OthelloPlayer
{
	public:
		/**
		 *Initialisation routines here
		 *This could do anything from open up a cache of "best moves" to
		 *spawning a background processing thread. 
		 */
		MyBot(Turn turn);

	/**
	 *Play something 
	 */
	virtual Move play(const OthelloBoard &board);
	private:
};

MyBot::MyBot(Turn turn): OthelloPlayer(turn) {}

Move MyBot::play(const OthelloBoard &board)
{
	num_moves++;
	start = clock();
	list<Move> moves = board.getValidMoves(turn);
	my = turn;
	curr_board = board;

	moves.sort(comp_fun);

	list<Move>::iterator it, f_ptr = moves.begin();
	Move bestMove((*f_ptr).x, (*f_ptr).y);

	double maxi_m = -100000;
	double MAX = 100000, MIN = -100000;

	OthelloBoard copyBoard = board;

	short depth = 1;

	for (it = moves.begin(); it != moves.end(); it++)
	{
		double currValue = alphabeta(copyBoard, *it, turn, depth, MIN, MAX);
		if (currValue > maxi_m)
		{
			maxi_m = currValue;
			bestMove = *it;
		}

		copyBoard = board;
	}

	finish = clock();
	return bestMove;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C"
{
	OthelloPlayer* createBot(Turn turn)
	{
		return new MyBot(turn);
	}

	void destroyBot(OthelloPlayer *bot)
	{
		delete bot;
	}
}