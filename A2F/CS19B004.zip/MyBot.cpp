/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <vector>
#include <float.h>
#include <algorithm>
using namespace std;
using namespace Desdemona;

clock_t start,ch1,ch2;
Turn maxColor;

#define INF 1e18
#define maxABDepth 5

int getStaticScore(vector<vector<int> > &board){
    vector<vector<int> > staticWeights = { 
                    { 20, -3, 11, 8, 8, 11, -3, 20 },
                    { -3, -7, -4, 1, 1, -4, -7, -3 },
                    { 11, -4, 2, 2, 2, 2, -4, 11 },
                    { 8, 1, 2, -3, -3, 2, 1, 8 },
                    { 8, 1, 2, -3, -3, 2, 1, 8 },
                    { 11, -4, 2, 2, 2, 2, -4, 11 },
                    { -3, -7, -4, 1, 1, -4, -7, -3 },
                    { 20, -3, 11, 8, 8, 11, -3, 20 } };
    /*vector<vector<int> > staticWeights = {
                    { 10, -3,  7,  6,  6,  7, -3, 10 },
                    { -3, -5, -4,  1,  1, -4, -5, -3 },
                    {  7, -4,  2,  2,  2,  2, -4,  7 },
                    {  6,  1,  2,  0,  0,  2,  1,  6 },
                    {  6,  1,  2,  0,  0,  2,  1,  6 },
                    {  7, -4,  2,  2,  2,  2, -4,  7 },
                    { -3, -5, -4,  1,  1, -4, -5, -3 },
                    { 10, -3,  7,  6,  6,  7, -3, 10 }
    };*/
    int res = 0;    
    for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            res += staticWeights[i][j] * board[i][j];
        }
    }
    return res;
}
bool boundCheck(int i, int j){
    if(i<0 || i>7 || j<0 || j>7){
        return false;
    }
    return true;
}
double getStability(vector<vector<int> > &board){
    int my = 0, opp = 0;
    int c =0;
    for(int i=0;i<8;i++){
        for(int j=0;j<8;j++){
            if(board[i][j] != 0){
                c = 0;
                if(boundCheck(i-1,j-1) && board[i-1][j-1] == 0){
                    c++;
                }
                if(boundCheck(i-1,j) && board[i-1][j] == 0){
                    c++;
                }
                if(boundCheck(i-1,j+1)&& board[i-1][j+1] == 0){
                    c++;
                }
                if(boundCheck(i,j-1)&& board[i][j-1] == 0){
                    c++;
                }
                if(boundCheck(i,j+1)&& board[i][j+1] == 0){
                    c++;
                }
                if(boundCheck(i+1,j-1)&& board[i+1][j-1] == 0){
                    c++;
                }
                if(boundCheck(i+1,j)&& board[i+1][j] == 0){
                    c++;
                }
                if(boundCheck(i+1,j+1)&& board[i+1][j+1] == 0){
                    c++;
                }
                if(board[i][j] == 1){my+=c;}else{opp+=c;}
            }
            
        }
    }
    double ret = ((double)my)/(my + opp);
    if(my > opp) ret = ret*(-100);
    else if(my < opp) ret = 100*(1-ret);
    else ret = 0;
    return ret;

}
double getHeuristicValue(OthelloBoard board){
    int myCoins = 0, oppCoins = 0;
    int myMobility = board.getValidMoves(maxColor).size();
    int oppMobility = board.getValidMoves(other(maxColor)).size();

    vector<vector<int> > intboard(8,vector<int>(8,0));

    for(int i=0; i<8; i++){
        for(int j=0; j<8; j++){
            if(board.get(i,j) == maxColor){
                intboard[i][j] = 1;
                myCoins++;
            }
            else if(board.get(i,j) == other(maxColor)){
                intboard[i][j] = -1;
                oppCoins++;
            }
        }
    }

    double statVal = 0.0;
    statVal = (double)getStaticScore(intboard);
    double cornerDiff = 0.0;
    cornerDiff = intboard[0][0]+intboard[0][7]+intboard[7][0]+intboard[7][7];
    double coinDiff = 0.0;
    coinDiff = ((double)(100.0))/(myCoins+oppCoins);
    if(myCoins > oppCoins){coinDiff *= myCoins;}
    else{coinDiff *= -oppCoins;}
    double closeCDiff = 0;
    if(intboard[0][0] == 0){
        closeCDiff = closeCDiff-intboard[0][1]-intboard[1][1]-intboard[1][0];
    }
    if(intboard[7][0] == 0){
        closeCDiff = closeCDiff-intboard[7][1]-intboard[6][1]-intboard[6][0];
    }
    if(intboard[0][7] == 0){
        closeCDiff = closeCDiff-intboard[0][6]-intboard[1][6]-intboard[1][7];
    }
    if(intboard[7][7] == 0){
        closeCDiff = closeCDiff-intboard[7][6]-intboard[6][6]-intboard[6][7];
    }

    double mobility = 0.0;
    mobility = ((double)(100))/(myMobility+oppMobility);
    if(myMobility > oppMobility){mobility *= myMobility;}
    else{mobility *= -oppMobility;}  
    double stability =  getStability(intboard);

    return statVal*10 + cornerDiff*20000.0 + closeCDiff*4000 + mobility*90 + coinDiff*10 + stability*80;

}


double RecAlphaBeta(OthelloBoard curboard, Move curMove, Turn curColor, int depth, double alpha, double beta){
    ch2 = clock();
    if((double)(ch2-start)/CLOCKS_PER_SEC > 1.95){
        if(depth%2==0){
            return -INF;
        }
        return INF;
    }

    double nodeVal;
    if(depth == maxABDepth){
        nodeVal = getHeuristicValue(curboard);
    }
    else{
        curboard.makeMove(curColor, curMove);
        Turn nxtColor = other(curColor);
        list<Move> nxtMoves = curboard.getValidMoves(nxtColor);
        double maxVal = -INF;
        double minVal = INF;
        if(depth%2 != 0){
            for(auto it = nxtMoves.begin(); it != nxtMoves.end(); ++it){
                double childVal = RecAlphaBeta(curboard,(*it),nxtColor,depth+1,alpha,beta);
                maxVal = max(childVal, maxVal);
                alpha = max(alpha, maxVal);
                if(beta <= alpha){
                    break;
                }
            }
            nodeVal = maxVal;
        }
        else{
            for(auto it = nxtMoves.begin(); it != nxtMoves.end(); ++it){
                double childVal = RecAlphaBeta(curboard,(*it),nxtColor,depth+1,alpha,beta);
                minVal = min(childVal, minVal);
                beta = min(beta, minVal);
                if(beta <= alpha){
                    break;
                }
            }
            nodeVal = minVal;
        }
    }
    return nodeVal;
}


class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

bool myCompare(pair<double,Move> a, pair<double,Move>  b) {
    return a.first>b.first;
}


Move MyBot::play( const OthelloBoard& board )
{
    start = clock();
    Turn myColor = turn;
    maxColor = turn;
    OthelloBoard temp;

    vector<pair<double,Move> > moveVal;
    list<Move> moves = board.getValidMoves(myColor);
    list<Move>::iterator it = moves.begin();
    
    for(it = moves.begin(); it != moves.end(); ++it){
        temp = board;
        temp.makeMove(myColor, (*it));
        moveVal.push_back(make_pair(getHeuristicValue(temp),(*it)));
    }

    sort(moveVal.begin(), moveVal.end(), myCompare);

    double best = -INF;
    Move bestMove = moveVal[0].second;

    for(int i=0; i < (int)moves.size(); ++i){
        temp = board;
        double retv = RecAlphaBeta(temp, moveVal[i].second, myColor, 0, -INF, INF);
        if(retv > best){
            best = retv;
            bestMove = moveVal[i].second;
        }
    }
    return bestMove;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}