
#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>
using namespace std;
using namespace Desdemona;
clock_t tbegin,tend;
Turn p_c;
#define INF 1e18
// Evaluation function is derived from multiple sources: kartikkukreja github, Washington DC research paper
double eval_func(OthelloBoard board)  {
    double m = 0.0,cc = 0.0, ss = 0.0, c = 0.0, ce = 0.0, v = 0.0; 
    char grid[8][8];
    int p_s = 0, o_s = 0, i, j, k, p_v = 0, o_v = 0, x, y,o_ce = 0,o_crnr = 0,p_ce = 0,p_crnr = 0;
    int p_m = board.getValidMoves(p_c).size();
    int o_m = board.getValidMoves(other(p_c)).size();
    int xx[]={0,7};
    int yy[]={0,7};
    int A[] = {-1, -1, 0, 1, 1, 1, 0, -1};                       
    int B[] = {0, 1, 1, 1, 0, -1, -1, -1};
    int mat[8][8] = { { 20, -3, 11, 8 , 8 , 11, -3, 20 },            
    				  { -3, -7, -4, 1 , 1 , -4, -7, -3 },
                      { 11, -4, 2 , 2 , 2 , 2 , -4, 11 },
                      { 8 , 1 , 2 , -3, -3, 2 , 1 , 8  },
                      { 8 , 1 , 2 , -3, -3, 2 , 1 , 8  },
                      { 11, -4, 2 , 2 , 2 , 2 , -4, 11 },
                      { -3, -7, -4, 1 , 1 , -4, -7, -3 },
                      { 20, -3, 11, 8 , 8 , 11, -3, 20 } };
    for(int i=0;i<8;i++) {
        for(int j=0;j<8;j++) {
            Coin findTurn = board.get(i,j);
            if(findTurn == p_c){                        
                p_s++;
                ss += 10*mat[i][j];
                grid[i][j] = 'x';
            }
            else if(findTurn == other(p_c)) {
                o_s++;
                ss -= 10*mat[i][j];
                grid[i][j] = 'o';
            }
            else grid[i][j] = '-';
        }
    }
    for(i = 0; i < 8; i++)
        for(j = 0; j < 8; j++)  {
            if(grid[i][j] == 'x')  {
                for(k = 0; k < 8; k++)  {
                    x = i + A[k]; y = j + B[k];
                    if(x >= 0 && x < 8 && y >= 0 && y < 8 && grid[x][y] == '-') {
                        p_v++;
                      }
                }
            } 
            else if(grid[i][j] == 'o')  {
                for(k = 0; k < 8; k++)  {
                    x = i + A[k]; y = j + B[k];
                    if(x >= 0 && x < 8 && y >= 0 && y < 8 && grid[x][y] == '-') {
                        o_v++;
                    }
                }
            }
        }
    for(int i=0;i<2;i++){
        for(int j=0;j<2;j++){
            int x1=xx[i],y1=yy[i];
            if(grid[x1][y1]=='-'){
                for(k = 0; k < 8; k++)  {
                    int x2 = x1 + A[k], y2 = y1 + B[k];
                    if(x2 >= 0 && x2 < 8 && y2 >= 0 && y2 < 8) {
                        if(grid[x2][y2] == 'x')  p_ce++;
                        else if(grid[x2][y2]=='o') o_ce++;
                        }
                }
            }
            else if(grid[x1][y1]=='x') p_crnr++;
            else o_crnr++;
        }
    }
    ce = -3820.26 * (p_ce - o_ce);      
    c = 25*850.724 * (p_crnr - o_crnr);
    // Vulnerability (v)
    if(p_v > o_v) v = -(7839.6 * p_v)/(p_v + o_v);
    else if(p_v < o_v) v = (7839.6 * o_v)/(p_v + o_v);
    // Total Coin count (cc)
    if(p_s > o_s) cc = (1190.0 * p_s)/(p_s + o_s);
    else if(p_s < o_s) cc = -(1190.0 * o_s)/(p_s + o_s);
    // Mobility (m)
    if(p_m > o_m) m = (8692.2 * p_m)/(p_m + o_m);
    else if(p_m < o_m) m = -8692.2 *(o_m)/(p_m + o_m);

    return cc + c + ce + m + v + ss;
}
double Min_Max(OthelloBoard board, Move move,Turn turn, int depth, double alpha, double beta,bool flag) {
    tend = clock();
	if(((double)(tend-tbegin)/CLOCKS_PER_SEC)>1.90) {
        if(turn == p_c){
            return -INF;
        }
        else{
            return INF;
        }
    }
	if(depth == 6) {
		return eval_func(board);
	}
    else{
        board.makeMove(turn,move);
        turn = other(turn);
        list<Move> moves = board.getValidMoves(turn);
        if((moves.size())==0)
        {
            return eval_func(board);
        }
        if(flag) {
            for(auto it=moves.begin();it!=moves.end();it++) 
            {
                alpha = max(alpha,Min_Max(board,*it,turn,depth+1,alpha,beta,!flag));
                if(alpha >= beta) 
                    return beta;
            }
            return alpha;
        }
        else {
            for(auto it=moves.begin();it!=moves.end();it++) 
            {
                beta = min(beta,Min_Max(board,*it,turn,depth+1,alpha,beta,!flag));
                if(alpha >= beta) 
                    return alpha;
            }
            return beta;
        }
    }
}
class MyBot: public OthelloPlayer
{
    public:
        Turn turn;
        MyBot( Turn turn );
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn ) : OthelloPlayer( turn )
{
    this->turn=turn;
}
Move helper(OthelloBoard board,Turn turn,bool flag){
    Move best(0,0);
    if(flag){
        OthelloBoard temp = board;
        list<Move> moves = board.getValidMoves(turn);
        p_c = turn;  
        double max_val = -INF;
        for(auto it=moves.begin();it!=moves.end();it++) {
            double val = Min_Max(temp,*it,p_c,1,-INF,INF,!flag);
            if(val > max_val) {
                max_val = val;
                best = *it;
            }
            temp = board;
        }
    }
    return best;
}
Move MyBot::play( const OthelloBoard& board )
{
    tbegin = clock();
    return helper(board,turn,1);
}

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}