

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>
#include <climits>
using namespace std;
using namespace Desdemona;

OthelloBoard grid;
clock_t start,finish;
Turn p;
#define INF 1e18

// Evaluation function is derived from multiple sources: kartikkukreja github, Washington DC research paper
double heurisitc(OthelloBoard board)  {
    char grid[8][8];
    for(int i=0;i<8;i++) {
        for(int j=0;j<8;j++) {
            Coin find = board.get(i,j);
            if(find == p) grid[i][j] = 'x';
            else if(find == other(p)) grid[i][j] = 'o';
            else grid[i][j] = '-';
        }
    }
    char opp_color = 'o',my_color = 'x';
    double p1 = 0, c = 0, l = 0, m = 0, f = 0, d = 0;
    int my_tiles = 0, opp_tiles = 0, my_front_tiles = 0, opp_front_tiles = 0;
    int X[] = {-1, -1, 0, 1, 1, 1, 0, -1};                         // Used to scout the 9 neighbouring squares of a given square
    int Y[] = {0, 1, 1, 1, 0, -1, -1, -1};
    int V[8][8] = 	{ { 20, -3, 11, 8, 8, 11, -3, 20 },             // Assign values to each square of the board according to their stability
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 20, -3, 11, 8, 8, 11, -3, 20 } };


	for(int i=0; i<8; i++)
		for(int j=0; j<8; j++)  {
			if(grid[i][j] == my_color)  {
				d += V[i][j];
				my_tiles++;
			} else if(grid[i][j] == opp_color)  {
				d -= V[i][j];
				opp_tiles++;
			}
			if(grid[i][j] != '-')   {
				for(int k=0; k<8; k++)  {
					int x = i + X[k]; int y = j + Y[k];
					if(x >= 0 && x < 8 && y >= 0 && y < 8 && grid[x][y] == '-') {
						if(grid[i][j] == my_color)  my_front_tiles++;
						else opp_front_tiles++;
						break;
					}
				}
			}
		}
	if(my_tiles > opp_tiles) p1 = (100.0 * my_tiles)/(my_tiles + opp_tiles);
	else if(my_tiles < opp_tiles) p1 = -(100.0 * opp_tiles)/(my_tiles + opp_tiles);

	if(my_front_tiles > opp_front_tiles) f = -(100.0 * my_front_tiles)/(my_front_tiles + opp_front_tiles);
	else if(my_front_tiles < opp_front_tiles) f = (100.0 * opp_front_tiles)/(my_front_tiles + opp_front_tiles);

	 /* Corner Occupancy*/
	my_tiles = opp_tiles = 0;
	if(grid[0][0] == my_color) my_tiles++;
	else if(grid[0][0] == opp_color) opp_tiles++;
	if(grid[0][7] == my_color) my_tiles++;
	else if(grid[0][7] == opp_color) opp_tiles++;
	if(grid[7][0] == my_color) my_tiles++;
	else if(grid[7][0] == opp_color) opp_tiles++;
	if(grid[7][7] == my_color) my_tiles++;
	else if(grid[7][7] == opp_color) opp_tiles++;
	c = 25 * (my_tiles - opp_tiles);
      /* Corner Closeness*/
	my_tiles = opp_tiles = 0;
	if(grid[0][0] == '-')   {
		if(grid[0][1] == my_color) my_tiles++;
		else if(grid[0][1] == opp_color) opp_tiles++;
		if(grid[1][1] == my_color) my_tiles++;
		else if(grid[1][1] == opp_color) opp_tiles++;
		if(grid[1][0] == my_color) my_tiles++;
		else if(grid[1][0] == opp_color) opp_tiles++;
	}
	if(grid[0][7] == '-')   {
		if(grid[0][6] == my_color) my_tiles++;
		else if(grid[0][6] == opp_color) opp_tiles++;
		if(grid[1][6] == my_color) my_tiles++;
		else if(grid[1][6] == opp_color) opp_tiles++;
		if(grid[1][7] == my_color) my_tiles++;
		else if(grid[1][7] == opp_color) opp_tiles++;
	}
	if(grid[7][0] == '-')   {
		if(grid[7][1] == my_color) my_tiles++;
		else if(grid[7][1] == opp_color) opp_tiles++;
		if(grid[6][1] == my_color) my_tiles++;
		else if(grid[6][1] == opp_color) opp_tiles++;
		if(grid[6][0] == my_color) my_tiles++;
		else if(grid[6][0] == opp_color) opp_tiles++;
	}
	if(grid[7][7] == '-')   {
		if(grid[6][7] == my_color) my_tiles++;
		else if(grid[6][7] == opp_color) opp_tiles++;
		if(grid[6][6] == my_color) my_tiles++;
		else if(grid[6][6] == opp_color) opp_tiles++;
		if(grid[7][6] == my_color) my_tiles++;
		else if(grid[7][6] == opp_color) opp_tiles++;
	}
	l = -12.5 * (my_tiles - opp_tiles);

        /* Mobility */
	my_tiles = board.getValidMoves(p).size();
	opp_tiles = board.getValidMoves(other(p)).size();
	if(my_tiles > opp_tiles) m = (100.0 * my_tiles)/(my_tiles + opp_tiles);
	else if(my_tiles < opp_tiles) m = -(100.0 * opp_tiles)/(my_tiles + opp_tiles);

     // final score
	double score = (10 * p1) + (801.724 * c) + (382.026 * l) + (78.922 * m) + (74.396 * f) + (10 * d);
	return score;
}

// Aplha beta algorithm
double Alphabeta(OthelloBoard o, Move m,Turn t,int l,double a, double b) {
    finish = clock();
    if(((double)(finish-start)/CLOCKS_PER_SEC)>1.95) {
        if(t == p) return -INF;
        return INF;
    }
	if(l == 6) {
		return heurisitc(o);
	}
	o.makeMove(t,m);
	t = other(t);
	list<Move> moves = o.getValidMoves(t);
    list<Move>::iterator it = moves.begin();
    if(!(moves.size())) return heurisitc(o);
    if(t==other(p)) {
        for(;it!=moves.end();it++) {
            b = min(b,Alphabeta(o,*it,t,l+1,a,b));
            if(a >= b) return a;
        }
        return b;
    }
    else {
        for(;it!=moves.end();it++) {
            a = max(a,Alphabeta(o,*it,t,l+1,a,b));
            if(a >= b) return b;
        }
        return a;
    }
}

class MyBot: public OthelloPlayer
{ 
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        Turn turn;
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
    this->turn=turn;
}

Move MyBot::play( const OthelloBoard& board )
{
    start = clock();
    list<Move> moves = board.getValidMoves(turn);
    p = turn;  
    Move bestMove((*moves.begin()).x,(*moves.begin()).y);
    double value = -INF;
    OthelloBoard temp = board;
    for(auto it = moves.begin();it!=moves.end();it++) {
    	double currval = Alphabeta(temp,*it,p,1,-INF,INF);
    	if(currval > value) {
    		value = currval;
    		bestMove = *it;
    	}
    	temp = board;
    }
    return bestMove;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}