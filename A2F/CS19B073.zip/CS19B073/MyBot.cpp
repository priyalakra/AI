/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}



Move MyBot::play( const OthelloBoard& board )
{
    list<Move> moves = board.getValidMoves(turn);
    //int randNo = rand() % moves.size();
    bool isBlack = false;
    
    if(turn == BLACK) isBlack = true;
    list<Move>::iterator t1 = moves.begin(); int maxCoins = -100;
    for(list<Move>::iterator it = moves.begin(); it != moves.end(); it++) {

        OthelloBoard board1 = board;
        board1.makeMove(turn, *it);
        list<Move> moves1 = board1.getValidMoves(other(turn)); int minCoins = 100;
        for(list<Move>::iterator it1 = moves1.begin(); it1 != moves1.end(); it1++) {
            OthelloBoard board2 = board1;
            board2.makeMove(other(turn), *it1);

            /*if(isBlack && board2.getBlackCount() < minCoins) minCoins = board2.getBlackCount();
            else if(!isBlack && board2.getRedCount() < minCoins) minCoins = board2.getRedCount();
            if(minCoins < maxCoins) break;*/

            list<Move> moves2 = board2.getValidMoves(turn); int maxCoins1  = -100;

            for(list<Move>::iterator it2 = moves2.begin(); it2 != moves2.end(); it2++) {

                OthelloBoard board3 = board2;
                board3.makeMove(turn, *it2);

                /*if(isBlack && board3.getBlackCount() > maxCoins1) maxCoins1 = board3.getBlackCount();
                else if(!isBlack && board3.getRedCount() > maxCoins1) maxCoins1 = board3.getRedCount();
                if(maxCoins1 > minCoins) break;*/


                list<Move> moves3 = board3.getValidMoves(other(turn)); int minCoins1  = 100;

                for(list<Move>::iterator it3 = moves3.begin(); it3 != moves3.end(); it3++) {

                    OthelloBoard board4 = board3;
                    board4.makeMove(other(turn), *it3);
                    list<Move> moves4 = board4.getValidMoves(turn); int maxCoins2  = -100;

                    for(list<Move>::iterator it4 = moves4.begin(); it4 != moves4.end(); it4++) {

                        OthelloBoard board5 = board4;
                        board5.makeMove(turn, *it4);
                        int x = board5.getBlackCount();
                        if(isBlack && x > maxCoins2) maxCoins2 = x;
                        else if(!isBlack && -x > maxCoins2) maxCoins2 = -x;
                        if(maxCoins2 > minCoins1) break;

                        /*list<Move> moves5 = board5.getValidMoves(other(turn)); int minCoins2  = 100;
                        for(list<Move>::iterator it5 = moves5.begin(); it5 != moves5.end(); it5++) {
                            OthelloBoard board6 = board5;
                            board6.makeMove(other(turn), *it5);
                            int x = board6.getBlackCount(), y = board6.getRedCount();
                            if(isBlack && x < minCoins2) minCoins2 = x;
                            else if(!isBlack && y < minCoins2) minCoins2 = y;
                            if(maxCoins2 > minCoins2) break;
                        }
                        if(maxCoins2 < minCoins2) minCoins2 = maxCoins2;
                        if(maxCoins2 > minCoins1) break;*/

                    }
                    if(maxCoins2 < minCoins1) minCoins1 = maxCoins2;
                    if(minCoins1 < maxCoins1) break;
                }
                if(minCoins1 > maxCoins1) maxCoins1 = minCoins1;
                if(maxCoins1 > minCoins) break;


            }
            if(maxCoins1 < minCoins) minCoins = maxCoins1;
            if(minCoins < maxCoins) break;
        }
        if(minCoins > maxCoins) {
            maxCoins = minCoins;
            t1 = it;
        }
    }
    return *t1;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}


