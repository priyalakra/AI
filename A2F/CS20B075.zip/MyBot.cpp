/*
 * @file botTemplate.cpp
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-02-04
 * Template for users to create their own bots
 */

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <vector>
using namespace std;
using namespace Desdemona;
Turn turny;
#define INF (1e18)
clock_t start, finish;

class MyBot : public OthelloPlayer
{
public:
    /**
     * Initialisation routines here
     * This could do anything from open up a cache of "best moves" to
     * spawning a background processing thread.
     */
    MyBot(Turn turn);
    Move bestMove(const OthelloBoard &, Turn);
    double ScoreMove(OthelloBoard, Move);
    double AlphaBetaPrune(OthelloBoard board, Move move, Turn turn, int level, double alpha, double beta);
    /**
     * Play something
     */
    virtual Move play(const OthelloBoard &board);

private:
};

MyBot::MyBot(Turn turn)
    : OthelloPlayer(turn)
{
    turny = turn;
}

double BoardEvaluator(OthelloBoard &board, vector<vector<char>> &grid)
{
    char my_color = 'm', opp_color = 'y';
    int myTiles = 0, oppTiles = 0, i, j, k, myFrontTiles = 0, oppFrontTiles = 0, x, y;
    double piece_difference = 0.0, corner_placement = 0.0, corner_closeness = 0.0, frontier_disks = 0.0, board_placement = 0.0;

    int X1[] = {-1, -1, 0, 1, 1, 1, 0, -1};
    int Y1[] = {0, 1, 1, 1, 0, -1, -1, -1};
    int V[8][8] = {{10, -3, 11, 8, 8, 11, -3, 10},
                   {-3, -7, -4, 1, 1, -4, -7, -3},
                   {9, -4, 2, 2, 2, 2, -4, 9},
                   {8, 1, 2, -3, -3, 2, 1, 8},
                   {8, 1, 2, -3, -3, 2, 1, 8},
                   {9, -4, 2, 2, 2, 2, -4, 9},
                   {-3, -7, -4, 1, 1, -4, -7, -3},
                   {10, -3, 11, 8, 8, 11, -3, 10}};
    // Piece difference, frontier disks and disk squares
    for (i = 0; i < 8; i++)
        for (j = 0; j < 8; j++)
        {
            if (grid[i][j] == my_color)
            {
                board_placement += V[i][j];
            }
            else if (grid[i][j] == opp_color)
            {
                board_placement -= V[i][j];
            }
            if (grid[i][j] != 'e')
            {
                if(grid[i][j] == my_color) myTiles++;
                else oppTiles++;
                for (k = 0; k < 8; k++)
                {
                    x = i + X1[k];
                    y = j + Y1[k];
                    if (x >= 0 && x < 8 && y >= 0 && y < 8 && grid[x][y] == 'e')
                    {
                        if (grid[i][j] == my_color)
                            myFrontTiles++;
                        else
                            oppFrontTiles++;
                        break;
                    }
                }
                if(grid[i][j] == my_color ) myTiles++;
                else oppTiles++;
            }
        }

    if (myTiles > oppTiles)
        piece_difference = (double)(myTiles) / (1.0*(myTiles + oppTiles));
    else if (myTiles < oppTiles)
        piece_difference = -(double)(oppTiles) / (1.0 * (myTiles + oppTiles));

    if (myFrontTiles > oppFrontTiles)
        frontier_disks = -(double)(myFrontTiles) / (1.0 * (myFrontTiles + oppFrontTiles));
    else if (myFrontTiles < oppFrontTiles)
        frontier_disks = (double)(oppFrontTiles) / (1.0 * (myFrontTiles + oppFrontTiles));
    piece_difference *=100.0;
    frontier_disks *= 100.0;

    // Corner occupancy
    myTiles = oppTiles = 0;
    int cornerCoords[] = {0, 7};
    for(int x: cornerCoords){
        for(int y: cornerCoords){
            if(grid[x][y] == my_color) myTiles++;
            if(grid[x][y] == opp_color) oppTiles++;
        }
    }
    corner_placement = 25 * (myTiles - oppTiles);

    // Corner closeness
    myTiles = oppTiles = 0;
    int start[] = {0, 1};
    int end[] = {6, 7};
    if (grid[0][0] == 'e')
    {
        for(int x: start){
            for(int y: start){
                if(x+y == 0) continue;
                if(grid[x][y] == my_color) myTiles++;
                else if(grid[x][y] == opp_color) oppTiles++;
            }
        }
    }
    if (grid[0][7] == 'e')
    {
        for(int x: start){
            for(int y: end){
                if(x == 0 && y == 7) continue;
                if(grid[x][y] == my_color) myTiles++;
                else if(grid[x][y] == opp_color) oppTiles++;
                
            }
        }
    }
    if (grid[7][0] == 'e')
    {
        for(int x:end){
            for(int y : start){
                if(x == 7 && y == 0) continue;
                if(grid[x][y] == my_color) myTiles++;
                else if(grid[x][y] == opp_color) oppTiles++;
            }
        }
    }
    if (grid[7][7] == 'e')
    {
        for(int x:end){
            for(int y:end){
                if(x == 7 && y == 7) continue;
                if(grid[x][y] == my_color) myTiles++;
                else if(grid[x][y] == opp_color) oppTiles++;
            }
        }
    }
    corner_closeness = -10 * (myTiles - oppTiles);

    double score = (100 * piece_difference) + (850 * corner_placement) + (380 * corner_closeness) + (80 * frontier_disks) + (10 * board_placement);
    return score;
}

vector<vector<char>> make_grid(OthelloBoard &board, Turn turn) {

        vector<vector<char>> grid(8, vector<char>(8));
        for (int i = 0; i < 8; i++)
        {
            for (int j = 0; j < 8; j++)
            {
                Coin findTurn = board.get(i, j);
                if (findTurn == turn)
                    grid[i][j] = 'y';
                else if (findTurn == other(turn))
                    grid[i][j] = 'm';
                else
                    grid[i][j] = 'e';
            }
        }
        return grid;
}

double MyBot::AlphaBetaPrune(OthelloBoard board, Move move, Turn turn, int level, double alpha, double beta)
{
    finish = clock();
    if (((double)(finish - start) / CLOCKS_PER_SEC) > 1.95)
    {
        if (level & 1)
            return beta;
        return alpha;
    }
    if (level == 6)
    {
        vector<vector<char>> grid = make_grid(board, turn);
        return BoardEvaluator(board, grid);
    }
    board.makeMove(turn, move);
    turn = other(turn);
    list<Move> newMoves = board.getValidMoves(turn);
    list<Move>::iterator iter = newMoves.begin();
    double ret = -INF;
    if (level %2 == 1)
        ret *= -1;
    if ((newMoves.size()) == 0)
        return ret;
    for (; iter != newMoves.end(); iter++)
    {
        double curr = AlphaBetaPrune(board, *iter, turn, level + 1, alpha, beta);
        if (level %2 == 1)
        {
            ret = min(ret, curr);
            beta = min(beta, ret);
        }
        else
        {
            ret = max(ret, curr);
            alpha = max(alpha, ret);
        }
        if (beta <= alpha)
            break;
    }
    return ret;
}

double MyBot::ScoreMove(OthelloBoard board, Move move)
{
    return AlphaBetaPrune(board, move, turn, 1, -INF, INF);
}

Move MyBot::bestMove(const OthelloBoard &board, Turn turn)
{
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it = moves.begin();
    Move final = (*it);
    vector<Move> corner;
    vector<Move> edge;
    vector<Move> rest;
    vector<Move> badMove;
    for (; it != moves.end(); it++)
    {
        if (((*it).x == 1 || (*it).x == 6) || ((*it).y == 1 || (*it).y == 6))
        {
            badMove.push_back((*it));
            continue;
        }
        if (((*it).x == 0 || (*it).x == 7) && ((*it).y == 0 || (*it).y == 7))
            corner.push_back((*it));
        else if (((*it).x == 0 || (*it).x == 7) || ((*it).y == 0 || (*it).y == 7))
            edge.push_back((*it));
        else
            rest.push_back((*it));
    }
    vector<Move> store;
    vector<double> storeScoreMove;
    if (corner.size() > 0)
    {
        final = corner[0];
        double val = ScoreMove(board, final);
        for (int i = 0; i < (int)corner.size(); i++)
        {
            double curVal = ScoreMove(board, corner[i]);
            storeScoreMove.push_back(curVal);
            if (val < curVal){
                val = curVal;
                final = corner[i];
            }
        }
        for (int i = 0; i < (int)corner.size(); i++)
        {
            if (val == storeScoreMove[i])
                store.push_back(corner[i]);
        }
        return store[rand() % (store.size())];
    }
    if (edge.size() > 0)
    {
        final = edge[0];
        double val = ScoreMove(board, final);
        for (int i = 0; i < (int)edge.size(); i++)
        {
            double curVal = ScoreMove(board, edge[i]);
            storeScoreMove.push_back(curVal);
            if (val < curVal) {
                val = curVal;
                final = edge[i];
            }
        }
        for (int i = 0; i < (int)edge.size(); i++)
        {
            if (val== storeScoreMove[i])
                store.push_back(edge[i]);
        }
        return store[rand() % (store.size())];
    }
    if (rest.size() > 0)
    {
        final = rest[0];
        double val = ScoreMove(board, final);
        for (int i = 0; i < (int)rest.size(); i++)
        {
            double curVal = ScoreMove(board, rest[i]);
            storeScoreMove.push_back(curVal);
            if (val < curVal) {
                val = curVal;
                final = rest[i];
            }
        }
        for (int i = 0; i < (int)rest.size(); i++)
        {
            if (val == storeScoreMove[i])
                store.push_back(rest[i]);
        }
        return store[rand() % (store.size())];
    }
    final = badMove[0];
    double val = ScoreMove(board, final);
    for (int i = 0; i < (int)badMove.size(); i++)
    {
        double curVal = ScoreMove(board, badMove[i]);
        storeScoreMove.push_back(curVal);
        if (val < curVal) {
            val = curVal;
            final = badMove[i];
        }
    }
    for (int i = 0; i < (int)badMove.size(); i++)
    {
        if (val == storeScoreMove[i])
            store.push_back(badMove[i]);
    }
    return store[rand() % (store.size())];
}


Move MyBot::play(const OthelloBoard &board)
{
    start = clock();
    try {
    return bestMove(board, turn);
    } catch(...){
        cerr<<"Uncaught exception and I don't know why";
        list<Move> something = board.getValidMoves(turn);
        return *something.begin();
    }
        
}


// The following lines are _very_ important to create a bot module for Desdemona

extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
