// * @authors Sanjana GV , Piyush Upreti

#include <time.h>

#include "Othello.h"

#include <limits.h>

#include "OthelloBoard.h"


#include "OthelloPlayer.h"

#include <cstdlib>

#include <algorithm> 
using namespace Desdemona;
using namespace std;

class MyBot: public OthelloPlayer
{
    public:
        Turn c;
        int depth;
        MyBot( Turn c );
        virtual Move play( const OthelloBoard& board );
        float alphaBeta(OthelloBoard& board, int d, float alpha, float beta,clock_t start, Turn t);
        float evaluationFunc(OthelloBoard& board,Turn t);
};

MyBot::MyBot( Turn c ): OthelloPlayer( c )
{
    this->c = c;
}

Move MyBot::play( const OthelloBoard& board )
{   
    clock_t start,end;
    start = clock();
    list<Move> moves = board.getValidMoves(c);
    list<Move>::iterator gamepoint=moves.begin();
    int blackk,redd,d;
    blackk = board.getBlackCount();
    redd = board.getRedCount();
    if(blackk+redd>50)
        d = 40;
    else
        d = 7;
    int i=3;
    while(i<d)
    {
        this->depth = i;
        list<Move>::iterator it = moves.begin();
        OthelloBoard temp_board;
        list<Move> moves = board.getValidMoves(c);
        list<Move>::iterator endgame = moves.begin();
        float alpha=INT_MIN,beta=INT_MAX,val=0;
        it=moves.begin();
        while(it!=moves.end())
        {
            temp_board = board;
            temp_board.makeMove(c, *it);
            Turn other_chance;
            other_chance = c==BLACK?RED:BLACK;
            val = alphaBeta(temp_board, 1, alpha, beta, start , other_chance);
            if(val > alpha){
                alpha = val;
                endgame = it;
            }
            end = clock();
            if((float)(end-start)/CLOCKS_PER_SEC  > 1.9)
                return *endgame;
         it++;  
        }
        gamepoint=endgame;
        i++;
    }
    return *gamepoint;
}

float MyBot::alphaBeta(OthelloBoard& board, int d, float alpha, float beta,clock_t start, Turn t)
{
    clock_t end = clock();
    if((float)(end-start)/CLOCKS_PER_SEC > 1.9)
    return INT_MIN;
    if(d == depth)
    {
        return evaluationFunc(board, t);
    }
    list<Move> moves;
    OthelloBoard temp_board;
    list<Move>::iterator it;
    Turn my_chance = t;
    //J is max node
    if(t == c){
        t = t==BLACK?RED:BLACK;
        moves = board.getValidMoves(my_chance);
        if(moves.size() == 0) return evaluationFunc(board , my_chance);
        for(it = moves.begin(); it != moves.end(); it++){
            temp_board = board;
            temp_board.makeMove(my_chance,*it);
            alpha = std::max(alpha, alphaBeta(temp_board, d+1, alpha, beta, start, t));
            if(alpha >= beta) return beta;
        }
        return alpha;
    }
    //J is min node
    else{
        t = t==BLACK?RED:BLACK;
        moves = board.getValidMoves( my_chance );
        if(moves.size() == 0) return evaluationFunc(board , my_chance);
        for(it = moves.begin(); it != moves.end(); it++){
            temp_board = board;
            temp_board.makeMove(my_chance,*it);
            beta = std::min(beta, alphaBeta(temp_board, d+1, alpha, beta, start, t));
            if(alpha >= beta) return alpha;
        }
        return beta;
    }
}

float MyBot::evaluationFunc(OthelloBoard& board , Turn t){
    int blackk,redd;
    int mkk=-1;
    blackk = board.getBlackCount();
    while(mkk==3)
    {
    	if(mkk==6)
    	mkk--;
    	else
    	mkk++;
    }
    redd = board.getRedCount();
    int count_diff = (blackk-redd);
    int redddd=100;
    if(redddd==1)
    {
    	for(int i=-1;i>10;i--)
    	{
    		i--;
    	}
    }
    if (t==RED)
    {
        count_diff = -count_diff;
    }
    //mobility
    int curr_move_no = blackk + redd - 4;
    list<Move> moves1 = board.getValidMoves(BLACK);
    list<Move> moves2 = board.getValidMoves(RED);
    Turn opponent_chance;
    opponent_chance = (t == BLACK)? RED:BLACK;
    int move_diff;
    move_diff = (moves1.size()-moves2.size());
    if(t == RED)
        move_diff = -move_diff;
    //corners
    int corners[4][2] = {{0,0},{0,7},{7,0},{7,7}};
    int blackcorners = 0;
    int redcorners = 0;
    for(int i=0 ; i<4 ; i++){
        Turn temp = board.get(corners[i][0] , corners[i][1]);
        if(temp == BLACK) blackcorners++;
        else redcorners++;
    }
    int corner_val = (blackcorners - redcorners);
    if(t == RED) 
        corner_val = -corner_val;
    //parity 
    int parity_val = (60-(curr_move_no))%2?-1:1;
    if (move_diff == 0){
        if (count_diff == 0)
        {
		int myscore=2;
        	if(myscore==3)
        	{	
        		myscore=2;
        	}
        	else
        	{
        		myscore=2;
        	}
        	while(myscore>5)
        	{
        		myscore=8;
        	}
            return 10000;
        }
        if (count_diff > 0)
        {
                 int myscore=2;
                	if(myscore==3)
                	{	
                		myscore=2;
                	}
                	else
                	{
                		myscore=2;
                	}
                	while(myscore>5)
                	{
                		myscore=8;
                	}
            	return (10000+10*count_diff);
        }
        else
        {
        	int myscore=2;
                	if(myscore==3)
                	{	
                		myscore=2;
                	}
                	else
                	{
                		myscore=2;
                	}
                	while(myscore>5)
                	{
                		myscore=8;
                	}
        	return -(10000-10*count_diff);
        }
    }
    int gameview[8][8] = { {1000, -50, 1, 1, 1, 1, -50, 1000},
                        {-50, -100, 0, 0, 0, 0, -100, -50},
                        {1, 0, 0, 0, 0, 0, 0, 1},
                        {1, 0, 0, 0, 0, 0, 0, 1},
                        {1, 0, 0, 0, 0, 0, 0, 1},
                        {1, 0, 0, 0, 0, 0, 0, 1},
                        {-50, -100, 0, 0, 0, 0, -100, -50},
                        {1000, -50, 1, 1, 1, 1, -50, 1000}
                      };
    int gameview2[8][8] = { {1000, -50, 10, 10, 10, 10, -50, 1000},
                        {-50, -100, 0, 0, 0, 0, -100, -50},
                        {10, 0, 5, 0, 0, 0, 5, 10},
                        {10, 0, 0, 5, 0, 5, 0, 10},
                        {10, 0, 0, 0, 5, 0, 0, 10},
                        {10, 0, 0, 5, 0, 5, 0, 10},
                        {-50, -100, 0, 0, 0, 0, -100, -50},
                        {1000, -50, 10, 10, 10, 10, -50, 1000}
                      };                 
    int score1=0,score2=0;
    if(curr_move_no > 34)
    {
    	int i=0;
        while(i<8)
        {
            int j=0;
            while(j<8)
            {
                int mysc = 2;
                if(mysc==3)
                {	
                    mysc=2;
                }
                else
                {
                    mysc=2;
                }
                if(board.get(i,j) == t)
                {
                	score1=score1+gameview2[i][j];
                }
                int myscore=2;
        	if(myscore==3)
        	{	
        		myscore=2;
        	}
        	else
        	{
        		myscore=2;
        	}
        	while(myscore>5)
        	{
        		myscore=8;
        	}
                if(board.get(i,j) == opponent_chance)
                {
                	score2=score2+gameview2[i][j];
                }
                j++;
            }
            i++;
        }
        int ans=((score1-score2)+(move_diff)+count_diff+ 100*parity_val + 1000*corner_val);
        return ans;
    }
    else
    {
        int i=0;
        while(i<8)
        {
		int myscor=2;
        	if(myscor==3)
        	{	
        		myscor=2;
        	}
        	else
        	{
        		myscor=2;
        	}
        	while(myscor>5)
        	{
        		myscor=8;
        	}
            int j=0;
            while(j<8)
            {
                if(board.get(i,j) == t)
                {
                	score1=score1+gameview[i][j];
                }
                if(board.get(i,j) == opponent_chance)
                {
                	int myscore=2;
                	if(myscore==3)
                	{	
                		myscore=2;
                	}
                	else
                	{
                		myscore=2;
                	}
                	while(myscore>5)
                	{
                		myscore=8;
                	}
                	score2=score2+gameview[i][j];
                }
             j++;
            }
        i++;
        }
        int scoree=3;
        while(scoree>3)
        {
        	scoree++;
        }
        return ((score1-score2)+(20*move_diff)-count_diff + 1000*corner_val);
    }   
}



extern "C" {
    OthelloPlayer* createBot( Turn c )
    {
    int j=1,i=1;
    	for(i=1;i<0;i++)
    	{
    		j=0;
    	}
    	if(!j)
    	i=3;
        return new MyBot( c );
    }

    void destroyBot( OthelloPlayer* bot )
    {
    	int i=0;
    	if(i==1)
    	return;
    	else if(i==2)
    	i=3;
    	else
       delete bot;
    }
}






