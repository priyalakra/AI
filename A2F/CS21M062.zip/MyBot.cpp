/*
AI - Assignment 2
Group 39
Shivam Kumar CS21M062
Vansh Saini CS21M068
*/


/*
One player is black , and other is red. The two players take turns placing pieces with their color up on the board.
Each time they place a piece on the board it must be placed such that at least one of the other players pieces is flipped. 
To flip a piece, their piece must be directly in a line between an old piece of yours on the board, 
and the piece you just placed on the board.If a player is unable to place their piece on the board, they forfeit their turn.
The winner is the player with the most pieces on the board.
*/


#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <time.h>
#include <bits/stdc++.h>

#define my_vector list


using namespace std;
using namespace Desdemona;
         
/*
Defining Class MyBot 
This will contain all the required functions
*/
class MyBot : public OthelloPlayer
{
public:
    
    MyBot(Turn turn);

    // Functions
    virtual Move play(const OthelloBoard &board);
    virtual int AlphaBeta(const OthelloBoard &board, int depth, int alpha_min, int beta_max);
    virtual int heuristic(const OthelloBoard &board, Turn turn);
    virtual int update(int &a, int &max_a,int &beta_max);
    virtual int update1(int &b, int &min_b,int &alpha_min);
    virtual int calculate_hueristic(const OthelloBoard &board, Turn turn,vector<vector<int>> &hval,Turn beta);
  //virtual int helper(const OthelloBoard &new_board,int alpha_min);
    int move_num = 0;
    Turn my_color;

private:
};

MyBot::MyBot(Turn turn)
    : OthelloPlayer(turn)
{
}

// Implementation of above class functions


/*
calculate heuristic for max by adding all the value where our coin is placed minus all the values where opponent's coin is placed
*/
int MyBot :: calculate_hueristic(const OthelloBoard &board, Turn turn,vector<vector<int>> &hval,Turn beta)
{

    int temp = 0;

    for (int i = 0; i < hval[0].size(); i++)
    {
        for (int j = 0; j < hval.size(); j++)
        {
            if (board.get(i, j) == turn)
                temp += hval[i][j];
            if (board.get(i, j) == beta)
                temp -= hval[i][j];
        }
    }

    return temp;
}



//function to determine the next move for the current state of the board
int MyBot:: update(int &a, int &max_a,int &beta_max)
{
    if (a > max_a)
            {
                max_a = a;
                if (max_a > beta_max)
                    return 1;
            }
    return 0;
}

int MyBot:: update1(int &b, int &min_b,int &alpha_min)
{
    if (b < min_b)
            {
                min_b = b;
                if (min_b < alpha_min)
                    return 1;
            }
    return 0;
}

// int MyBot:: helper(const OthelloBoard &new_board,int alpha_min)
//      {
//         int x ;
//         x= AlphaBeta(new_board,3,alpha_min,200);
//         return x ;
//      }

Move MyBot::play(const OthelloBoard &board)    
{
  
    //gather all the movements that are presently feasible for max and then Let the first move come first.
    my_vector<Move> moves = board.getValidMoves(turn);
    my_vector<Move>::iterator it = moves.begin();

    Move best_next_move = *it;

    //establish a lower constraint for the alpha value
    int alpha_min = -199;
    int n = moves.size();
    int i =0;
    
    /*Finding the move that will result in the highest alpha value for each move of max.
    
      For that we make a fresh duplicate of the provided board
      
      and in the copy of the board, make each move one at a time.
      
      Then to determine the alpha value for this move, call the alphabeta function.
      
      If the alpha value soo obtained is greater then update the same and save the move.
    */
    while(i<n)
    {
         Turn alpha = turn;
         OthelloBoard new_board = board;
         new_board.makeMove(alpha, *it);
         int currn_alpha_value = AlphaBeta(new_board, 3, alpha_min, 200);
         
         if(alpha_min<currn_alpha_value  )
         {
            alpha_min = currn_alpha_value;
            best_next_move = *it;
         }
         i++;
         it++;
    }

    //return the following move with the greatest alpha value.
    return best_next_move;
}



/*
Function to calculate heuristic values for a given board position for max nodes
*/
int MyBot::heuristic(const OthelloBoard &board, Turn turn)
{
    // value assigned to each board square based on certain expert rating criteria
    vector<vector<int>>hval;
    vector<int> temp1 = {60, -10, 10, 2, 2, 10, -10, 60};
    vector<int> temp2 = {-10, -20, -2, -2, -2, -2, -20, -10};
    vector<int> temp3 = {10, -2, 7, 1, 1, 7, -2, 10};
    vector<int> temp4 = {2, -2, 1, 1, 1, 1, -2, 2};
    vector<int> temp5 = {2, -2, 1, 1, 1, 1, -2, 2};
    vector<int> temp6 = {10, -2, 7, 1, 1, 7, -2, 10};
    vector<int> temp7 = {-10, -20, -2, -2, -2, -2, -20, -10};
    vector<int> temp8 = {60, -10, 10, 2, 2, 10, -10, 60};


     hval.push_back(temp1);
     hval.push_back(temp2);
     hval.push_back(temp3);
     hval.push_back(temp4);
     hval.push_back(temp5);
     hval.push_back(temp6);
     hval.push_back(temp7);
     hval.push_back(temp8);
    
     Turn beta = other(turn);

     //first, let the hvalue be zero
     int hvalue = 0;
 
     return hvalue =  calculate_hueristic(board,turn,hval,beta);
    
}

/*
Using alpha beta pruning, the below function calculates the minimum and maximum values for each move.

Terminating condition - If the game tree is at its last level, then all of the nodes are terminal.
 
return the heuristic value     
*/
int MyBot::AlphaBeta(const OthelloBoard &board, int depth, int alpha_min, int beta_max)
{
    
    
    if (depth == 0)
        return heuristic(board, turn);
 
    /*
     If it is Max's turn, Max must decide which move to make. 
     First get all the currently possible moves for max
    */
    else if (!(depth % 2))
    {
        my_vector<Move> moves = board.getValidMoves(turn);
        my_vector<Move>::iterator it = moves.begin();

        /* initally we set max alpha value equal to alpha_min */
        int max_a = alpha_min;
        int a;
        int n = moves.size();
        int i = 0;
        /* for every move of max, find the move which will lead to maximum alpha value */
        /*
        For that we make a fresh duplicate of the provided board
      
      	and in the copy of the board, make each move one at a time.
      
      	Then to determine the alpha value for this move, call the alphabeta function.
      
      	If the alpha value soo obtained is greater then update the same and save the move.
        
        */
        
        while(i<n)
        {
            Turn trn = turn;
            OthelloBoard new_board = board;
            new_board.makeMove(trn, *it);
            a = AlphaBeta(new_board, depth - 1, max_a, beta_max);
            int x = update(a,max_a,beta_max);
            if(x)
                return beta_max;
            
            i++;
            it++;
        }

        // return the highest alpha value
        return max_a;
    }

    /*
     If it is min's turn, Max must decide which move to make. 
     First get all the currently possible moves for min
    */
    else
    {
        Turn beta = other(turn);

        my_vector<Move> moves = board.getValidMoves(beta);
        my_vector<Move>::iterator it = moves.begin();

        /* initally we set min beta value equal to beta_max */
        int min_b = beta_max;
        int b;

        /* for every move of min, find the move which will lead to minimum beta value */
        
        int n = moves.size();
        int i = 0;
        
        /*
        For that we make a fresh duplicate of the provided board
      
      	and in the copy of the board, make each move one at a time.
      
      	Then to determine the beta value for this move, call the alphabeta function.
      
      	If the beta value soo obtained is lesser then update the same and save the move.
        
        */
        while(i<n)
        {
            Turn trn_b = beta;
            OthelloBoard my_board = board;

            my_board.makeMove(trn_b, *it);

            int d1 = depth -1;
            b = AlphaBeta(my_board, d1, alpha_min, min_b);
            int x = update1(b,min_b,alpha_min);
            if(x)
                return alpha_min;

            i++;
            it++;
        }

        // return the beta value
        return min_b;
    }
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
