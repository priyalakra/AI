/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard &board );
        virtual int AlphaBetaPruning(const OthelloBoard &board, int a_min_, int b_max_, int d);
        virtual int HeuristicsFunction(const OthelloBoard &board, Turn turn);

    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard &board )
{
    list<Move> moves = board.getValidMoves( turn );
    list<Move>::iterator it = moves.begin();

    Move move_forward = *it;

    int min_alpha = -300;
    for (int i =0 ; i < moves.size(); i++, it++)
    {
        OthelloBoard new_ =  board; 
        Turn a = turn;
        new_.makeMove(a, *it);
        int alpha = AlphaBetaPruning(new_, min_alpha, 300, 3);
        if(alpha > min_alpha){
            min_alpha = alpha;
            move_forward = *it;
        }
    }
    return move_forward;
}

int MyBot::AlphaBetaPruning(const OthelloBoard &board, int a_min_, int b_max_, int d)
{
    if(d == 0){
        return HeuristicsFunction(board, turn);
    }
    else if(d % 2 == 0){
        list<Move> moves = board.getValidMoves(turn);
        list<Move>::iterator it = moves.begin();

        int maxm_alpha = a_min_;
        int alpha;

        for (int i =0 ; i < moves.size(); i++, it++)
        {
            Turn t = turn;
            OthelloBoard new_ = board;
            new_.makeMove(t, *it);
            alpha = AlphaBetaPruning(new_, maxm_alpha, b_max_, d-1);
            if(alpha > maxm_alpha){
                maxm_alpha = alpha;
                if(maxm_alpha > b_max_) return b_max_;
            }
        }
        return maxm_alpha;
    }
    else{
        Turn bt = other(turn);
        list<Move> moves = board.getValidMoves(bt);
        list<Move>::iterator it = moves.begin();
        int minm_beta = b_max_;
        int beta;
        for(int i =0 ; i < moves.size(); it++, i++){
            Turn trn = bt;
            OthelloBoard b_new = board;
            b_new.makeMove(trn, *it);
            beta = AlphaBetaPruning(b_new, a_min_, minm_beta, d-1);
            if(beta < minm_beta){
                minm_beta = beta;
                if(minm_beta <  a_min_) return a_min_;
            }
        }
        return minm_beta;
    }
}

int MyBot::HeuristicsFunction(const OthelloBoard& board , Turn turn)
{
    // taken from the paper https://courses.cs.washington.edu/courses/cse573/04au/Project/mini1/O-Thell-Us/Othellus.pdf
    int heuristic_values[8][8] = {100, -10, 11, 6, 6, 11, -10, 100,
                                  -10, -20, 1, 2, 2, 1, -20, -10,
                                  10, 1, 5, 4, 4, 5, 1, 10,
                                  6, 2, 4, 2, 2, 4, 2, 6,
                                  6, 2, 4, 2, 2, 4, 2, 6,
                                  10, 1, 5, 4, 4, 5, 1, 10,
                                  -10, -20, 1, 2, 2, 1, -20, -10,
                                  100, -10, 11, 6, 6, 11, -10, 100};
    
    int h = 0;
    Turn b = other(turn);
    for (int i=0 ; i < 8; i++){
        for (int j =0; j < 8; j++){
            if(board.get(i, j) == turn) h+= heuristic_values[i][j];
            if(board.get(i, j) == b) h-= heuristic_values[i][j];
        }
    }
    return h;
}
    // The following lines are _very_ important to create a bot module for Desdemona

    extern "C"
{
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}
