/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <iostream>
using namespace std;
using namespace Desdemona;


#define INF 999999
class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread.
         */

        MyBot( Turn turn );

        virtual Move play( const OthelloBoard& board );
        virtual int  test1(const OthelloBoard& board, int height, int min, int max);
        virtual int tester(const OthelloBoard& board, int height, int min, int optimial_val);
        virtual int othelloBoardEvaluator(const OthelloBoard& board, Turn turn2);
        int move_num = 0;
        Turn turn2;

    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    move_num++;
    int a=1;
    int height = 2 , new_value;
    int optimum_value = -INF ;
    list<Move> moves = board.getValidMoves( turn );
    int k=0;
    if(move_num == 1)
    { 
        a++;
        turn2 = turn;
        a += k;
    }
    int valid_moves= moves.size();
    a = a - k;
    list<Move>::iterator it = moves.begin();
    k++;
    
    Move our_move= *it;
    a=0;
    int i =1;
    while( i< valid_moves )
        {
            OthelloBoard temp_board= board;
            a++;
            Turn trn = turn;
            temp_board.makeMove(trn , *it);
            new_value= test1( temp_board, height , -INF , INF );
            k += a; 
            if( new_value > optimum_value)
            {
                optimum_value= new_value;
                our_move=*it;
                a--;
            }
            it++,i++;
        }
    
    return our_move;
}
extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}

int gl=0;
int MyBot::test1(const OthelloBoard & temp_board , int height , int min , int max)
{
     
     Turn other_player= other(turn);
     int c = 0,new_value;
     list<Move> valid_moves= temp_board.getValidMoves(other_player);
     int k =0;
     list<Move>::iterator it= valid_moves.begin();

     int optimial_val= max;
     k++;
      int i=0;
     while( i<valid_moves.size())
     {
              OthelloBoard temporary_board= temp_board;
              c = c+k;
              Turn trn_b = other_player;

              temporary_board.makeMove(trn_b, *it);


             c++;
              // if((height - 1) != 0)
               new_value= tester(temporary_board, height-1, min , optimial_val);
              //
              // else
               //new_value= othelloBoardEvaluator(temporary_board , turn2 );;


              if(new_value< optimial_val )
              {

                optimial_val= new_value;
                c--;
               if( optimial_val<min)
               {
                c += k;
                return min;
               }

             }

             it++;
             i++;
     }

     return optimial_val;
}


int MyBot::tester(const OthelloBoard &temporary_board , int height , int min ,int  optimial_val)
{
    int tp =1,new_value, k =0;
  if(height == 0)
  {
    tp = tp+ k;
    OthelloBoard my_brd = temporary_board;
    k--;
    return othelloBoardEvaluator(my_brd, turn2);
   }

          list<Move> moves = temporary_board.getValidMoves(turn);
          int xy = 0;
          xy++;
          list<Move> ::iterator it= moves.begin();
          int calc=0;
          calc++;
          int alpha= min , i=0 ;
          while(i<moves.size())
          {
            Turn trn_c = turn;
            OthelloBoard temp_board = temporary_board;
            tp++;
            temp_board.makeMove(trn_c , *it);
            k++;
             new_value = test1(temp_board,height,alpha, optimial_val);

             if(new_value>alpha)
             {
                alpha=new_value;
                tp = tp-k;
                if(alpha> optimial_val)
                 {
                     tp = tp+1;
                     return optimial_val; 
                }
          }

          it++,i++;
        }
          return alpha;

}
int gp =0;
/*The heuristic functions control the ability of the computer to correctly determine how good a particular state is for a player. 
A number of factors determine whether a given state of the game is good for a player.*/
int MyBot::othelloBoardEvaluator(const OthelloBoard & board , Turn turn2 )
{
    int l=0;
    Turn oppturn=other(turn);
//char my_color = 'm',opp_color = 'y';
int myTiles = 0;
int  oppTiles = 0;
int  i, j, k, myFrontTiles = 0;
int  oppFrontTiles = 0;
int  x, y;
double p = 0.0;
double c = 0.0;
double u = 0.0;
double m = 0.0;
double f = 0.0;
double d = 0.0;
int X1[] = {-1, -1, 0, 1, 1, 1, 0, -1};
gp = gp +l;
int Y1[] = {0, 1, 1, 1, 0, -1, -1, -1};
l = 0;
double V[8][8] = 	{ { 1,-0.25,0.10,0.05,0.05,0.10,-0.25,1.00},
        { -0.25 ,-0.25 ,0.01 ,0.01 ,0.01 ,0.01 ,-0.25 ,-0.25},
        {0.10 ,0.01, 0.05, 0.02, 0.02, 0.05, 0.01, 0.10 },
        { 0.05 ,0.01 ,0.02 ,0.01 ,0.01 ,0.02 ,0.01 ,0.05},
        { 0.05, 0.01, 0.02, 0.01, 0.01, 0.02, 0.01, 0.05 },
        { 0.05 ,0.01 ,0.02 ,0.01 ,0.01 ,0.02 ,0.01, 0.05 },
        {0.10 ,0.01, 0.05, 0.02, 0.02, 0.05, 0.01, 0.10   },
        {1,-0.25,0.10,0.05,0.05,0.10,-0.25,1.00 } };
l++;
i=0, j=0;
for(; i < 8; i++)
    for(; j < 8;  )  {
        if(board.get(i,j)==turn)  {
            gp++;
            d += V[i][j];
            gp = gp+l;
            myTiles++;
        }
        else if(board.get(i,j)==oppturn)  
        {
            d -= V[i][j];
            l--;
            oppTiles++;
        }
        if(board.get(i,j)!=EMPTY)   
        { 
            int m=0, k =0;
            while(k < 8)  
            {
                m = m+l;
                x = i + X1[k]; 
                l--;
                m--;
                y = j + Y1[k];
                if(x >= 0 && x < 8 && y >= 0 && y < 8 && board.get(x,y) == EMPTY)
                 {
                    m++;
                    k++;
                    if(board.get(i,j)==turn)
                    {  
                        myFrontTiles++;
                        m--;
                        k=k+1;
                    }
                    else oppFrontTiles++;
                    break;
                }
                k++;
            }
        }
        j++;
    }

if(myTiles > oppTiles)
{ 
    l++;
    p = (100.0 * myTiles)/(myTiles + oppTiles);
}
else if(myTiles < oppTiles) 
{ 
    p = -(100.0 * oppTiles)/(myTiles + oppTiles);
    l--;
}

if(myFrontTiles > oppFrontTiles)
{
    gp++;
     f = -(100.0 * myFrontTiles)/(myFrontTiles + oppFrontTiles);
     gp--;
}
else if(myFrontTiles < oppFrontTiles)

{   gp = gp+1;
     f = (100.0 * oppFrontTiles)/(myFrontTiles + oppFrontTiles);
     gp--;
}

//Corner occupancy
myTiles = oppTiles = 0;
if(board.get(0,0)==turn)
{
     myTiles++;
     gp++;
}
else if(board.get(0,0)==oppturn)
{
     oppTiles++;
     gp--;
}
if(board.get(0,7)==turn)
{
     myTiles++;
     gp--;
}
else if(board.get(0,7)==oppturn)
{
     oppTiles++;
     gp = gp+1;
}
if(board.get(7,0)==turn)
{
     myTiles++;
     gp++;
}
else if(board.get(7,0)==oppturn)
{
     oppTiles++;
     gp--;
}
if(board.get(7,7)==turn) 
{ 
    myTiles++;
    gp++;
}
else if(board.get(7,7)==oppturn) 
{
    oppTiles++;
    gp = gp*2;
}
c = 25 * (myTiles - oppTiles);

//Corner closeness
myTiles = oppTiles = 0;
int h=0, o=1;
if(board.get(i,j)==EMPTY)   {
    if(board.get(0,1)==turn) 
    {
        myTiles++;
        h++;
    }
    else if(board.get(0,1)==oppturn)
    {
        oppTiles++;
        h = h+2;
    } 
    if(board.get(1,1)==turn) 
    {
        myTiles++;
        o = h+1;
    }
    else if(board.get(1,1)==oppturn) 
    { 
        oppTiles++;
        o--;
    }
    if(board.get(1,0)==turn) 
    {
        myTiles++;
        o++;
    }
    else if(board.get(1,0)==oppturn) 
    {
        oppTiles++;
        h =o*1;
    }
}
if(board.get(0,7)==EMPTY)   {
    if(board.get(0,6)==turn)
    {
         myTiles++;
         o--;
    }
    else if(board.get(0,6)==oppturn) 
    {
        oppTiles++;
        o++;
    }
    if(board.get(1,6)==turn)
    {
         myTiles++;
         o=o+1;
    }
    else if(board.get(1,6)==oppturn) 
    {
        oppTiles++;
        o--;
    }
    if(board.get(1,7)==turn) 
    {
        myTiles++;
        h = h+ o;
    }
    else if(board.get(1,7)==oppturn) 
    {
        oppTiles++;
        h--;
    }
}
if(board.get(7,0)==EMPTY)   {
    if(board.get(7,1)==turn) 
    {
        myTiles++;
        gp++;
    }
    else if(board.get(7,1)==oppturn) 
    {
        oppTiles++;
        gp = h+o;
    }
    if(board.get(6,1)==turn) 
    {
        myTiles++;
        o++;
    }
    else if(board.get(6,1)==oppturn) 
    {
        oppTiles++;
        h--;
    }
    if(board.get(6,0)==turn) 
    {
        myTiles++;
        o = o+2;
    }
    else if(board.get(6,0)==oppturn)
    {
         oppTiles++;
         o--;
    }
}
if(board.get(7,7)==EMPTY)   {
    if(board.get(6,7)==turn)
    {
         myTiles++;
         h= h+1;
    }
    else if(board.get(6,7)==oppturn) 
    {
        oppTiles++;
        h--;
    }
    if(board.get(6,6)==turn)
    {
         myTiles++;
         o++;
    }
    else if(board.get(6,6)==oppturn) 
    {
        oppTiles++;
        o++;
    }
    if(board.get(7,6)==turn) 
    {
        myTiles++;
        o--;
    }
    else if(board.get(7,6)==oppturn) 
    {
        oppTiles++;
        h= h*2;
    }
}
l = -10 * (myTiles - oppTiles);

// Mobility
myTiles = (double)(board.getValidMoves(turn).size());
int w = 0; int z=0;
oppTiles = (double)(board.getValidMoves(oppturn).size());
d+=myTiles;
d-=oppTiles;
w = w+z;
if(myTiles > oppTiles) 
{   
    m = (100.0 * myTiles)/(myTiles + oppTiles);
    z++;
}
else if(myTiles < oppTiles) 
{
    w--;
    m = -(100.0 * oppTiles)/(myTiles + oppTiles);
}

//final weighted score
int final_score=0;
z = w + z;
double score = (11 * p) + (850.724 * c) + (382.026 * l) + (86.922 * m) + (78.396 * f) + (10 * d);
z--;
w--;
final_score = w+z;
int sc = int(score);
return sc;

}