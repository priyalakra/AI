#include<bits/stdc++.h>
#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:

        MyBot( Turn turn );

        virtual Move play( const OthelloBoard& board );
         int Beta_function(OthelloBoard& b,int d,int avalue,int bvalue);
         int Alpha_function(OthelloBoard& b, int d, int avalue, int bvalue);
        int F(OthelloBoard& board, Turn turn);


        Turn my_color;
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
  my_color = turn ;
}

Move MyBot::play( const OthelloBoard& board )
{
    list<Move> array=board.getValidMoves( turn );
    int maximum=INT_MIN;
    int temp;
    Move answer = *array.begin();
    int level=2;
    for(auto it = array.begin();it !=array.end();it++){

      OthelloBoard extra = board;
      extra.makeMove(turn,*it);
      temp = Beta_function(extra,level,maximum,INT_MAX);
      if(temp>maximum){
        maximum = temp;
        answer = *it;
      }
    }
    return answer;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}

int MyBot::Beta_function(OthelloBoard& b,int d, int avalue,int bvalue)
{

  Turn opp;
  if(turn == RED)
  opp = BLACK;
  else
  opp = RED;
  list<Move> array = b.getValidMoves(opp);
  int minimum = bvalue;
  int X;
  //int size = moves.size();
  for(auto it=array.begin(); it!= array.end(); it++){
    OthelloBoard extra = b;
    extra.makeMove(opp,*it);
    X = Alpha_function(extra,d-1,avalue,minimum);
    if(X<minimum){
      minimum = X;
      if(minimum<avalue)return avalue;
    }
  }
  return minimum;
}

int MyBot::Alpha_function( OthelloBoard& b, int d, int avalue, int bvalue){
  if(d == 0){

    return F(b,turn);
  }
  list<Move> array = b.getValidMoves(turn);
  int maximum = avalue;
  int temp;
  for(auto it=array.begin(); it !=array.end(); it++){
    OthelloBoard extra = b;
    extra.makeMove(turn,*it);
    temp = Beta_function(extra,d,maximum,bvalue);
    if(temp>maximum){
      maximum = temp;
      if(maximum>bvalue)return bvalue;
    }
  }
  return maximum;
}

int MyBot::F( OthelloBoard& board, Turn turn){

  int array[100] = {
    0,0, 0,0,0,0,0,0,0,0,
    0,100,-10,10,3,3,10,-10,100,0,
    0,-10,-20,-3,-3,-3,-3,-20,-10,0,
    0,10,-3, 8,1,1,8,-3,10,0,
    0,3,-3,1,1,1,1,-3,3,0,
    0, 3, -3, 1, 1,1,1,-3,3,0,
    0,10,-3, 8, 1, 1, 8, -3,10, 0,
    0,-10,-20, -3, -3, -3,-3,-20,-10,0,
    0,100,-10,10,3, 3,10,-10,100, 0,
    0, 0, 0, 0,0, 0,0,0,0,0,
};
int point = 0;

    Turn opp;
    if(turn == 1)
     opp = RED;
    else
    opp = BLACK;
    for (int row = 0 ;row < 8 ;row++)
    {
        for (int col =0 ;col < 8; col++)
        {

            if (board.get(row,col) == turn)
              {  point += array[(row+1)*10+1+col];}
            // calculate the point of the opponent
            else if( board.get(row,col) == opp)
              {  point -= array[(row+1)*10+1+col]; }
          }
    }
    return point;
}
