#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>

using namespace std;
using namespace Desdemona;

typedef pair<int,int> pii;

#define INF 1e18
#define BOARD_SIZE 8

clock_t begin_time;
clock_t current_time;

bool is_time_elapsed()
{
	current_time = clock();
	double tt = ((double)(current_time-begin_time)/CLOCKS_PER_SEC);
	return ((tt>1.95)?true:false);
}

int dirx[8] = {-1,-1,0,1,1,1,0,-1};
int diry[8] = {0,1,1,1,0,-1,-1,-1};

class MyBot: public OthelloPlayer
{
    public:
        MyBot( Turn turn );
        int horizantal_bias[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
        int vertical_bias[8] = {0, 1, 1, 1, 0, -1, -1, -1};
	int weight[8][8] = 	{ { 20, -3, 11, 8, 8, 11, -3, 20 },
				{ -3, -7, -4, 1, 1, -4, -7, -3 },
				{ 11, -4, 2, 2, 2, 2, -4, 11 },
				{ 8, 1, 2, -3, -3, 2, 1, 8 },
				{ 8, 1, 2, -3, -3, 2, 1, 8 },
				{ 11, -4, 2, 2, 2, 2, -4, 11 },
				{ -3, -7, -4, 1, 1, -4, -7, -3 },
				{ 20, -3, 11, 8, 8, 11, -3, 20 } };
        virtual Move play( const OthelloBoard& board );
        virtual double eval(const OthelloBoard& board,Turn turn);
        virtual double ComputeMove(OthelloBoard board, Move move,double alpha, double beta, Turn turn, int depth);
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{}

Move MyBot::play( const OthelloBoard& board )
{
    begin_time = clock();
    double curr_best_val = -INF;
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator it = moves.begin();
    Move curr_best_move((*it).x,(*it).y);
    for(it=moves.begin();it!=moves.end();it++) 
    {
    	OthelloBoard cpy = board;
    	double val = ComputeMove(cpy,*it,-INF,INF,turn,1);
    	if((val-curr_best_val)>0) // Play as Max Node
    	{
    		curr_best_move = *it;
    		curr_best_val = val;
    	}
    }
    return curr_best_move;
}

/////////////////////////////////////////////////////////////////////////////

bool isvalid(int x,int y)
{
	return (x >= 0 && x < BOARD_SIZE && y >= 0 && y < BOARD_SIZE);
}

pii closeness(int x,int y,char table[8][8],char color1,char color2)
{
	if(table[0][0] != '0') return make_pair(0,0);
	int t1 = 0;
	int t2 = 0;
	for(int i=0;i<BOARD_SIZE;i++)
	{
		for(int j=0;j<BOARD_SIZE;j++)
		{
			int xx = x+dirx[i];
			int yy = y+diry[j];
			if(isvalid(xx,yy))
			{
				if(table[xx][yy] == color1) 	 t1++;
				else if(table[xx][yy] == color2) t2++;
			}
		}
	}
	return make_pair(t1,t2);
}	

double MyBot::eval(const OthelloBoard& board,Turn turn)
{
	char color1 = 'n',color2 = 'v',color3 = '0';
    	char table[BOARD_SIZE][BOARD_SIZE];
	for(int i=0;i<BOARD_SIZE;i++) 
	{
		for(int j=0;j<BOARD_SIZE;j++) 
		{
			Coin curr_turn = board.get(i,j);
			if(curr_turn == other(turn)) table[i][j] = color1;
			else if(curr_turn == turn) table[i][j] = color2;
			else table[i][j] = color3;
		}
	}
	
	
	double mb = 0.0;
	double m1 = board.getValidMoves(turn).size();
	double m2 = board.getValidMoves(other(turn)).size();
	if(m1 > m2) mb = (100.0 * m1)/(m1+m2);
	else if(m1 < m2) mb = -(100.0 * m2)/(m1+m2);
	
	
	int tiles1 = 0, tiles2 = 0;
	int tmpTiles1 = 0, tmpTiles2 = 0;
	double dsk = 0.0;
	double fd = 0.0;
	double pd = 0.0;
	
	for(int i = 0; i < BOARD_SIZE; i++) 
	{
		for(int j = 0; j < BOARD_SIZE; j++)  
		{
			if(table[i][j] == color1)
			{
				dsk += weight[i][j];
				tiles1++;
			}
			else if(table[i][j]==color2)
			{
				dsk -= weight[i][j];
				tiles2++;
			}
		}
	}
	if(tiles1 > tiles2) 		pd = (100.0 * tiles1)/(tiles1 + tiles2);
	else if(tiles1 < tiles2) 	pd = -(100.0 * tiles2)/(tiles1 + tiles2);
	else {}
	
	
	
	for(int i = 0; i < BOARD_SIZE; i++) 
	{
		for(int j = 0; j < BOARD_SIZE; j++)  
		{
		    if(table[i][j] != '0')   
		    {
			for(int k = 0; k < BOARD_SIZE; k++)  
			{
			    int xx = i + horizantal_bias[k];
			    int yy = j + vertical_bias[k];
			    if(isvalid(xx,yy) && table[xx][yy] == '0') 
			    {
				if(table[i][j] == color1) tmpTiles1++;
				else tmpTiles2++;
				break;
			    }
			}
		    }
		}
	}
	if(tmpTiles1 > tmpTiles2) 	fd = -(100.0 * tmpTiles1)/(tmpTiles1 + tmpTiles2);
	else if(tmpTiles1 < tmpTiles2) 	fd = (100.0 * tmpTiles2)/(tmpTiles1 + tmpTiles2);
	else {}
	
	
	tiles1 = 0; tiles2 = 0;
	pii u = closeness(7,7,table,color1,color2);
	tiles1 += u.first;
	tiles2 += u.second;
	u = closeness(0,7,table,color1,color2);
	tiles1 += u.first;
	tiles2 += u.second;
	u = closeness(0,0,table,color1,color2);
	tiles1 += u.first;
	tiles2 += u.second;
	u = closeness(7,0,table,color1,color2);
	tiles1 += u.first;
	tiles2 += u.second;
	
	
	double t1 = 0;
	double t2 = 0;
	int tmp[2] = {0,7};
	for(int hh=0;hh<2;hh++)
	{
		for(int kk=0;kk<2;kk++)
		{
			if(table[tmp[hh]][tmp[kk]] == color1) 		t1++;
			else if(table[tmp[hh]][tmp[kk]] == color2) 	t2++;
		}
	}	


	// Cummilative score with different weights
	double res = (78.396 * fd) + (382.026 * (-10) * (tiles1-tiles2));
	res += (86.922 * mb) + (11 * pd);
	res += (850.724 * 25 *  (t1-t2)) + (10 * dsk);
	return res;
}

///////////////////////////////////////////////////////////////////////////

double MyBot::ComputeMove(OthelloBoard board, Move move,double alpha, double beta, Turn turn, int depth) 
{
        if(is_time_elapsed()) 
        {
		if((depth%2)!=0) 	return -INF;
		else 			return  INF;
        }
	if(depth > 3)  return eval(board,turn); // End of depth, return the heuristic value for this node
	Turn nxt = other(turn);
	board.makeMove(other(nxt),move);
	list<Move> nxtMoves = board.getValidMoves(nxt);
	double res = 0;
	if(depth&1) 	res =  INF;
	else 		res = -INF;
	if(nxtMoves.size()==0) return res;
	for(list<Move>::iterator itr = nxtMoves.begin();itr!=nxtMoves.end();itr++) 
	{
		double val = ComputeMove(board,*itr,alpha,beta,nxt,depth+1); // Value at current node(Either min or max)
		if((depth%2)!=0)  // In case of min Node
		{
			res =  min(res,val);
			beta = min(beta,res);
		}
		else 	     	  // In case of max Node
		{ 
			res =   max(res,val);
			alpha = max(alpha,res);		
		}
		if(alpha>=beta) break; // alpha-beta pruning
	}
	return res; 
}

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}
