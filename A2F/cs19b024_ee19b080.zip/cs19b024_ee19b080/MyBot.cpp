/*
 * @file botTemplate.cpp
 * @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
 * @date 2010-02-04
 * Template for users to create their own bots
 */

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>
using namespace std;
using namespace Desdemona;

clock_t clk_begin, clk_end;
Turn player_colour;
#define INF 1e18

// Evaluation function is derived from multiple sources: kartikkukreja github, Washington DC research paper
double eval(OthelloBoard board)
{

    // 1 denotes ourmarker -1 denotes oppmarker, 0 denotes not played yet
    int dir[8][2] = {{-1, 0}, {-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}};

    int static_stability[8][8] = {{20, -3, 11, 8, 8, 11, -3, 20},
                   {-3, -7, -4, 1, 1, -4, -7, -3},
                   {11, -4, 2, 2, 2, 2, -4, 11},
                   {8, 1, 2, -3, -3, 2, 1, 8},
                   {8, 1, 2, -3, -3, 2, 1, 8},
                   {11, -4, 2, 2, 2, 2, -4, 11},
                   {-3, -7, -4, 1, 1, -4, -7, -3},
                   {20, -3, 11, 8, 8, 11, -3, 20}};

    // int static_stability[8][8] = {
    //     {4, -3, 2, 2, 2, 2, -3, 4},
    //     {-3, -4, -1, -1, -1, -1, -4, -3},
    //     {2, -1, 1, 0, 0, 1, -1, 2},
    //     {2, -1, 0, 1, 1, 0, -1, 2},
    //     {2, -1, 0, 1, 1, 0, -1, 2},
    //     {2, -1, 1, 0, 0, 1, -1, 2},
    //     {-3, -4, -1, -1, -1, -1, -4, -3},
    //     {4, -3, 2, 2, 2, 2, -3, 4}};
    int grid[8][8] = {};

    int p1_squares = 0, p2_squares = 0, p1_v_squares = 0, p2_v_squares = 0;
    double coin_parity = 0, mobility = 0, stability = 0, corners = 0, corner_closeness = 0, vulnerability = 0;
    // init grid
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            Coin findTurn = board.get(i, j); 
            if (findTurn == player_colour){
                grid[i][j] = 1; 
            }
            else if (findTurn == other(player_colour)){
                grid[i][j] = -1; 
            }
            else{
                grid[i][j] = 0; 
            } 
        }
    }

    // returns if the piece is in range.
    auto in_range = [&](int x, int y)
    {
        return (x >= 0 and x < 8) and (y >= 0 and y < 8);
    };

    // coin parity, vulnerability and stability.
    for (int x = 0; x < 8; x++)
    {
        for (int y = 0; y < 8; y++)
        {

            if (grid[x][y] == 1)
            {
                p1_squares++;
                stability += static_stability[x][y];
            }
            else if (grid[x][y] == -1)
            {
                p2_squares++;
                stability -= static_stability[x][y];
            }

            if (grid[x][y] != 0)
            {
                for (int i = 0; i < 8; i++)
                {
                    int dx = x + dir[i][0], dy = y + dir[i][1];
                    // if the adjacent cell exists and is empty.
                    if (in_range(dx, dy) and grid[dx][dy] == 0)
                    {
                        // depending on who grid[x,y] is the vulnerability is calculated !
                        if (grid[x][y] == 1)
                        {
                            p1_v_squares++;
                        }
                        else
                        {
                            p2_v_squares++;
                        }
                    }
                }
            }
        }
    }
    coin_parity = (p1_squares > p2_squares) ? ((100.0 * p1_squares) / (p1_squares + p2_squares)) : (-(100.0 * p2_squares) / (p1_squares + p2_squares));
    vulnerability = (p1_v_squares > p2_v_squares) ? (-(100.0 * p1_v_squares) / (p1_v_squares + p2_v_squares)) : ((100.0 * p2_v_squares) / (p1_v_squares + p2_v_squares));

    // corner occupancy
    p1_squares = 0, p2_squares = 0;
    int corner_coords[4][2] = {{0, 0}, {0, 7}, {7, 0}, {7, 7}};
    for (int i = 0; i < 4; i++)
    {
        int x = corner_coords[i][0], y = corner_coords[i][1];
        if (grid[x][y] == 1)
        {
            ++p1_squares;
        }
        else if (grid[x][y] == -1)
        {
            ++p2_squares;
        }
    }
    corners = 25 * (p1_squares - p2_squares);

    // corner closeness.
    p1_squares = 0, p2_squares = 0;
    for (int i = 0; i < 4; i++)
    {
        int x = corner_coords[i][0], y = corner_coords[i][1];
        for (int j = 0; j < 8; j++)
        {
            int dx = x + dir[j][0];
            int dy = y + dir[j][1];
            if (in_range(dx, dy))
            {
                if (grid[dx][dy] == 1)
                {
                    p1_squares++;
                }
                else if (grid[dx][dy] == -1)
                {
                    p2_squares++;
                }
            }
        }
    }
    corner_closeness = -10 * (p1_squares - p2_squares);

    // Mobility
    p1_squares = board.getValidMoves(player_colour).size();
    p2_squares = board.getValidMoves(other(player_colour)).size();

    mobility = (p1_squares > p2_squares) ? ((100.0 * p1_squares) / (p1_squares + p2_squares)) : (-(100.0 * p2_squares) / (p1_squares + p2_squares));
    // double score = 11 * coin_parity + 850.74 * corners + (382.026 * corner_closeness) + (86.922 * mobility) + (78.396 * vulnerability) + 50 * (stability);

    double score = 11 * coin_parity + 850.74 * corners + (382.026 * corner_closeness) + (86.922* mobility) + (78.396 * vulnerability) + 10* (stability);

    return score;
}

// Aplha beta algorithm
double alpha_beta(OthelloBoard board, Move move, Turn turn, int k, double alpha, double beta)
{
    clk_end = clock();

    if (((double)(clk_end - clk_begin) / CLOCKS_PER_SEC) > 1.95)
    {
        if (turn == player_colour)
            return -INF;
        return INF;
    }
    if (k == 6)
    {
        return eval(board);
    }

    board.makeMove(turn, move);
    turn = other(turn);
    
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator move_it = moves.begin();

    if ((moves.size()) == 0)
        return eval(board);
    
    if (turn == other(player_colour))
    {
        for (; move_it != moves.end(); move_it++)
        {
            beta = min(beta, alpha_beta(board, *move_it, turn, k + 1, alpha, beta));
            if (alpha >= beta)
                return alpha;
        }
        return beta;
    }
    else
    {
        for (; move_it != moves.end(); move_it++)
        {
            alpha = max(alpha, alpha_beta(board, *move_it, turn, k + 1, alpha, beta));
            if (alpha >= beta)
                return beta;
        }
        return alpha;
    }
}

class MyBot : public OthelloPlayer
{
public:
    /**
     * Initialisation routines here
     * This could do anything from open up a cache of "best moves" to
     * spawning a background processing thread.
     */
    Turn turn;
    MyBot(Turn turn);

    /**
     * Play something
     */
    virtual Move play(const OthelloBoard &board);

private:
};

MyBot::MyBot(Turn turn)
    : OthelloPlayer(turn)
{
    this->turn = turn;
}

Move MyBot::play(const OthelloBoard &board)
{
    clk_begin = clock();
    list<Move> moves = board.getValidMoves(turn);
    list<Move>::iterator move_it = moves.begin();
    Move bestMove((*move_it).x, (*move_it).y);

    OthelloBoard temp = board;
    double best_val = -INF;
    player_colour = turn;
    for (; move_it != moves.end(); move_it++)
    {
        double curr_val = alpha_beta(temp, *move_it, player_colour, 1, -INF, INF);
        if (curr_val > best_val)
        {
            best_val = curr_val;
            bestMove = *move_it;
        }
        temp = board;
    }
    return bestMove;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C"
{
    OthelloPlayer *createBot(Turn turn)
    {
        return new MyBot(turn);
    }

    void destroyBot(OthelloPlayer *bot)
    {
        delete bot;
    }
}
