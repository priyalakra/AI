/*
Team Name = Sarvagya Sriram Mamgain(CS21M059) & Ankit Kharwar(CS21M005)
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>

#define FL false
#define TR true
#define DBL double
#define Initeger int
#define Bulian bool
#define Iterate_Loop for

using namespace std;
using namespace Desdemona;



#define INF 1e18

Turn my;

clock_t start,finish;
OthelloBoard globalBoard;

Bulian compareTwo(char a , char b) //User to compare two different caharacters
{
     if(a == b) return TR; //TR if same
     return FL; //Else FL;
}


Bulian isPossibleToMove(char self, char opp, char *str)  {
	if(compareTwo(str[0] , opp))return FL;
	
	
	Initeger counter = 1;
	
	while(counter < 8) 
	{
	     if (compareTwo(str[counter] , 'e')) return FL; //return FL is found "E"
		if (compareTwo(str[counter] , self)) return TR; 
		counter += 1; //counter increment(loop vaiable)
	}
	
	
	return FL;
	
}

Initeger ret(Initeger a , Initeger b , Initeger c)
{
     return a + b*c;
}

bool isLegalMove(char self, char opp, char Board[8][8], Initeger startx, Initeger starty)   {
	if (Board[startx][starty] != 'e') return FL;
	char str[10];


	int x, y, Direction_For_X, Direction_For_Y, ctr;
	Iterate_Loop (Direction_For_Y = -1; Direction_For_Y <= 1; Direction_For_Y++)
	{
		Iterate_Loop (Direction_For_X = -1; Direction_For_X <= 1; Direction_For_X++)    
		{
	        // keep going if both velocities are zero
			if (!Direction_For_Y && !Direction_For_X) continue;
			str[0] = '\0';
			for (ctr = 1; ctr < 8; ctr++)   
			{
				
				
				x = ret(startx , ctr , Direction_For_X);
				y = ret(starty , ctr , Direction_For_Y);
				
				if (x >= 0  && x<8 && y >= 0 && y<8)
				{
				    str[ctr-1] = Board[x][y];
				}
				else
				{
				    str[ctr-1] = 0;
				}
			}
			if (isPossibleToMove(self, opp, str)) return true;
		}
	}
	return false;
}




Initeger n_MovesCorrect(char self, char opp, char Board[8][8])   {
	Initeger count = 0, i, j;
	for(i = 0; i < 8; i++)
	{
	      for(j = 0; j < 8; j++) 
	      {
	      
	          if(isLegalMove(self, opp, Board, i, j)) count+=1;
	      }
	 }
	return count;
}

DBL othelloBoardEvaluator(char Board[8][8])  {
	char mine_clr_chosen = 'm',others_clr_chosen = 'y';
    Initeger mine_Teil = 0, other_Teil = 0, i, j, k, myFrontTiles = 0, oppFrontTiles = 0, x, y;
    DBL p = 0.0, c = 0.0, l = 0.0, m = 0.0, f = 0.0, d = 0.0;

    Initeger X1[] = {-1, -1, 0, 1, 1, 1, 0, -1}; //X-axis direction cells
    Initeger Y1[] = {0, 1, 1, 1, 0, -1, -1, -1}; //Y-Axis Direction cells
    
    //Prebuild amtrix for loss calculation Or profit calculation
    Initeger V[8][8] = 	{ { 20, -3, 11, 8, 8, 11, -3, 20 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 20, -3, 11, 8, 8, 11, -3, 20 } };
  
	// Piece difference, frontier disks and disk squares
 
 
      i = 0;
	while(i < 8)
	{
	    j = 0;
	    while(j < 8)
	    {
	          if(Board[i][j] == mine_clr_chosen)   //If our cell then addition to the value of d
	          {
                     d += V[i][j];
                     mine_Teil++;
               } 
                 else if(Board[i][j] == others_clr_chosen)  //If enemy cell then subtraction to the value of d
                 {
                     d -= V[i][j];
                     other_Teil++;
                 }
                 if(Board[i][j] != 'e')   //Else do this
                 {
                     for(k = 0; k < 8; k++)  
                     {
                         x = i + X1[k]; y = j + Y1[k];
                         if(x >= 0 && x < 8 && y >= 0 && y < 8 && Board[x][y] == 'e')   //Checking over all the combiations
                         {
                             if(Board[i][j] == mine_clr_chosen)  myFrontTiles+=1;  //If our cell
                             else oppFrontTiles+=1; //If enemy cell
                             
                             if(TR) 
                             break;
                         }
                     }
                 }
	          j+=1;
	    }
	    i+=1;
	}
        
        
 
 
 

    if(mine_Teil > other_Teil) p = (100.0 * mine_Teil)/(mine_Teil + other_Teil);
    else if(mine_Teil < other_Teil) p = -(100.0 * other_Teil)/(mine_Teil + other_Teil);

    if(myFrontTiles > oppFrontTiles) f = -(100.0 * myFrontTiles)/(myFrontTiles + oppFrontTiles);
    else if(myFrontTiles < oppFrontTiles) f = (100.0 * oppFrontTiles)/(myFrontTiles + oppFrontTiles);

    // checking for the occupancy taken by the corners
    mine_Teil = other_Teil = 0;
if(Board[0][0] == mine_clr_chosen)  //Checking for the top left corner , we see who have chosen it , if our color then its our tile and help to increase the count , else it will inc, emeny tiles
{
    mine_Teil+=1;// Add to Our tiles count , if it is of our color
}
    else if(Board[0][0] == others_clr_chosen) 
    {
        other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
    }
    if(Board[0][7] == mine_clr_chosen) //Checking for the top right corner , we see who have chosen it , if our color then its our tile and help to increase the count , else it will inc, emeny tiles
    {
        mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
    else if(Board[0][7] == others_clr_chosen) 
    {
        other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
    }
    if(Board[7][0] == mine_clr_chosen) //Checking for the bottom left corner , we see who have chosen it , if our color then its our tile and help to increase the count , else it will inc, emeny tiles
    {
        mine_Teil+=1;// Add to Our tiles count , if it is of our color
    }
    else if(Board[7][0] == others_clr_chosen) 
    {
        other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
    }
    if(Board[7][7] == mine_clr_chosen) //Checking for the botom right corner , we see who have chosen it , if our color then its our tile and help to increase the count , else it will inc, emeny tiles
    {
        mine_Teil+=1;// Add to Our tiles count , if it is of our color
    }
    else if(Board[7][7] == others_clr_chosen) 
    {
        other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
    }
    
    //Adding upto to "c" the above calc. counts
    c = 25 * (mine_Teil - other_Teil);

    // checking the closeness for the Corners 
    mine_Teil = other_Teil = 0;
    if(compareTwo(Board[0][0] , 'e'))   { //If top left "e" cell , then its check its corners :- 
        if(Board[0][1] == mine_clr_chosen) 
        {
            mine_Teil+=1;   // Add to Our tiles count , if it is of our color
        }
        else if(Board[0][1] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
        if(Board[1][1] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[1][1] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
        if(Board[1][0] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[1][0] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
    }
    if(compareTwo(Board[0][7] , 'e'))   {//If top right "e" cell , then its check its corners :- 
        if(Board[0][6] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[0][6] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
        if(Board[1][6] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[1][6] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
        if(Board[1][7] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[1][7] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
    }
    if(compareTwo(Board[7][0] , 'e'))   {//If bottom left "e" cell , then its check its corners :- 
        if(Board[7][1] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[7][1] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
        if(Board[6][1] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[6][1] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
        if(Board[6][0] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[6][0] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
    }
    if(compareTwo(Board[7][7] , 'e'))   {//If bottom right "e" cell , then its check its corners :- 
        if(Board[6][7] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[6][7] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
        if(Board[6][6] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[6][6] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
        if(Board[7][6] == mine_clr_chosen) 
        {
            mine_Teil+=1;// Add to Our tiles count , if it is of our color
        }
        else if(Board[7][6] == others_clr_chosen)
        {
             other_Teil+=1;// Add to Enemie's tiles count , if it is of Enemie's color
        }
    }
    l = -10 * (mine_Teil - other_Teil);

    // Doing calculation for the final mobility
    mine_Teil = n_MovesCorrect(mine_clr_chosen, others_clr_chosen, Board);
    other_Teil = n_MovesCorrect(others_clr_chosen, mine_clr_chosen, Board);
    if(mine_Teil > other_Teil) m = (100.0 * mine_Teil)/(mine_Teil + other_Teil);
    else if(mine_Teil < other_Teil) m = -(100.0 * other_Teil)/(mine_Teil + other_Teil);

    // finding the final answer for the Weigted score using above calc sums
    DBL score = (11 * p) ;
    score +=  (850.724 * c) ;
    score += (382.026 * l) ;
    score += (86.922 * m) ;
    score += (78.396 * f) ;
    score += (10 * d);
    return score;
}

DBL testMyMove(OthelloBoard board, Move move, Turn turn, short level, DBL alpha, DBL beta) {
    finish = clock();
    if(((DBL)(finish-start)/CLOCKS_PER_SEC)>1.95) { //Checking the time to be udner 2 seconds
        if(level&1) return -INF;    //this case we return negative infitnie
        return INF; //this case we return positive infitnie
    }
	if(level == 6) {   //Only if we are depth of 6 then run this
		char Board[8][8];
	
		
		Initeger i = 0; //loop varilbles
		while(i < 8)
		{
		     Initeger j = 0; //loop varilbles
		     while(j < 8)
		     {
		          Coin findTurn = board.get(i,j);
				if(findTurn == turn) Board[i][j] = 'y';   // If it  turn then set it up to Y
				else if(findTurn == other(turn)) Board[i][j] = 'm'; //Else we have to set to M if not turn
				else Board[i][j] = 'e';  //otherwise simply set to E
				
				j+=1; // ineer loop counter
		     }
		     i+=1; //outer loop counter
		}
		
		
		
		
		return othelloBoardEvaluator(Board);
	}
	board.makeMove(turn,move);
	turn = other(turn);
	list<Move> newMoves = board.getValidMoves(turn);
	list<Move>::iterator iter = newMoves.begin();
	DBL ret = -INF;
	if(level&1) ret *= -1;
	if(!(newMoves.size())) return ret;
	Iterate_Loop(;iter!=newMoves.end();iter++) {
		DBL curr = testMyMove(board,*iter,turn,level+1,alpha,beta);
		if(level&1) {
			ret = min(ret,curr);
			beta = min(beta,ret);
		}
		else {
			ret = max(ret,curr);
			alpha = max(alpha,ret);		
		}
		if(beta<=alpha) break;
	}
	return ret; 
}

DBL tester(OthelloBoard board,Turn turn) {
   
    
    char Board[8][8];
  
    
     Initeger i = 0;
	while(i < 8)
	{
	    Initeger j = 0;
	    while(j < 8)
	    {
	        Coin findTurn = board.get(i,j);
             if(findTurn == turn) {if(TR) Board[i][j] = 'm';}
             else if(findTurn == other(turn)) {if(!FL) Board[i][j] = 'y';}
             else { if(TR) Board[i][j] = 'e';}
				
	          j+=1;
	    }
	    i+=1;
	}
	
    
    
    return othelloBoardEvaluator(Board);
    
    
    
}

Bulian compare(Move a, Move b) {
    OthelloBoard One = globalBoard,Two = globalBoard;
    One.makeMove(my,a);
    Two.makeMove(my,b);
    return tester(One,my)>tester(Two,my);
}

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& board );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    start = clock();
    list<Move> moves = board.getValidMoves( turn );
    my = turn;
    globalBoard = board;
    
    moves.sort(compare);
    
    list<Move>::iterator iter = moves.begin();
    Move bestMove((*iter).x,(*iter).y);
    DBL retVal = -INF;
    DBL MAX = INF, MIN = -INF;
    OthelloBoard copyBoard = board;
    short level = 1;
    Iterate_Loop(;iter!=moves.end();iter++) {
    	DBL currValue = testMyMove(copyBoard,*iter,turn,level,MIN,MAX);
    	if(currValue <= retVal) 
    	{
    		;
    	}
    	else
    	{
    	     retVal = currValue;
    		bestMove = *iter;
    	}
    	copyBoard = board;
    }
    return bestMove;
}

// The following lines are very important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn whosetTurn )
    {
        return new MyBot(  whosetTurn );
    }

    void destroyBot( OthelloPlayer* Plyr_bot )
    {
        delete Plyr_bot;
    }
}
