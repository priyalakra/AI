#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include <ctime>
#include <list>
using namespace std;
using namespace Desdemona;

#define INF 1e18

Turn my;

clock_t start,finish;
OthelloBoard globalBoard;


bool canMove(char self, char opp, char *s)  {
	if (s[0] != opp) return false;
	for (int ctr = 1; ctr < 8; ctr++) {
		if (s[ctr] == 'e') return false;
		if (s[ctr] == self) return true;
	}
	return false;
}

bool isLegal(char self, char opp, char Matrix[8][8], int startx, int starty)   {
	if (Matrix[startx][starty] != 'e') return false;
	char s[10];
	int x, y, dx, dy, ctr;
	for (dy = -1; dy <= 1; dy++)
		for (dx = -1; dx <= 1; dx++)    {
	        // keep going if both velocities are zero
			if (!dy && !dx) continue;
			s[0] = '\0';
			for (ctr = 1; ctr < 8; ctr++)   {
				x = startx + ctr*dx;
				y = starty + ctr*dy;
				if (x >= 0 && y >= 0 && x<8 && y<8) s[ctr-1] = Matrix[x][y];
				else s[ctr-1] = 0;
			}
			if (canMove(self, opp, s)) return true;
		}
	return false;
}

int numValidMoves(char self, char opp, char Matrix[8][8])   {
	int count = 0, i, j;
	for(i = 0; i < 8; i++) for(j = 0; j < 8; j++) if(isLegal(self, opp, Matrix, i, j)) count++;
	return count;
}

double othelloBoardEvaluator(char Matrix[8][8])  {
	char mclr = 'm',oppc = 'y';
    int mytil = 0, opptil = 0, i, j, k, myFronttil = 0, oppFronttil = 0, x, y;
    double p = 0.0, c = 0.0, l = 0.0, m = 0.0, f = 0.0, d = 0.0;

    int X1[] = {-1, -1, 0, 1, 1, 1, 0, -1};
    int Y1[] = {0, 1, 1, 1, 0, -1, -1, -1};
    int V[8][8] = 	{ { 20, -3, 11, 8, 8, 11, -3, 20 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 8, 1, 2, -3, -3, 2, 1, 8 },
    				{ 11, -4, 2, 2, 2, 2, -4, 11 },
    				{ -3, -7, -4, 1, 1, -4, -7, -3 },
    				{ 20, -3, 11, 8, 8, 11, -3, 20 }};

    for(i = 0; i < 8; i++){
        for(j = 0; j < 8; j++)  {
            if(Matrix[i][j] == mclr)  {
                d += V[i][j];
                mytil++;
            } 
            else if(Matrix[i][j] == oppc)  {
                d -= V[i][j];
                opptil++;
            }
            if(Matrix[i][j] != 'e'){
                for(k = 0; k < 8; k++)  {
                    x = i + X1[k]; y = j + Y1[k];
                    if(x >= 0 && x < 8 && y >= 0 && y < 8 && Matrix[x][y] == 'e') {
                        if(Matrix[i][j] == mclr)  myFronttil++;
                        else oppFronttil++;
                        break;
                    }
                }
            }
        }
    }

    if(mytil > opptil) p = (100.0 * mytil)/(mytil + opptil);
    else if(mytil < opptil) p = -(100.0 * opptil)/(mytil + opptil);

    if(myFronttil > oppFronttil) f = -(100.0 * myFronttil)/(myFronttil + oppFronttil);
    else if(myFronttil < oppFronttil) f = (100.0 * oppFronttil)/(myFronttil + oppFronttil);

    mytil = opptil = 0;
    mytil += (Matrix[0][0] == mclr);
    opptil += (Matrix[0][0] == oppc);
    mytil += (Matrix[0][7] == mclr);
    opptil += (Matrix[0][7] == oppc);
    mytil += (Matrix[7][0] == mclr);
    opptil += (Matrix[7][0] == oppc);
    mytil += (Matrix[7][7] == mclr);
    opptil += (Matrix[7][7] == oppc);
    c = 25 * (mytil - opptil);

    mytil = opptil = 0;
    if(Matrix[0][0] == 'e')   {
        if(Matrix[0][1] == mclr) mytil++;
        else if(Matrix[0][1] == oppc) opptil++;
        if(Matrix[1][1] == mclr) mytil++;
        else if(Matrix[1][1] == oppc) opptil++;
        if(Matrix[1][0] == mclr) mytil++;
        else if(Matrix[1][0] == oppc) opptil++;
    }
    if(Matrix[0][7] == 'e')   {
        if(Matrix[0][6] == mclr) mytil++;
        else if(Matrix[0][6] == oppc) opptil++;
        if(Matrix[1][6] == mclr) mytil++;
        else if(Matrix[1][6] == oppc) opptil++;
        if(Matrix[1][7] == mclr) mytil++;
        else if(Matrix[1][7] == oppc) opptil++;
    }
    if(Matrix[7][0] == 'e')   {
        if(Matrix[7][1] == mclr) mytil++;
        else if(Matrix[7][1] == oppc) opptil++;
        if(Matrix[6][1] == mclr) mytil++;
        else if(Matrix[6][1] == oppc) opptil++;
        if(Matrix[6][0] == mclr) mytil++;
        else if(Matrix[6][0] == oppc) opptil++;
    }
    if(Matrix[7][7] == 'e')   {
        if(Matrix[6][7] == mclr) mytil++;
        else if(Matrix[6][7] == oppc) opptil++;
        if(Matrix[6][6] == mclr) mytil++;
        else if(Matrix[6][6] == oppc) opptil++;
        if(Matrix[7][6] == mclr) mytil++;
        else if(Matrix[7][6] == oppc) opptil++;
    }
    l = (mytil - opptil)*(-10);

    // Mobility
    mytil = numValidMoves(mclr, oppc, Matrix);
    opptil = numValidMoves(oppc, mclr, Matrix);
    if(mytil > opptil) m = (100.0 * mytil)/(mytil + opptil);
    else if(mytil < opptil) m = -(100.0 * opptil)/(mytil + opptil);

    // final weighted score
    double score = (11 * p) + (850.724 * c) + (382.026 * l) + (86.922 * m) + (78.396 * f) + (10 * d);
    return score;
}

double moveTest(OthelloBoard B, Move move, Turn turn, short level, double alpha, double beta) {
    finish = clock();
    if(((double)(finish-start)/CLOCKS_PER_SEC)>1.95) {
        if(level&1) return -INF;
        return INF;
    }
	if(level == 6) {
		char Matrix[8][8];
		for(int i=0;i<8;i++) {
			for(int j=0;j<8;j++) {
				Coin findTurn = B.get(i,j);
				if(findTurn == turn) Matrix[i][j] = 'y';
				else if(findTurn == other(turn)) Matrix[i][j] = 'm';
				else Matrix[i][j] = 'e';
			}
		}
		return othelloBoardEvaluator(Matrix);
	}
	B.makeMove(turn,move);
	turn = other(turn);
	list<Move> newMoves = B.getValidMoves(turn);
	list<Move>::iterator iter = newMoves.begin();
	double ret = -INF;
	if(level&1) ret *= -1;
	if(!(newMoves.size())) return ret;
	for(;iter!=newMoves.end();iter++) {
		double curr = moveTest(B,*iter,turn,level+1,alpha,beta);
		if(level&1) {
			ret = min(ret,curr);
			beta = min(beta,ret);
		}
		else {
			ret = max(ret,curr);
			alpha = max(alpha,ret);		
		}
		if(beta<=alpha) break;
	}
	return ret; 
}

double tester(OthelloBoard B,Turn turn) {
    char Matrix[8][8];
    for(int i=0;i<8;i++) {
        for(int j=0;j<8;j++) {
        Coin findTurn = B.get(i,j);
        if(findTurn == turn) Matrix[i][j] = 'm';
        else if(findTurn == other(turn)) Matrix[i][j] = 'y';
        else Matrix[i][j] = 'e';
        }
    }
    return othelloBoardEvaluator(Matrix);
}

bool compare(Move a, Move b) {
    OthelloBoard One = globalBoard,Two = globalBoard;
    One.makeMove(my,a);
    Two.makeMove(my,b);
    return tester(One,my)>tester(Two,my);
}

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play( const OthelloBoard& B );
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& B )
{
    start = clock();
    list<Move> moves = B.getValidMoves( turn );
    my = turn;
    globalBoard = B;
    moves.sort(compare);
    list<Move>::iterator it = moves.begin();
    Move bestMove((*it).x,(*it).y);
    double retVal = -INF;
    double MAX = INF, MIN = -INF;
    OthelloBoard copyBoard = B;
    short level = 1;
    for(;it!=moves.end();it++) {
    	double currValue = moveTest(copyBoard,*it,turn,level,MIN,MAX);
    	if(currValue > retVal) {
    		retVal = currValue;
    		bestMove = *it;
    	}
    	copyBoard = B;
    }
    return bestMove;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}